function sf_srcwlt_init(src_wlt,fpeak)

global bp

bp.src_wlt = src_wlt;

if (src_wlt)

wlt_t = zeros(bp.nt,1);
t0=(bp.nt+1)/2*bp.dt;

wpeak = 2*pi*fpeak;
apeak=wpeak*wpeak*0.25;

for it=1:bp.nt
    
    t=it*bp.dt;
    t1=t-t0;
    
    rktmp = apeak*t1*t1;
    if(rktmp<=100)
        wlt_t(it) = (1.0-2*rktmp)*exp(-rktmp);
    end
    
end

bp.src_wlt = 1;
bp.wlt=fft(wlt_t,bp.nfft);
bp.wlt=bp.wlt(1:bp.nw,:);
MASK=[1;2*ones(bp.nw-2,1);1];
bp.wlt=abs(bp.wlt).*MASK; %zero-phase source wavelet

figure('name','bandpass + sourcewavelet')
plot([0:bp.nw-1]/bp.nw/2/bp.dt,bp.flt,'b'); hold on
plot([0:bp.nw-1]/bp.nw/2/bp.dt,bp.wlt,'r'); 

else
    
    return
    
end
