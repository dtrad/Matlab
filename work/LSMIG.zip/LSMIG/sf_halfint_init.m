function sf_halfint_init(inv,n1,rho,sign)
% code for half integration/derivation with regularization (rho)
% (-j*w)^(1/2) = |w|^(1/2)exp(-j*45)
global hint

hint.n=n1;
hint.nfft = 2^nextpow2(n1);
hint.nw = hint.nfft/2+1;

hint.cf = zeros(hint.nw,1)+1i*zeros(hint.nw,1);

for i=1:hint.nw
    om = sign * 2. * pi * i / hint.nfft;
    %om = 2. * pi * i / hint.nfft;
    
    % Z = exp(j*2*pi*f/dt) = exp(j*2*pi*i/n)
    cw_r = cos(om);
    cw_i = sin(om);
       
    % 1-Z
    cz_r = 1.-rho*cw_r;
    cz_i =   -rho*cw_i;
    cz = cz_r + 1i * cz_i;
    
    if (inv)
        cz = sqrt(cz); %sqrt(1-Z)
    else
        cz2_r = 0.5*(1.+rho*cw_r);
        cz2_i = 0.5*rho*cw_i;
        cz2 = cz2_r + 1i * cz2_i;
        cz = sqrt(cz2/cz);
    end
    
    %hint.cf(i) = cz/hint.nfft; 
    hint.cf(i) = cz; 
end


