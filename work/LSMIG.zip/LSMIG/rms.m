function out=rms(in)

    in=in(:);
    n = numel(in);
    out = sqrt(1/n*(in'*in) ) * 3;