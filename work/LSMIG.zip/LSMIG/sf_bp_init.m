function sf_bp_init(f1,f2,f3,f4,dt,nt)

global bp

w1 = pi * f1 / pi;
w2 = pi * f2 / pi;
w3 = pi * f3 / pi;
w4 = pi * f4 / pi;

A = w4^2/(w4-w3);
B = w3^2/(w4-w3);
C = w2^2/(w2-w1);
D = w1^2/(w2-w1);

ABCD = A - B - C + D;

bp.nt=nt;
bp.dt=dt;
flt_t = zeros(nt,1);
t0=(bp.nt+1)/2*bp.dt;


for it=1:bp.nt
    
    t=it*bp.dt;
    t1=t-t0;
    
    %broadband ormbsy wavelet
    wlt =( + A * ( sinc(w4*t1))^2 ...
        - B * ( sinc(w3*t1))^2 ...
        - C * ( sinc(w2*t1))^2 ...
        + D * ( sinc(w1*t1))^2 ...
        ) /ABCD;
    flt_t(it) = flt_t(it)+wlt;
    
    
end % loop over trace samples

bp.nfft=2^nextpow2(bp.nt);
bp.nw = bp.nfft/2+1;

bp.flt=fft(flt_t,bp.nfft);
bp.flt=bp.flt(1:bp.nw,:);
MASK=[1;2*ones(bp.nw-2,1);1];
bp.flt=abs(bp.flt).*MASK;

%
%plot([0:bp.nw-1]/bp.nw/2/bp.dt,bp.flt)