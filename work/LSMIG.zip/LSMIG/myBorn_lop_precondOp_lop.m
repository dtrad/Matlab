function out=myBorn_lop_precondOp_lop(adj,nout,nin,in)

global myBorn_lop


out = myBorn_lop.precondOp.*in;