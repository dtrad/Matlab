%%  triangle_init
function tr = triangle_init(nbox,ndat) 
    
    tr.nx = ndat;
    tr.nb = nbox;
    tr.np = ndat + 2 * nbox;
    tr.tmp = zeros(tr.np,1);

end