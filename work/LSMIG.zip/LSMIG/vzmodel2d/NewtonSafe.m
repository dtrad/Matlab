function [rts] = NewtonSafe(FunFcnIn,x0,x1,x2,tol)

verb=0;
NITER = 100;
fl = feval(FunFcnIn,x1);
fh = feval(FunFcnIn,x2);

if ( (fl > 0.0 && fh > 0.0) || (fl<0.0 && fh <0.0) )
   disp(['Error: root must be bracketed in x=[xl,xh] f(xl)=',num2str(fl),'(xh)=',num2str(fh)])
   rts = NaN;
   return
end

if (fl == 0)
    rts = x1;
end

if (fh == 0)
    rts = x2;
end

if (fl < 0.0)
    xl = x1;
    xh = x2;
else
    xl = x2;
    xh = x1;
end

rts = x0;
dxold = abs(x2-x1);
dx = dxold;

[f,df] = feval(FunFcnIn,rts);

for j=1:NITER
    if ((((rts-xh)*df-f)*((rts-xl)*df-f) > 0.0) ...
            || (abs(2.0*f) > abs(dxold*df)))
        dxold=dx;
        dx=0.5*(xh-xl);
        rts=xl+dx;
        if (xl == rts)
            return
        end
        
        if (verb) disp(['iter= ',num2str(j),' f= ',num2str(f),' df= ',num2str(df), ' x= ',num2str(rts)])
        end
    else
        dxold=dx;
        dx=f/df;
        
        
        temp=rts;
        rts = rts - dx;
        
        if (verb) disp(['iter= ',num2str(j),' f= ',num2str(f),' df= ',num2str(df), ' x= ',num2str(rts)])
        end
        if (temp == rts)
            return;
        end
    end
    if (abs(dx) < tol)
        return
    end
    
    [f,df] = feval(FunFcnIn,rts);
    if (f < 0.0)
        xl=rts;
    else
        xh=rts;
    end
    
end

disp('Maximum number of iterations exceeded in NewtonSafe');


    


    
