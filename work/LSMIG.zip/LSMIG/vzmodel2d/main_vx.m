%% PP and PS-wave raytracing in V(x) = V0+ ax * x models

clc, close all, clear all
%warning off;
addpath('C:\Users\lcasasan\Documents\MATLAB\src\OPTIMIZED')

%% layers definition
% parameters = [ Vpo_1 Vso_1 epsilon_1 delta_1 incl_asse_1 rho1; ...
%                Vpo_n Vso_n epsilon_n delta_n incl_asse_n rho_n];

z0 = [1500];
dip = 1e-3;kdip=tand(dip);

%--------- Isotropic single layer (Rosales)
vP0(1) = 1700;   axP=+0.15;
vS0(1) =  300;   axS=+0.35;

%--------- Isotropic single layer (Rosales)
%vP0(1) = 1500;   axP=+0.0;
%vS0(1) =  385;   axS=-0.0;

epsi(1)=  .0;
del(1)=   .0;
ti(1) = 0;
rho(1)=1000;


parameters = [vP0(:),vS0(:),epsi(:),del(:),ti(:),rho(:)];
reflectors = [z0(:),kdip, zeros(numel(z0(:)),4), 1 ];

%% aquisition geometry
m = 2500;
h_min = -500; h_max = 500; dh = 12.5; %half offset
h = [h_min:dh:h_max]'
%h = [h_min:dh:h_max]'/2000;
h2 = 2 * h;
xs = m - h;
xr = m + h;
zs = 0.0;
zr = 0.0;
geometry = [xs,zeros(size(xs)),zs*ones(size(xs)),xr,zeros(size(xr)),zr*ones(size(xr))];

%% straight rays computation (reference)
[tpp,xpp,zpp]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PP');
[tps,xps,zps]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PS');


%% kdir

ztest_v0 = z0 + kdip * ( -vP0(1)/axP) ;
ZMAX = 10000;ZMIN=0;
if (axP>0)
    z_test_min = ceil(max(ZMIN,ztest_v0*1.1));
    z_test_max = ZMAX; 
else
    z_test_min = ZMIN;
    z_test_max = floor(min(10000,ztest_v0*.9));
end
    

z_test=[z_test_min:z_test_max];
jdip = 1/kdip;
x_test_z = (z_test-z0)*jdip;



%% V(x) ray tracing

tpp0_vx   = zeros(size(h));  
raypp0_vx = zeros(size(h));  

tpp1_vx    = zeros(size(h)); tps1_vx    = zeros(size(h));
zpp1_RP_vx = zeros(size(h)); zps1_CP_vx = zeros(size(h));  
xpp1_RP_vx = zeros(size(h)); xps1_CP_vx = zeros(size(h));

tpp2_vx    = zeros(size(h)); tps2_vx    = zeros(size(h));
zpp2_RP_vx = zeros(size(h)); zps2_CP_vx = zeros(size(h));  
xpp2_RP_vx = zeros(size(h)); xps2_CP_vx = zeros(size(h));

tpp_vx    = zeros(size(h)); tps_vx    = zeros(size(h));
zpp_RP_vx = zeros(size(h)); zps_CP_vx = zeros(size(h));  
xpp_RP_vx = zeros(size(h)); xps_CP_vx = zeros(size(h));

polpp_vx= zeros(size(h));
polps_vx= zeros(size(h));
%raypp1  = zeros(size(h));  
tol = 1e-6;
%%
%for ih=21
for ih=1:numel(h)
  
   shtx = xs(ih); recx=xr(ih);
   xRP_0 = (shtx+recx)/2.0;
   % optimization using gauss-newton PS
   gamma0 = vP0/vS0;
   xCP_0 = shtx + h2(ih) * (gamma0)/(gamma0+1);
   
   if kdip==0
        zRP_0 = z0;
        zCP_0 = z0;
   else
        zRP_0 = z0 + kdip * xRP_0;
        zCP_0 = z0 + kdip * xCP_0;
   end
   
   
%    x1=max(shtx,recx);
%    x2=min(shtx,recx);
%    v=vP0(1)+axP*x2;   
%    tpp0_vx(ih) = vzmodel2d_d2t(2*z0,x1-x2,v,axP);
%    raypp0_vx(ih) =  vzmodel2d_calcp(2*z0,x1-x2,v,axP);
    
   % optimization using simplex method fminsearch
   % pp 
%    [zpp1_RP_vx(ih)] = ...
%    fminsearch(@(z) vzmodel2d_tway_time_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip),zRP_0); 
%    [tpp1_vx(ih),xpp1_RP_vx(ih)] = vzmodel2d_tway_time_vx(zpp1_RP_vx(ih),shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip);
%    % ps 
%    [zps1_CP_vx(ih)] = ...
%    fminsearch(@(z) vzmodel2d_tway_time_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip),zCP_0); 
%    [tps1_vx(ih),xps1_CP_vx(ih)] = vzmodel2d_tway_time_vx(zps1_CP_vx(ih),shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip);
   
   
   % function test 
%      x_test = [0:10000]; % you need to scale first and second der by kdip and kdip^2
%      z_test =  z0 + (kdip+1e-6) * x_test; 
%      %z_test = [0:10000];
%      %x_test = [z_test-z0]/kdip;
%      %%%% pp
%      tpp_test    = vzmodel2d_tway_time_vx_test(z_test,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip);
%      % I SAY dtdppdz HOWEVER IS STILL THE RAY PARAMETER ALONG THE REFLECTOR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%      [dtppdz_test,d2tppdz2_test] = vzmodel2d_tway_timedz_vx_test(z_test,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip);
%      %%%% ps
%      tps_test    = vzmodel2d_tway_time_vx_test(z_test,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip);
%      [dtpsdz_test,d2tpsdz2_test] = vzmodel2d_tway_timedz_vx_test(z_test,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip);
% 
%      figure('name','functional test')
%      subplot(321);plot(x_test,tpp_test); hold on; plot(xpp(ih),tpp(ih),'bs');title('PP')
%      set(gca,'Xlim',[x_test(1),x_test(end)])
%      subplot(322);plot(x_test,tps_test); hold on; plot(xps(ih),tps(ih),'bs');title('PP')
%      set(gca,'Xlim',[x_test(1),x_test(end)])
%      %%%% dtdx pp
%      subplot(323);plot(x_test(1:end-1),diff(tpp_test)); hold on; plot(xpp(ih),0,'bs');hold on;
%                   plot(x_test,dtppdz_test,'r--'); 
%      set(gca,'ygrid','on','Xlim',[x_test(1),x_test(end)])
% 
%      %%%% dtdx ps
%      subplot(324);plot(x_test(1:end-1),diff(tps_test)); hold on; plot(xps(ih),0,'bs');hold on;
%                   plot(x_test,dtpsdz_test,'r--');
%      set(gca,'ygrid','on','Xlim',[x_test(1),x_test(end)])
%      %%%% d2tdz2 pp
%      subplot(325);plot(z_test(1:end-2),diff(diff(tpp_test))); hold on; 
%                   plot(z_test,d2tppdz2_test,'r--'); hold on;
%      set(gca,'ygrid','on','Xlim',[z_test(1),z_test(end)])
%      %%%% d2tdz2 ps
%      subplot(326);plot(z_test(1:end-2),diff(diff(tps_test))); hold on; 
%                   plot(z_test,d2tpsdz2_test,'r'); hold on;
%      set(gca,'ygrid','on','Xlim',[z_test(1),z_test(end)])
     
   % optimization using fzero
   %pp
   [zpp2_RP_vx(ih)] = ...
       fzero(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip),zRP_0);
   [tpp2_vx(ih),xpp2_RP_vx(ih)] = vzmodel2d_tway_time_vx(zpp2_RP_vx(ih),shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip,'PP');
   %ps
   [zps2_CP_vx(ih)] = ...
       fzero(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip),zCP_0);
   [tps2_vx(ih),xps2_CP_vx(ih)] = vzmodel2d_tway_time_vx(zps2_CP_vx(ih),shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS');
   
   
   % optimization using gauss-newton PP
    %[x] = NewtonSafe(@(xc) funcCcp_z(xc,Ds,Dr,gamma0_avg(ilayer)),x0,0.0,1.0,tol);
  
    xRP_0 = (shtx+recx)/2.0;    
    if kdip==0
        zRP_0 = z0;
        zRP_min = zRP_0 - 100.0;
        zRP_max = zRP_0 + 100.0;
    else
        zRP_0 = z0 + kdip * xRP_0;
        zRP_pve = zRP_0 + kdip * max(h2);
        zRP_nve = zRP_0 - kdip * max(h2);
        zRP_v0 = z0 + kdip * (-vP0(1)/axP+1e-6);
        
        zRP_min = min (zRP_pve,zRP_nve);
        zRP_max = max (zRP_pve,zRP_nve);
        
        if (axP>0)            
            if (kdip>0)
                zRP_min = ceil(max(zRP_min,zRP_v0*1.0001));   
            else
                zRP_max = floor(min(zRP_max,zRP_v0*.9999));
            end
        elseif (axP<0)
            if (kip>0)
                zRP_max = floor(min(zRP_max,zRP_v0*.9999));
            else
                zRP_min = ceil(max(zRP_min,zRP_v0*1.0001));   
            end
        end
        
    end
    % reflection point (RP)
    shtz = z0 + kdip * shtx;
    recz = z0 + kdip * recx;
    
    if (shtz<zRP_min) || (shtz>zRP_max) || (recz<zRP_min) || (recz>zRP_max)
        disp(['shot or receiver velocity is negative vsht=',num2str(vP0(1)+axP*shtx),...
                                                    'xrec=',num2str(vP0(1)+axP*recx)]);
        zpp_RP_vx(ih) = NaN;
        xpp_RP_vx(ih) = NaN;
        tpp_vx(ih)    = NaN;
        
    else
        %[zpp_RP_vx(ih)] = ...
        %    NewtonSafe(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip), ...
        %    zRP_0,zRP_min,zRP_max,tol);
        [zpp_RP_vx(ih)] = ...
            NewtonSafe(@(z) vzmodel2d_tway_timedx_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip), ...
            zRP_0,zRP_min,zRP_max,tol);
        % traveltimes
        [tpp_vx(ih),xpp_RP_vx(ih),polpp_vx(ih)] = vzmodel2d_tway_time_vx(zpp_RP_vx(ih),shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip,'PP');
    end
    
    
    % optimization using gauss-newton PS
    gamma0 = vP0/vS0;
    xCP_0 = shtx + h2(ih) * (gamma0)/(gamma0+1);    
    if kdip==0
        zCP_0 = z0;
        zCP_min = zRP_0 - 100.0;
        zCP_max = zRP_0 + 100.0;
    else
        zCP_0 = z0 + kdip * xCP_0;
        zCP_pve = zCP_0 + kdip * max(h2);
        zCP_nve = zCP_0 - kdip * max(h2);
        zCP_vP0 = max(z0 + kdip * (-vP0(1)/(axP+1e-6)),0);
        zCP_vS0 = max(z0 + kdip * (-vS0(1)/(axS+1e-6)),0);

        zCP_min = min (zCP_pve,zCP_nve);
        zCP_max = max (zCP_pve,zCP_nve);
        zCP_v0_min = max(zCP_vP0,zCP_vS0);
        zCP_v0_max = min(zCP_vP0,zCP_vS0);
        
        if (axP*axS > 0)
            if (axP>0)
                if (kdip>0)
                    zCP_min = ceil(max(zCP_min,zCP_v0_min*1.0001)); 
                else
                    zCP_max = ceil(min(zCP_max,zCP_v0_max*0.9999));
                end
            else 
                if (kdip>0)
                    zCP_max = ceil(min(zCP_max,zCP_v0_max*0.9999));
                else
                    zCP_min = ceil(max(zCP_min,zCP_v0_min*1.0001)); 
                end
            end
               
        elseif (axP*axS < 0)
            zCP_min = ceil(max(zCP_min,zCP_v0_min*1.0001));   
            zCP_max = ceil(min(zCP_max,zCP_v0_max*0.9999));   
            
        end
    
    end
    
    if (shtz<zRP_min) || (shtz>zRP_max) || (recz<zCP_min) || (recz>zCP_max)
        disp(['shot or receiver velocity is negative vsht=',num2str(vP0(1)+axP*shtx),...
                                                   ' xrec=',num2str(vS0(1)+axS*recx)]);
        zps_CP_vx(ih) = NaN;
        xps_CP_vx(ih) = NaN;
        tps_vx(ih)    = NaN;
        
    else
    [zps_CP_vx(ih)] = ...
        NewtonSafe(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip), ...
        zCP_0,zCP_min,zCP_max,tol);
    
    [tps_vx(ih),xps_CP_vx(ih),polps_vx(ih)] = vzmodel2d_tway_time_vx(zps_CP_vx(ih),shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS');
    end
end

%% plot (traveltime)
figure('name','traveltime comparison')
set(gca,'ydir','reverse')
subplot(121)
plot(h,tpp,'b-.','linewidth',2.0); hold on
plot(h,tpp2_vx,'r-x','linewidth',2.0); hold on
plot(h,tpp_vx,'g-o','linewidth',2.0); hold on

set(gca','Ylim',[0 max([tpp(:);tps(:)])],'Ydir','reverse')
title('PP')
%plot
subplot(122)
plot(h,tps,'b-.','linewidth',2.0); hold on
plot(h,tps2_vx,'r-x','linewidth',2.0); hold on
plot(h,tps_vx,'g-o','linewidth',2.0); hold on
set(gca','Ylim',[0 max([tpp(:);tps(:)])],'Ydir','reverse')
title('PS')

%% plot (RP and CP)
figure('name','reflection point')
set(gca,'ydir','reverse')
subplot(121)
plot(h,xpp,'b-.','linewidth',2.0); hold on
plot(h,xpp2_RP_vx,'r-o','linewidth',2.0); 
plot(h,xpp_RP_vx,'g-s','linewidth',2.0); 

title('PP')
%plot
subplot(122)
plot(h,xps,'b-.','linewidth',2.0); hold on
plot(h,xps2_CP_vx,'r-o','linewidth',2.0); hold on
plot(h,xps_CP_vx,'g-s','linewidth',2.0); 

title('PS')

%% plot polarity sinsht*cosrec
figure('name','polarity change vs offset')
subplot(121)
%polpp_vx(find(imag(polpp_vx))) = - imag(polpp_vx(find(imag(polpp_vx))));
plot(h,polpp_vx,'k','linewidth',2.0); hold on
plot(h,ones(size(h)),'k'); 
set(gca,'Ylim',[0;2],'Xgrid','on')
title('PP')

subplot(122)
%polps_vx(find(imag(polps_vx))) = - imag(polps_vx(find(imag(polps_vx))));

plot(h,polps_vx,'k','linewidth',2.0); hold on
plot(h,zeros(size(h)),'k'); 
set(gca,'Ylim',[-1;1],'Xgrid','on')
title('PS')



