function [dtdx,d2tdx2] = vzmodel2d_tway_timedx(x,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip)

 
z = z0 + kdip * x;
%traveltime derivatives with respect to the reflecting point z(x)
dtshtdx=vzmodel2d_calctimedx(x-shtx,z,v0_dw,az_dw,kdip);
dtrecdx=vzmodel2d_calctimedx(x-recx,z,v0_up,az_up,kdip);
dtdx = dtshtdx+dtrecdx;

d2tshtdx2=vzmodel2d_calctimedx2(x-shtx,z,v0_dw,az_dw,kdip);
d2trecdx2=vzmodel2d_calctimedx2(x-recx,z,v0_up,az_up,kdip);
d2tdx2 = d2tshtdx2+d2trecdx2;
end

function [dtdx] = vzmodel2d_calctimedx(x,z,v0,av,kdip)

sml=1.e-6;
lrg=1.e+6;

r = sqrt(x.^2+z.^2);
v=v0+av*z;

%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml)
        if(abs(av)>sml)
            %t = 1./av * arcosh(1+ (av.^2 * r.^2) ./ (2 .* v0 .* v));  
            W = sqrt(4.*v0.*v.*r.^2 + av^2*r.^4);          
            dtdx = 1./W.*(2.*x + kdip.*(2.*z - av./v.*r.^2)); 
        else
            
            %t = sqrt(r.^2/v0^2);
            W = sqrt(4.*v0.*v0.*r.^2); 
            dtdx =  1./W.*(2.*x + kdip.*(2.*z)); 
        end
    else
        dtdx = lrg;
        disp(['v=',num2str(v),'z=',num2str(z)])
    end

    return
end


function [d2tdx2] = vzmodel2d_calctimedx2(x,z,v0,av,kdip)

sml=1.e-6;
lrg=1.e+6;

r = sqrt(x.^2+z.^2);
dr2dx = 2*( x + z * kdip);
dr4dx = 2*r.^2.*dr2dx;
v=v0+av*z;

%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml)
        if(abs(av)>sml)
            
            N = (2.*x + kdip.*(2.*z - av./v.*r.^2));
            dNdx = 2 + kdip .* ( kdip * (2+r.^2*av^2./v.^2) - av./v.*dr2dx);
            W = sqrt(4.*v0.*v.*r.^2 + av^2*r.^4);
            F = 4*v0*(av*kdip*r.^2+v.*dr2dx) + av^2 .* dr4dx;            
            d2tdx2 = dNdx./W - N./2./W.^3.*F;
        else
            N = (2.*x + kdip.*(2.*z));
            dNdx = 2 .* (1 + kdip^2);           
            W = sqrt(4.*v0.*v0.*r.^2); 
            F = 4.*v0.*v0*dr2dx;
            d2tdx2 = dNdx./W - N./2./W.^3.*F; 
        end
    else
        d2tdx2 = lrg;
        
    end

    return
end



