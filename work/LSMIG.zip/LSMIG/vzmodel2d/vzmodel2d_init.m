function  my = vzmodel2d_init()

% my.tmax     = [];
% my.srate    = [];
% my.nt       = [];
% my.dx       = [];
% my.dz       = [];
% my.fcross   = [];
% my.lcross   = [];
% 
% my.ns       = 1;
% my.shotx    = [];
% my.shoty    = [];
% my.frecx    = [];
% my.lrecx    = [];
% my.ds       = 0;
% 
% my.v0P      = [];
% my.axP      = 0;
% my.azP      = 0;
% my.v0S      = [];
% my.axS      = 0;
% my.azS      = 0;
% 
% my.IsBbwlt = 0; %apply broadband
% my.IsSprd  = 0; %apply polarity
% my.IsPlrty = 0; %apply polarity
% my.fpeak    = [];
% 
% my.f1      = [];
% my.f2      = [];
% my.f3      = [];
% my.f4      = [];
% 
% my.dim      = 2;
% my.ndep     = [];
% my.z0s      = [];
% my.angles   = [];
% 
% my.maxit    = 100;
% my.tol      = 1e-6;

my.tmax     = [];
my.srate    = [];
my.nt       = [];
my.dx       = [];
my.dz       = [];
my.fcross   = [];
my.lcross   = [];

my.ns       = 1;
my.shotx    = [];
my.shoty    = [];
my.frecx    = [];
my.lrecx    = [];
my.ds       = 0;

my.v0P      = [];
my.axP      = 0;
my.azP      = 0;
my.v0S      = [];
my.axS      = 0;
my.azS      = 0;

my.IsBbwlt = 0; %apply broadband
my.IsSprd  = 0; %apply polarity
my.IsPlrty = 0; %apply polarity
my.fpeak    = [];

my.f1      = [];
my.f2      = [];
my.f3      = [];
my.f4      = [];

my.dim      = 2;
my.ndep     = [];
my.z0s      = [];
my.angles   = [];

my.maxit    = 100;
my.tol      = 1e-6;