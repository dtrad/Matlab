
function [t,p] = vzmodel2d_d2t(x,z0,v0,av)
    
    t = vzmodel2d_calctime(x,z0,v0,av);
    
end

function [t] = vzmodel2d_calctime(x,z,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

    v=v0+av*z;
    r = sqrt(x.*x+z.*z);
    b=(x.*x+z.*z)./(2*v0*v);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml) 
        if(abs(av)>sml) 
            %t = 1./av * acosh(1+ (av.^2 * r.^2) ./ (2 .* v0 .* v));
            t = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb.*avb));
        else
            t = avb + sqrt(2*b+avb.*avb);
        end
    else
       t=lrg;
    end

    return 
end


