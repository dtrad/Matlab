function [rayp] = vzmodel2d_calcp(x,z,v0,av)

    t = vzmodel2d_calctime(x,z,v0,av);    
    
    sml=1.e-6;
    if(abs(av)>sml) 
        if(x+1.0==1.0) 
            rayp=0.0;
        else
            a=exp(av*t);
            c=a*a-1.0;
            d=a*av*x;
            tmp = max(v0*v0*c*c-4*d*d,0.0);
            if(tmp>=0.0) 
                tau0=2*av*x/(v0*c+sqrt(tmp));
                ang0=2*atan(tau0);
                rayp=sin(ang0)/v0;
            else
                rayp=0.0;
            end
        end
    else
        rayp=x/(v0*t*v0);
    end

    return
end


function [t] = vzmodel2d_calctime(x,z,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

    v=v0+av*z;
    b=(x.*x+z.*z)./(2*v0*v);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml) 
        if(abs(av)>sml) 
            t = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb.*avb));
        else
            t = avb + sqrt(2*b+avb.*avb);
        end
    else
       t=lrg;
    end

    return 
end