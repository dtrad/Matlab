%% PP and PS-wave raytracing in V(x) = V0+ ax * x models

clc, close all, clear all
%warning off;
addpath('C:\Users\lcasasan\Documents\MATLAB\src\OPTIMIZED')

%% layers definition
% parameters = [ Vpo_1 Vso_1 epsilon_1 delta_1 incl_asse_1 rho1; ...
%                Vpo_n Vso_n epsilon_n delta_n incl_asse_n rho_n];

z0 = [0.1];
dip = 15;kdip=tand(dip);
%z0 = 1500
%kdip=1e-3;


%--------- Isotropic single layer (Rosales)
vP0(1) = 1700;   axP=+0.15;
vS0(1) =  300;   axS=+0.35;

%--------- Isotropic single layer (Rosales)
%vP0(1) = 1500;   axP=+0.0;
%vS0(1) =  385;   axS=-0.0;

epsi(1)=  .0;
del(1)=   .0;
ti(1) = 0;
rho(1)=1000;


parameters = [vP0(:),vS0(:),epsi(:),del(:),ti(:),rho(:)];
reflectors = [z0(:),kdip, zeros(numel(z0(:)),4), 1 ];

%% aquisition geometry
m = 2500;xs=2000;
h_min = -2000; h_max = 2000; dh = 50; %half offset
h = [h_min:dh:h_max]';
%h = [h_min:dh:h_max]'/2000;
h2 = 2 * h;
%xs = m - h;
%xr = m + h;
xs = xs*ones(size(h));
xr = xs+2*h;
m = (xs+xr)/2.0;
zs = 0.0;
zr = 0.0;
geometry = [xs,zeros(size(xs)),zs*ones(size(xs)),xr,zeros(size(xr)),zr*ones(size(xr))];

%% straight rays computation (reference)
[tpp,xpp,zpp]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PP');
[tps,xps,zps]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PS');


%% kdir

ztest_v0 = z0 + kdip * ( -vP0(1)/axP) ;
ZMAX = 10000;ZMIN=0;
if (axP>0)
    z_test_min = ceil(max(ZMIN,ztest_v0*1.1));
    z_test_max = ZMAX; 
else
    z_test_min = ZMIN;
    z_test_max = floor(min(10000,ztest_v0*.9));
end
    

z_test=[z_test_min:z_test_max];
jdip = 1/kdip;
x_test_z = (z_test-z0)*jdip;



%% V(x) ray tracing

tpp0_vx   = zeros(size(h));  
raypp0_vx = zeros(size(h));  

tpp1_vx    = zeros(size(h)); tps1_vx    = zeros(size(h));
zpp1_RP_vx = zeros(size(h)); zps1_CP_vx = zeros(size(h));  
xpp1_RP_vx = zeros(size(h)); xps1_CP_vx = zeros(size(h));

tpp2_vx    = zeros(size(h)); tps2_vx    = zeros(size(h));
zpp2_RP_vx = zeros(size(h)); zps2_CP_vx = zeros(size(h));  
xpp2_RP_vx = zeros(size(h)); xps2_CP_vx = zeros(size(h));

tpp_vx    = zeros(size(h)); tps_vx    = zeros(size(h));
zpp_RP_vx = zeros(size(h)); zps_CP_vx = zeros(size(h));  
xpp_RP_vx = zeros(size(h)); xps_CP_vx = zeros(size(h));

polpp_vx= zeros(size(h));
polps_vx= zeros(size(h));
%raypp1  = zeros(size(h));  
tol = 1e-6;
%%


%%
for ih=1:numel(h)
  
   shtx = xs(ih); recx=xr(ih);
   xRP_0 = (shtx+recx)/2.0;
   % optimization using gauss-newton PS
   gamma0 = vP0/vS0;
   xCP_0 = shtx + h2(ih) * (gamma0)/(gamma0+1);
    
   if kdip==0
        zRP_0 = z0;
        zCP_0 = z0;
   else
        zRP_0 = z0 + kdip * xRP_0;
        zCP_0 = z0 + kdip * xCP_0;
   end
   
   % optimization using fzero
   %pp
   [zpp2_RP_vx(ih)] = ...
       fzero(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip),zRP_0);
   [tpp2_vx(ih),xpp2_RP_vx(ih)] = vzmodel2d_tway_time_vx(zpp2_RP_vx(ih),shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip,'PP');
   %ps
   [zps2_CP_vx(ih)] = ...
       fzero(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip),zCP_0);
   [tps2_vx(ih),xps2_CP_vx(ih)] = vzmodel2d_tway_time_vx(zps2_CP_vx(ih),shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS');
   
   
%    %optimization using gauss-newton PP

    xdip = -z0/(kdip);
    xvel = -vP0(1)/(axP+1e-6);
    zvel =  z0+kdip*(-vP0(1)/(axP+1e-6));
    xvelS = -vS0(1)/(axS+1e-6);
    zvelS = z0+kdip*(-vS0(1)/(axS+1e-6));
    if((xdip-shtx)*(xdip-recx)> 0.0) && ((xvel-shtx)*(xvel-recx)> 0.0) 
    
    az=z0 + kdip * (shtx+recx)/2.0;
    %bz=z0 + kdip * xdip
    bz=zvel;
    [az,bz,cz,fa,fb,fc] = mnbrak(@(z) vzmodel2d_tway_time_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip,'PP'),az,bz);       
        
        %[zpp_RP_vx(ih)] = ...
        %    NewtonSafe(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip), ...
        %    zRP_0,zRP_min,zRP_max,tol);
        [zpp_RP_vx(ih)] = ...
            NewtonSafe(@(z) vzmodel2d_tway_timedx_vx(z,shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip), ...
            zRP_0,az,cz,tol);
        % traveltimes
        [tpp_vx(ih),xpp_RP_vx(ih),polpp_vx(ih)] = vzmodel2d_tway_time_vx(zpp_RP_vx(ih),shtx,recx,vP0(1),axP,vP0(1),axP,z0,kdip,'PP');
    end
    
    
%     % optimization using gauss-newton PS

    if((xdip-shtx)  * (xdip-recx)> 0.0) && ...
      ((xvel-shtx)  * (xvel-recx)> 0.0) && ...
      ((xvelS-shtx) * (xvelS-recx)> 0.0)
    
    az=z0 + kdip * (shtx+recx)/2.0;
    bz=max(zvel,zvelS);
    
   % ftmp = vzmodel2d_tway_time_vx(bz,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS');
   % [dftmp,dftmp2] = vzmodel2d_tway_timedz_vx(bz,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip)
    
    [az,bz,cz,fa,fb,fc] = mnbrak(@(z) vzmodel2d_tway_time_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS'),az,bz);       
  
    
    
    [zps_CP_vx(ih)] = ...
        NewtonSafe(@(z) vzmodel2d_tway_timedz_vx(z,shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip), ...
        (az+cz)/2,az,cz,tol);
    
    [tps_vx(ih),xps_CP_vx(ih),polps_vx(ih)] = vzmodel2d_tway_time_vx(zps_CP_vx(ih),shtx,recx,vP0(1),axP,vS0(1),axS,z0,kdip,'PS');
    end
end

%% plot (traveltime)
figure('name','traveltime comparison')
set(gca,'ydir','reverse')
subplot(121)
plot(h,tpp,'b-.','linewidth',2.0); hold on
plot(h,tpp2_vx,'r-x','linewidth',2.0); hold on
plot(h,tpp_vx,'g-o','linewidth',2.0); hold on

set(gca','Ylim',[0 max([tpp(:);tps(:)])],'Ydir','reverse')
title('PP')
%plot
subplot(122)
plot(h,tps,'b-.','linewidth',2.0); hold on
plot(h,tps2_vx,'r-x','linewidth',2.0); hold on
plot(h,tps_vx,'g-o','linewidth',2.0); hold on
set(gca','Ylim',[0 max([tpp(:);tps(:)])],'Ydir','reverse')
title('PS')

%% plot (RP and CP)
figure('name','reflection point')
set(gca,'ydir','reverse')
subplot(121)
plot(h,xpp,'b-.','linewidth',2.0); hold on
plot(h,xpp2_RP_vx,'r-o','linewidth',2.0); 
plot(h,xpp_RP_vx,'g-s','linewidth',2.0); 

title('PP')
%plot
subplot(122)
plot(h,xps,'b-.','linewidth',2.0); hold on
plot(h,xps2_CP_vx,'r-o','linewidth',2.0); hold on
plot(h,xps_CP_vx,'g-s','linewidth',2.0); 

title('PS')

%% plot polarity sinsht*cosrec
figure('name','polarity change vs offset')
subplot(121)
%polpp_vx(find(imag(polpp_vx))) = - imag(polpp_vx(find(imag(polpp_vx))));
plot(h,polpp_vx,'k','linewidth',2.0); hold on
plot(h,ones(size(h)),'k'); 
set(gca,'Ylim',[0;2],'Xgrid','on')
title('PP')

subplot(122)
%polps_vx(find(imag(polps_vx))) = - imag(polps_vx(find(imag(polps_vx))));

plot(h,polps_vx,'k','linewidth',2.0); hold on
plot(h,zeros(size(h)),'k'); 
set(gca,'Ylim',[-1;1],'Xgrid','on')
title('PS')



