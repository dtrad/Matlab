function [dtdx] = vzmodel2d_tway_timedx_old(x,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip)


z = z0 + kdip * x;
%traveltime derivatives with respect to the reflecting point z(x)
dtshtdx=vzmodel2d_calctimedx(x-shtx,z,v0_dw,az_dw,kdip);
dtrecdx=vzmodel2d_calctimedx(x-recx,z,v0_up,az_up,kdip);
dtdx = dtshtdx+dtrecdx;

end

function [dtdx] = vzmodel2d_calctimedx(x,z,v0,av,kdip)

sml=1.e-6;
lrg=1.e+6;

v=v0+av*z;
b=(x.*x+z.*z)./(2*v0*v);

avb =av*b;


%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml)
        if(abs(av)>sml)
            %%%% t = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb*avb));
            dbdx = (2*x+2*z*kdip)./(2*v0*v) - b*av*kdip./v ;
            f    = (1+av*avb    )+  av*sqrt(2*b+avb.*avb);
            dfdx = (av*av*dbdx + (av*(dbdx+avb.*av.*dbdx) ./ sqrt(2*b+avb.*avb))  );
            dtdx = (1.0/av)*(1.0./f).*dfdx;
        else
            %%%%    t = avb + sqrt(2*b+avb*avb);
            dbdx=(2*x+2*z*kdip)./(2*v0*v);
            dtdx = av*dbdx + (dbdx+avb.*av.*dbdx) ./ sqrt(2*b+avb.*avb);
        end
    else
        dtdx = lrg;
    end

    return
end


