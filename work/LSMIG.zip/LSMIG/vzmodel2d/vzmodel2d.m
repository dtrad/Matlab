function [traces] = vzmodel2d(my)

if (my.IsBbwlt) % braod band ormbsy wavelet
    w1 = pi * my.f1;
    w2 = pi * my.f2;
    w3 = pi * my.f3;
    w4 = pi * my.f4;
    
    A = w4^2/(w4-w3);
    B = w3^2/(w4-w3);
    C = w2^2/(w2-w1);
    D = w1^2/(w2-w1);
    
    ABCD = A - B - C + D;
else % narrow band ricker wavelet
    
    wpeak = 2*pi*my.fpeak;
    apeak=wpeak*wpeak*0.25;
end

tol = my.tol;
nin = my.nin;
nt  = my.nt;
ndep = my.ndep;

traces = zeros(nt,nin);

cdpxs = zeros(nin,1);
shotxs  = zeros(nin,1);
recxs = zeros(nin,1);
for in=1:nin
    
    ixl = my.fcross + in - 1;
    cdpxs(in) = (ixl -1) * my.dx;
    shotxs(in)	= my.fshotx;
    hx = (cdpxs(in)-shotxs(in))*2.0;
    recxs(in)	= shotxs(in) + hx;
    
    for idep=1:ndep
        z0   = my.z0s(idep);
        dip = my.angles(idep)/180*pi;
        kdip = tan(dip);
        %------- reflection point (RP)
        a=cdpxs(in);
        if (kdip==0)
            b=(my.fcross-1)*my.dx;
        else
            b=-z0/kdip;
        end
        [a,b,c] = mnbrak(@(x) vzmodel2d_tway_time(x,shotxs(in),recxs(in),...
            my.v0P, my.azP, ...
            my.v0P, my.azP, ...
            z0,kdip,'PP'),a,b);
        
        [ximg] = ...
            NewtonSafe(@(x) vzmodel2d_tway_timedx(x,shotxs(in),recxs(in),...
            my.v0P, my.azP, ...
            my.v0P, my.azP, ...
            z0,kdip), ...
            (a+c)/2,a,c,tol);
        
        zimg = z0 + kdip * ximg;
        
        %------- traveltimes
        [t0,polarity] = vzmodel2d_tway_time(ximg,shotxs(in),recxs(in),...
            my.v0P, my.azP, ...
            my.v0P, my.azP, ...
            z0,kdip,'PP');
        if (~my.IsPlrty)
            polarity=1;
        end
        %------- geometrical spreading
        sprd=1;
        if (my.IsSprd)
            sprd=vzmodel2d_dipdivg(shotxs(in),recxs(in),...
            my.v0P, my.azP, ...
            my.v0P, my.azP, ...
                zimg,ximg,my.dim);
        end
        for it=1:nt
            
            t=it*my.srate/1e3;
            t1=t-t0;
            wlt=0.0;
            if (my.IsBbwlt) %% broadband ormbsy wavelet
                wlt =( + A * ( sinc(w4*t1))^2 ...
                    - B * ( sinc(w3*t1))^2 ...
                    - C * ( sinc(w2*t1))^2 ...
                    + D * ( sinc(w1*t1))^2 ...
                    ) /ABCD*abs(sprd)*polarity;
            else % narrow band ricker wavelet
                rktmp = apeak*t1*t1;
                if(rktmp<=100)
                    wlt = (1.0-2*rktmp)*exp(-rktmp)*abs(sprd)*polarity;
                end
            end
            traces(it,in) = traces(it,in)+wlt;
            
            
        end % loop over trace samples
        
    end % loop over reflector
    
end % loop over traces




