
function [t,x,polarity] = vzmodel2d_tway_time_vx(z,shtx,recx,v0_dw,ax_dw,v0_up,ax_up,z0,kdip,wavemode)

    if(abs(kdip)<=1e-6)
        kdip=1e-8;
    end
    %z = z0 + kdip * x; 
    jdip = 1/kdip;
    x = (z-z0)*jdip;
    %traveltime
    tsht=vzmodel2d_calctime_vx(x,shtx,z,v0_dw,ax_dw);
    trec=vzmodel2d_calctime_vx(x,recx,z,v0_up,ax_up);
    t = tsht+trec;
    
    %polarity angle at the reflector
    v_dw = v0_dw + ax_dw * x;
    v_up = v0_up + ax_up * x;
    
    %sinsht = vzmodel2d_calctimedz_vx(x,shtx,z,v0_dw,ax_dw,jdip)*kdip*v_dw;
    %sinrec = vzmodel2d_calctimedz_vx(x,recx,z,v0_up,ax_up,jdip)*kdip*v_up;
    
    sinsht = vzmodel2d_calctimedx_vx(x,shtx,z,v0_dw,ax_dw,jdip)*v_dw;
    sinrec = vzmodel2d_calctimedx_vx(x,recx,z,v0_up,ax_up,jdip)*v_up;
    
    cossht = sqrt(1-sinsht.^2);
    cosrec = sqrt(1-sinrec.^2);
    
    if strcmp(wavemode,'PP')
        polarity = cossht*cosrec;
    elseif strcmp(wavemode,'PS')
        polarity = sinsht*cosrec;
    else
        disp('wavemode wrong! pls select PP or PS')        
    end
    
end

function [t] = vzmodel2d_calctime_vx(xE,xS,z,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

    vS=v0+av*xS;
    vE=v0+av*xE;
    x = (xE-xS);
    b=(x.*x+z.*z)./(2*vS*vE);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (vS>sml && vE>sml) 
        if(abs(av)>sml) 
            t = 1.0./av*log((1+av.*avb)+av*sqrt(2.*b+avb.*avb));
        else
            t = avb + sqrt(2*b+avb.*avb);
        end
    else
       t=lrg;
       disp(['vS(',num2str(xS),    ')=',num2str(vS),    'vE(',num2str(xE),')='    ,num2str(vE)])
    end

    return 
end

function [dtdx] = vzmodel2d_calctimedx_vx(xE,xS,z,v0,av,jdip)

sml=1.e-6;
lrg=1.e+6;


vS=v0+av*xS;
vE=v0+av*xE;
x = (xE-xS);
r = sqrt(x.^2+z.^2);
%dr2dz = 2*( jdip*x + z);

%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if ( (vS>sml) && (vE>sml) ) 
        if(abs(av)>sml)
            %t = 1./av * arcosh(1+ (av.^2 * r.^2) ./ (2 .* vS .* vE));  
            W = sqrt(4.*vS.*vE.*r.^2 + av^2*r.^4);          
            dtdz = 1./W.*(2.*z + jdip.*(2.*x - av./vE.*r.^2)); 
        else
            
            %t = sqrt(r.^2/v0^2);
            W = sqrt(4.*v0.*v0.*r.^2); 
            dtdz =  1./W.*(2.*z + jdip.*(2.*x)); 
        end
    else
        %disp(['vS=',num2str(vS),' vE=',num2str(vE)])
        dtdz = lrg;
    end

    dtdx = dtdz / jdip;
    return
end

% function [dtdz] = vzmodel2d_calctimedz_vx(xE,xS,z,v0,av,jdip)
% 
% sml=1.e-6;
% lrg=1.e+6;
% 
% 
% vS=v0+av*xS;
% vE=v0+av*xE;
% x = (xE-xS);
% r = sqrt(x.^2+z.^2);
% %dr2dz = 2*( jdip*x + z);
% 
% %    check if velocity become negative, if it's the case traveltime becomes meaningless
%     if ( (vS>sml) && (vE>sml) ) 
%         if(abs(av)>sml)
%             %t = 1./av * arcosh(1+ (av.^2 * r.^2) ./ (2 .* vS .* vE));  
%             W = sqrt(4.*vS.*vE.*r.^2 + av^2*r.^4);          
%             dtdz = 1./W.*(2.*z + jdip.*(2.*x - av./vE.*r.^2)); 
%         else
%             
%             %t = sqrt(r.^2/v0^2);
%             W = sqrt(4.*v0.*v0.*r.^2); 
%             dtdz =  1./W.*(2.*z + jdip.*(2.*x)); 
%         end
%     else
%         %disp(['vS=',num2str(vS),' vE=',num2str(vE)])
%         dtdz = lrg;
%     end
% 
%     return
% end
