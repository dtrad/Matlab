function sprd=vzmodel2d_dipdivg(shtx,recx,v0_sht,av_sht,v0_rec,av_rec,zimg,ximg,dim)

xs=ximg-shtx;
ps    = vzmodel2d_calcp(xs,zimg,v0_sht,av_sht);

%------- sht sprd,inplane,outplane
[sprds,psis,sigmas,cosang0s,cosangs] = vzmodel2d_calcdivg(xs,zimg,ps,v0_sht,av_sht,dim);

xr=ximg-recx;
pr    = vzmodel2d_calcp(xr,zimg,v0_rec,av_rec);

%------- rec sprd,inplane,outplane
[sprdr,psir,sigmar,cosang0r,cosangr] = vzmodel2d_calcdivg(xr,zimg,pr,v0_rec,av_rec,dim);

if(sprds < 0.0 || sprdr <0.0)
    sprd=0.0;
    return
end

%
v0=v0_sht;
 
if(dim==1)
    sprd=1.0;
elseif(dim==2) %------- sigmas=sigmar=1;
    sprd=2*v0/sqrt((psis*cosangs/cosangr + psir*cosangr/cosangs)*2*cosang0s*cosang0r);
elseif(dim==3)
    sprd=2*v0/sqrt((psis*cosangs/cosangr + psir*cosangr/cosangs)*(sigmas+sigmar)*cosang0s*cosang0r);
end

return
end
        
   

function [sprd,psi,sigma,cosang0,cosang] = vzmodel2d_calcdivg(x,z,p,v0,av,dim)

    v=v0+av*z;
    % p-preserves along propagation
    sinang=min(abs(p*v),1.0); %angle at the image point
    sinang0=min(abs(p*v0),1.0); %angle at the surface point

    if(dim==1) 
        cosang0=1.0;
        cosang=1.0;
        psi=1.0;
        sigma=1.0;
        sprd=1.0;
    else
        if(p+1.0~=1.0 && x+1.0~=1.0) 
            if(sinang0 <= 1.0 && sinang <= 1.0) 
                cosang=sqrt(max(1.0-sinang*sinang,1.e-7));
                cosang0=sqrt(max(1.0-sinang0*sinang0,1.e-7));
                psi=x/(p*cosang*cosang0);
                if(dim==2) 
                    sigma=1.0;
                    sprd=sqrt(p/x)*sqrt(v*v0);
                else
                    sigma=x/p;
                    sprd=p/x*sqrt(v0*v);
                end
            else
                cosang=0.0;
                cosang0=0.0;
                psi=0.0;
                sigma=0.0;
                sprd=-1.0;
            end
        else %----- p==0 || x==0 %vertical ray 
            cosang=1.0;
            cosang0=1.0;
            psi=z/2.0*(v+v0);
            if(dim==2) 
                sigma=1.0;
                sprd=sqrt(2.0/((v+v0)*z))*sqrt(v*v0);
            else
                sigma=z/2.0*(v+v0);
                sprd=2.0/((v+v0)*z)*sqrt(v0*v);
            end
        end
    end
    return
end

function [t] = vzmodel2d_calctime(x,z,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

    v=v0+av*z;
    b=(x.*x+z.*z)./(2*v0*v);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml) 
        if(abs(av)>sml) 
            t = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb.*avb));
        else
            t = avb + sqrt(2*b+avb.*avb);
        end
    else
       t=lrg;
    end

    return 
end
