function [dtdz,d2tdz2] = vzmodel2d_tway_timedz_vx(z,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip)
%function [dtdz] = vzmodel2d_tway_timedz_vx(z,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip)

if(abs(kdip)<=1e-6)
    kdip=1e-8;
end
%z = z0 + kdip * x;
jdip = 1/kdip;
x = (z-z0)*jdip;


%traveltime derivatives with respect to the reflecting point z(x)
dtshtdz=vzmodel2d_calctimedz_vx(x,shtx,z,v0_dw,az_dw,jdip);
dtrecdz=vzmodel2d_calctimedz_vx(x,recx,z,v0_up,az_up,jdip);
dtdz = dtshtdz+dtrecdz;

d2tshtdz2=vzmodel2d_calctimedx2(x,shtx,z,v0_dw,az_dw,jdip);
d2trecdz2=vzmodel2d_calctimedx2(x,recx,z,v0_up,az_up,jdip);
d2tdz2 = d2tshtdz2+d2trecdz2;
end

function [dtdz] = vzmodel2d_calctimedz_vx(xE,xS,z,v0,av,jdip)

sml=1.e-6;
lrg=1.e+6;


vS=v0+av*xS;
vE=v0+av*xE;
x = (xE-xS);
r = sqrt(x.^2+z.^2);
%dr2dz = 2*( jdip*x + z);

%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if ( (vS>sml) && (vE>sml) ) 
        if(abs(av)>sml)
            %t = 1./av * arcosh(1+ (av.^2 * r.^2) ./ (2 .* vS .* vE));  
            W = sqrt(4.*vS.*vE.*r.^2 + av^2*r.^4);          
            dtdz = 1./W.*(2.*z + jdip.*(2.*x - av./vE.*r.^2)); 
        else
            
            %t = sqrt(r.^2/v0^2);
            W = sqrt(4.*v0.*v0.*r.^2); 
            dtdz =  1./W.*(2.*z + jdip.*(2.*x)); 
        end
    else
        %disp(['vS=',num2str(vS),' vE=',num2str(vE)])
        dtdz = lrg;
    end

    return
end


function [d2tdz2] = vzmodel2d_calctimedx2(xE,xS,z,v0,av,jdip)

sml=1.e-6;
lrg=1.e+6;

vS=v0+av*xS;
vE=v0+av*xE;
x = (xE-xS);
r = sqrt(x.^2+z.^2);

dr2dz = 2 * (jdip*x + z);
dr4dz = 2*r.^2.*dr2dz;


%    check if velocity become negative, if it's the case traveltime becomes meaningless
     if ( (vS>sml) && (vE>sml) ) 
        if(abs(av)>sml)
            
            N = (2.*z + jdip.*(2.*x - av./vE.*r.^2)); 
            dNdx = 2 + jdip .* ( jdip * (2+r.^2*av^2./vE.^2) - av./vE.*dr2dz);
            W = sqrt(4.*vS.*vE.*r.^2 + av^2*r.^4);          
            F = 4*vS*(av*jdip*r.^2+vE.*dr2dz) + av^2 .* dr4dz;            
            d2tdz2 = dNdx./W - N./2./W.^3.*F;
        else
            N = (2.*z + jdip.*(2.*x)); 
            dNdz = 2 .* (1 + jdip^2);           
            W = sqrt(4.*v0.*v0.*r.^2); 
            F = 4.*v0.*v0*dr2dz;
            d2tdz2 = dNdz./W - N./2./W.^3.*F; 
        end
    else
        d2tdz2 = lrg;
    end

    return
end



