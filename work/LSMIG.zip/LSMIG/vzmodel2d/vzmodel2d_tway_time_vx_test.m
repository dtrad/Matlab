
function [t,x] = vzmodel2d_tway_time_vx_test(z,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip)

    if(abs(kdip)<=1e-6)
        kdip=1e-8;
    end
    %z = z0 + kdip * x; 
    jdip = 1/kdip;
    x = (z-z0)*jdip;
    %traveltime
    tsht=vzmodel2d_calctime_vx_test(x,shtx,z,v0_dw,az_dw);
    trec=vzmodel2d_calctime_vx_test(x,recx,z,v0_up,az_up);
    t = tsht+trec;
    
end

function [t] = vzmodel2d_calctime_vx_test(xE_vec,xS,z_vec,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

for ix=1:numel(xE_vec)
    xE=xE_vec(ix);
    z=z_vec(ix);
    
    vS=v0+av*xS;
    vE=v0+av*xE;
    x = (xE-xS);
    b=(x.*x+z.*z)./(2*vS*vE);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (vS>sml && vE>sml) 
        if(abs(av)>sml) 
            t(ix) = 1.0./av*log((1+av.*avb)+av*sqrt(2.*b+avb.*avb));
        else
            t(ix) = avb + sqrt(2*b+avb.*avb);
        end
    else
       t(ix)=lrg;
    end
end
    return 
end


