%% PP and PS-wave raytracing in V(z) = V0 + az * z or V(x) = V0+ ax * x models

clc, close all, clear all
%warning off;
addpath('C:\Users\lcasasan\Documents\MATLAB\src\OPTIMIZED')

%% layers definition
% parameters = [ Vpo_1 Vso_1 epsilon_1 delta_1 incl_asse_1 rho1; ...
%                Vpo_n Vso_n epsilon_n delta_n incl_asse_n rho_n];

z0 = [0];
dip = 15;kdip=tand(dip);

%--------- Isotropic single layer (Rosales)
vP0(1) = 1700;   azP=0.15;
vS0(1) =  300;   azS=0.35;

%--------- Isotropic single layer
%vP0(1) = 1500; azP = 0.0;  
%vS0(1) =  385; azS = 0.0; 
epsi(1)=  .0;
del(1)=   .0;
ti(1) = 0;
rho(1)=1000;


parameters = [vP0(:),vS0(:),epsi(:),del(:),ti(:),rho(:)];
reflectors = [z0(:),kdip, zeros(numel(z0(:)),4), 1 ];

%% aquisition geometry
m = 2500;
h_min = -500; h_max = 500; dh = 25; %half offset
h = [h_min:dh:h_max]';
%h = [h_min:dh:h_max]'/2000;
h2 = 2 * h;
xs = m - h;
xr = m + h;
zs = 0.0;
zr = 0.0;
geometry = [xs,zeros(size(xs)),zs*ones(size(xs)),xr,zeros(size(xr)),zr*ones(size(xr))];

%% straight rays computation (reference)
[tpp,xpp,zpp]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PP');
[tps,xps,zps]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PS');

%% V(z) ray tracing
xpp_RP= zeros(size(h)); tpp_vz = zeros(size(h));
xps_CP= zeros(size(h)); tps_vz = zeros(size(h));
polpp_vz= zeros(size(h));
polps_vz= zeros(size(h));
tol = 1e-6;


%for ih=41
for ih=1:numel(h)
    xRP_0 = (xs(ih)+xr(ih))/2.0;
    shtx = xs(ih); recx=xr(ih);
    
    gamma0 = vP0/vS0;
    xCP_0 = shtx + h2(ih) * (gamma0)/(gamma0+1);
    %debug
% %             x_test = [m-10000:m+10000];
% %             tpp_test    = vzmodel2d_tway_time  (x_test,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip);
% %             [dtppdx_test,d2tppdx2_test] = vzmodel2d_tway_timedx(x_test,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip);
% %         
% %             figure
% %             subplot(311);plot(x_test,tpp_test); hold on; plot(xpp(ih),tpp(ih),'bs');
% %             subplot(312);plot(x_test(1:end-1),diff(tpp_test)); hold on; plot(xpp(ih),0,'bs');hold on;
% %             set(gca,'ygrid','on')
% %             subplot(312);plot(x_test,dtppdx_test,'r'); hold on;
% %         
% %             subplot(313);plot(x_test(1:end-2),diff(diff(tpp_test))); hold on; plot(xpp(ih),0,'bs');hold on;
% %             set(gca,'ygrid','on')
% %             subplot(313);plot(x_test,d2tppdx2_test,'r'); hold on;
    
    
    % %     % debug for traveltime equations
    % %     [tpp_vz(ih),raypp_vz(ih)] = vzmodel2d_tway_time(xpp(ih),shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip);
    % %     [tps_vz(ih),rayps_vz(ih)] = vzmodel2d_tway_time(xps(ih),shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip);
    
    % optimization using simplex method fminsearch
    % %        [xpp1_RP(ih)] = ...
    % %        fminsearch(@(x) vzmodel2d_tway_time(x,shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip),xRP_0);
    % %        [tpp1_vz(ih)] = vzmodel2d_tway_time(xpp1_RP(ih),shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip);
    % %     
    % %       [xps1_RP(ih)] = ...
    % %        fminsearch(@(x) vzmodel2d_tway_time(x,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip),xRP_0);
    % %        [tps1_vz(ih)] = vzmodel2d_tway_time(xps1_RP(ih),shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip);
    
    % %     % optimization using fzero
            [xpp1_RP(ih)] = ...
            fzero(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip),xRP_0);
            [tpp1_vz(ih)] = vzmodel2d_tway_time(xpp1_RP(ih),shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip,'PP');
            [xps1_CP(ih)] = ...
            fzero(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip),xCP_0);
            [tps1_vz(ih)] = vzmodel2d_tway_time(xps1_CP(ih),shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip,'PS');    
    % optimization using gauss-newton PP
    %[x] = NewtonSafe(@(xc) funcCcp_z(xc,Ds,Dr,gamma0_avg(ilayer)),x0,0.0,1.0,tol);
    x0 =-z0/kdip;

    
    xRP_min = xRP_0-max(h2);
    xRP_max = xRP_0+max(h2);
    if (kdip~=0)
         if (kdip>0)
        xRP_min = max(-z0/kdip,xRP_min);
         else
        xRP_max = min(-z0/kdip,xRP_max);   
         end
    end
    % reflection point (RP)
    [xpp_RP(ih)] = ...
        NewtonSafe(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip), ...
        xRP_0,xRP_min,xRP_max,tol);
    
    % traveltimes
    [tpp_vz(ih),polpp_vz(ih)] = vzmodel2d_tway_time(xpp_RP(ih),shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip,'PP');
       
    % optimization using gauss-newton PS
    xCP_min = xCP_0-max(h2);
    xCP_max = xCP_0+max(h2);
    
    if (kdip==0)
        xCP_min = min(shtx,recx);
        xCP_max = max(shtx,recx);
    end
    if (kdip~=0)
        x0_vP0 =(-vP0(1)/(azP+1e-9)-z0)/kdip;
        x0_vS0 =(-vS0(1)/(azS+1e-9)-z0)/kdip;
        if (kdip>0)
            xCP_min = max(-z0/kdip,xCP_min);
        else
            xCP_max = min(-z0/kdip,xCP_max);
        end

    end
    % conversion point (CP)
    [xps_CP(ih)] = ...
        NewtonSafe(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip), ...
        xCP_0,xCP_min,xCP_max,tol);
    
    % traveltimes
    [tps_vz(ih),polps_vz(ih)] = vzmodel2d_tway_time(xps_CP(ih),shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip,'PS');
    
    
    
end

%% plot
figure('name','traveltime comparison')
set(gca,'ydir','reverse')
subplot(121)
plot(h,tpp,'b-.','linewidth',2.0); hold on
set(gca,'Ylim',[min([tps;tpp])*.8,max([tps;tpp])*1.1],'ydir','reverse')
plot(h,tpp1_vz,'r-x','linewidth',2.0); hold on
plot(h,tpp_vz,'g-o','linewidth',2.0); hold on
title('PP')
%plot
subplot(122)
plot(h,tps,'b-.','linewidth',2.0); hold on
set(gca,'Ylim',[min([tps;tpp])*.8,max([tps;tpp])*1.1],'ydir','reverse')

plot(h,tps1_vz,'r-x','linewidth',2.0); hold on
plot(h,tps_vz,'g-s','linewidth',2.0); hold on
title('PS')

% plot
figure('name','polarity change vs offset')
subplot(121)
plot(h,polpp_vz,'k','linewidth',2.0); hold on
plot(h,ones(size(h)),'k'); 
set(gca,'Ylim',[0;2],'Xgrid','on')

title('PP')
subplot(122)
plot(h,polps_vz,'k','linewidth',2.0); hold on
plot(h,zeros(size(h)),'k'); 
set(gca,'Ylim',[-1;1],'Xgrid','on')

title('PS')







