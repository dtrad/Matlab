addpath c:\Pr'ogram Files'\MaTLAB\R2007b\work\Tcodes\
clear all, close all,clc
EPS = 10000000*eps;
eta = 1/8+EPS;
M = 101;
dx = 50;
xm = (0:M-1)'*dx;
V = [ones(M,1)  xm.^2 xm.^4];
%V e' vandermonde??


[S,L,D] = svd(V);

figure
subplot(121)
plot(S(:,1:3))

[Qqr,R,E] = qr(V,0);
%Q = orth(V)
hold on
plot(Qqr(:,1:3),'o-')

axis tight

k20 = (1/M)*sum(xm.^2);
k40 = (1/M)*sum(xm.^4);
k60 = (1/M)*sum(xm.^6);
k42 = (k60-k20*k40)/(k40-k20^2);

u0 = V(:,1); u2 = V(:,2)-k20*V(:,1); u4 = V(:,3)-k42*u2-k40*V(:,1);

U = [u0 u2 u4]

UN = [u0/norm(u0) u2/norm(u2) u4/norm(u4)]
[Qgs, Rgs] = grams(V)




subplot(122)
plot(UN(:,1:3),'s')
set(gca,'xlim',[1,numel(xm)])

hold on
plot(Qgs(:,1:3),'*')

%% 
T0 = 1;
vn = 2537;
EPS = 1000000*eps;




S = 8*eta+1;
vh = sqrt(vn^2*(1+2*eta));



C =  [T0;vn^-2/(2*T0);-S/(8*T0^3*vn^4)];
Afrac = 2*C(3)/C(2)
% t= V*C;
 t_frac = V(:,1:2)*C(1:2)+ V(:,3)*C(3)*1./(1-Afrac*V(:,2))
% figure,plot(xm,t,'r.',xm,t_frac,'bo')

CdC=C+[0.01 0 0]'.*C;
Afrac_dc0 = 2*CdC(3)/CdC(2);
t_frac_dc0=V(:,1:2)*CdC(1:2)+ V(:,3)*CdC(3)*1./(1-Afrac_dc0*V(:,2));
CdC=C+[0.0 0.01 0]'.*C;
Afrac_dc2 = 2*CdC(3)/CdC(2);
t_frac_dc2=V(:,1:2)*CdC(1:2)+ V(:,3)*CdC(3)*1./(1-Afrac_dc2*V(:,2));
CdC=C+[0.0 0 0.01]'.*C;
Afrac_dc4 = 2*CdC(3)/CdC(2);
t_frac_dc4=V(:,1:2)*CdC(1:2)+ V(:,3)*CdC(3)*1./(1-Afrac_dc4*V(:,2));
%
Vfrac = [(t_frac_dc0-t_frac)/(0.01*C(1)),...
         (t_frac_dc2-t_frac)/(0.01*C(2)),...
         (t_frac_dc4-t_frac)/(0.01*C(3))];
     
     figure
V_norm = [V(:,1)/max(V(:,1)) V(:,2)/max(V(:,2)) V(:,3)/max(V(:,3)) ]    
Vfrac_norm = [Vfrac(:,1)/max(Vfrac(:,1)) Vfrac(:,2)/max(Vfrac(:,2)) Vfrac(:,3)/max(Vfrac(:,3)) ]    
     plot(V_norm),hold on,plot(Vfrac_norm,'.')
     
[Qgs_frac, Rgs_frac] = grams(Vfrac)     

[Qqr_frac,Rqr_frac,Eqr_frac] = qr(Vfrac,0);
figure('name','GS orthogonalization basis')
subplot(311)
plot(xm/xm(end),Qgs(:,1),'b.',xm/xm(end),Qgs_frac(:,1),'sb')
subplot(312)
plot(xm/xm(end),Qgs(:,2),'r.',xm/xm(end),Qgs_frac(:,2),'sr')
subplot(313)
plot(xm/xm(end),Qgs(:,3),'g.',xm/xm(end),Qgs_frac(:,3),'sg')
     Qqr_frac=Qqr_frac;
figure('name','QR orthogonalization basis')
subplot(311)
plot(xm/xm(end),Qqr(:,1),'b.',xm/xm(end),Qqr_frac(:,1),'sb')
subplot(312)
plot(xm/xm(end),Qqr(:,2),'r.',xm/xm(end),Qqr_frac(:,2),'sr')
subplot(313)
plot(xm/xm(end),Qqr(:,3),'g.',xm/xm(end),Qqr_frac(:,3),'sg')
     














