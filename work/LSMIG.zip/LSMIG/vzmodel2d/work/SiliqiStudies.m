%% Studies on Siliqi/Shifted Hyperbola Orthogonal parameterizations
clear all
close all
T0 = 1;
vn = 2537;
eta = -0.05;
S = 8*eta+1;
vh = sqrt(vn^2*(1+2*eta));
M = 61;
dh = 50;
xm = (0:M-1)'*dh;
par.par=1
m = (0:M-1)';
tau0 = T0/S; %Siliqi
TM =[T0+T0/S*((1+(xm(end).^2*S)/(T0^2*vn^2)).^(1/2)-1)]';
dtM=(real(TM(end))-T0);

tsili1 =[T0+T0/S*((1+(xm.^2*S)/(T0^2*vn^2)).^(1/2)-1)]';

Asili = (dtM^2+2*dtM*tau0)/tau0^2/(M-1)^2;
ts = 0.004

%%%dtM= (-1-(1+Asili*M^2-2*Asili*M+Asili)^(1/2))*tau0;
%% vedo Siliqiparameterization approximaqtion la stima rimane orthogonale

Niter = 200
Cstim = zeros(3,Niter);
Astim = Cstim;
par.xm = xm;

tsili = T0-tau0 + tau0*sqrt(1+ Asili*m.^2);
tsili_lin = T0-tau0 + tau0*(1+Asili/2*m.^2-1/8*Asili.^2*m.^4);
figure
plot(xm,tsili,'bo',xm,tsili_lin,'r.')

%%
m0 = [T0;tau0;dtM];
C =m0;A = m0;
OPTIONS = optimset
OPTIONS.MaxFunEvals = 1000;
OPTIONS.MaxIter = 1000;
OPTIONS.Display = 'Off';
for i = 1:Niter
    n = ts*randn(size(xm));
    tn = tsili+n;
    par.tn = tn;

    Cstim(:,i) =   lsqnonlin(@(m) T_siliqi_lin(m,par),m0,[],[],OPTIONS);
    Astim(:,i) =  lsqnonlin(@(m) T_siliqi(m,par),m0,[],[],OPTIONS);
      
end
    



figure('name','Siliqi Linearized (blue) vs Siliqi ortho (red)')


CC=corrcoef(Cstim(1,:)-C(1),Cstim(3,:)-C(3))
CA=corrcoef(Astim(1,:)-m0(1),Astim(3,:)-m0(3))
subplot(131)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0(1))/m0(1)*100,(Astim(3,:)-m0(3))/m0(3)*100,'r.')
xlabel('T0'),ylabel('\Delta T_M')
axis square


CC=corrcoef(Cstim(1,:)-C(1),Cstim(2,:)-C(2))
CA=corrcoef(Astim(1,:)-m0(1),Astim(2,:)-m0(2))
subplot(132)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(2,:)-C(2))/C(2)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0(1))/m0(1)*100,(Astim(2,:)-m0(2))/m0(2)*100,'r.')
xlabel('T0'),ylabel('\tau_0')
axis square


CC=corrcoef(Cstim(2,:)-C(2),Cstim(3,:)-C(3))
CA=corrcoef(Astim(2,:)-m0(2),Astim(3,:)-m0(3))
subplot(133)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-m0(2))/m0(2)*100,(Astim(3,:)-m0(3))/m0(3)*100,'r.')
axis square
xlabel('\tau_0'),ylabel('\Delta T_M')

%% different parameterization [T0;tau0;A];

m0 = [T0;tau0;Asili];
C =m0;A = m0
par.par=2;
OPTIONS = optimset
OPTIONS.MaxFunEvals = 1000;
OPTIONS.MaxIter = 1000;
OPTIONS.Display = 'Off';
for i = 1:Niter
    n = ts*randn(size(xm));
    tn = tsili+n;
    par.tn = tn;

    Cstim(:,i) =   lsqnonlin(@(m) T_siliqi_lin(m,par),m0,[],[],OPTIONS);
    Astim(:,i) =  lsqnonlin(@(m) T_siliqi(m,par),m0,[],[],OPTIONS);
      
end
    



figure('name','Siliqi Linearized (blue) vs Siliqi ortho (red)')


CC=corrcoef(Cstim(1,:)-C(1),Cstim(3,:)-C(3))
CA=corrcoef(Astim(1,:)-m0(1),Astim(3,:)-m0(3))
subplot(131)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0(1))/m0(1)*100,(Astim(3,:)-m0(3))/m0(3)*100,'r.')
xlabel('T0'),ylabel('a')
axis square


CC=corrcoef(Cstim(1,:)-C(1),Cstim(2,:)-C(2))
CA=corrcoef(Astim(1,:)-m0(1),Astim(2,:)-m0(2))
subplot(132)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(2,:)-C(2))/C(2)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0(1))/m0(1)*100,(Astim(2,:)-m0(2))/m0(2)*100,'r.')
xlabel('T0'),ylabel('\tau_0')
axis square


CC=corrcoef(Cstim(2,:)-C(2),Cstim(3,:)-C(3))
CA=corrcoef(Astim(2,:)-m0(2),Astim(3,:)-m0(3))
subplot(133)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-m0(2))/m0(2)*100,(Astim(3,:)-m0(3))/m0(3)*100,'r.')
axis square
xlabel('\tau_0'),ylabel('a')

