%%
 clc,close all, clear all
d = +0.1;
e = -0.12;
vp0 = 1.5;
vN = vp0*sqrt(1+2*d);
vH = vp0*sqrt(1+2*e);
eta = (e-d)/(1+2*d)
tau0 = 1;
p = sind(linspace(0,90,45))/vH;


taup_iso = tau0*sqrt(1-p.^2*vH^2) ;
taup_alkha = tau0*sqrt((1-p.^2*vH^2)./(1-p.^2*(vH^2-vN^2) ));
taup_alkha1 = tau0*sqrt((1-p.^2*vH^2).*(1+p.^2*(vH^2-vN^2) ));
taup_alkha2 = tau0*sqrt((1-p.^2*vH^2)).*(1+p.^2*(vH^2-vN^2)/2 );
figure,
plot(p,taup_iso,'kv-',p,taup_alkha,'rs-',p,taup_alkha1,'b^-',p,taup_alkha2,'g>-');
set(gca,'ydir','reverse')
%%
syms tau tau0 p vN2 vH2 A

tau = tau0*sqrt((1-p.^2*vH2))*(1+p.^2*A);

pretty(tau)
r = simple(diff(tau,1,p));
pretty(r)
r_approx = -tau0*p.*(vH2+3*vH2*p.^2*A)./(1-p.^2*vH2).^(1/2)
q_approx = simple(diff(r_approx,p,1))
q_approx_1 = tau0*vH2*(-1-9*p.^2*A)./(1-p.^2*vH2).^(3/2);
q = simple(diff(tau,2,p));
clc
pretty(tau)
% pretty(simple(r))
% pretty(simple(q))
pretty(simple(r_approx))
pretty(simple(q_approx_1))
% syms dtau
% R = solve(dtau-r,vH2)
% q_new = subs(q,vH2,R(1))
% pretty(simple(q_new))
% Q = solve(simple(q_new),vN2)

%% per il processing tau-p isotropo...
clear all, clc
syms tau tau0 p vH2 r

% write standar taup iso moveout (func_tau is the expression, tau is the
% variable )
func_tau = tau0*sqrt((1-p.^2*vH2))
% compute derivatives (eq.6 FOMEL)
r_exact = simple(diff(tau,1,p));
%q = simple(diff(tau,2,p));

clear tau,syms tau
% solve for the value of vH2 considering tau as a variable
% take positive root S(1)
S = solve(r+p*vH2*tau0^2/tau,vH2);
%
tau_new = simple( subs(func_tau,vH2,S(1)));

% find the value of tau respect to the other variables
% solve tau = f(p,r,tau0,tau) for tau 
tau0_map = solve(tau-tau_new,tau0)
pretty(tau0_map(1))

% substitue tau0 above found in the original expression for taup function 
% and the find the mapping relation for vH
S_new = subs(func_tau,tau0,tau0_map(1))
pretty(solve(tau-S_new,vH2))
%% per il processing tau-p VTI
% syms r q tau0 tau vH2 A
% % write VTI taup  moveout (func_tau is the expression, tau is the
% % variable )
% func_tau = tau0*sqrt((1-p.^2*vH2))*(1+p.^2*A);
% % compute derivatives (approximated)
% %r_approx = - tau0^2*p*vH2^2/tau*(1+p.^2*A)*(1+3*p^2*A);
% r_approx = - tau0^2*p*vH2^2/tau*(1+p.^2*A)*(1+3*p^2*A-2*A/vH2);
% %q_approx = - tau0^4*vH2^2/tau^3*(1+p.^2*A)^3*(1+9*p^2*A);
% %q_approx = - tau0^4*vH2^2/tau^3*(1+p.^2*A)^3*(1-2/vH2*A+9*p^2*A-6*vH2*p^4*A);
% q_approx = - tau0^4*vH2^2/tau^3*(1+12*p^2*A-2*A/vH2);
% 
% 
% 
% 
% r_approx1 = - tau0^2*p*vH2^2/tau*(1+4*p.^2*A)
% q_approx1 = - tau0^4*vH2^2/tau^3*(1+12*p.^2*A)
% 
% f1 = r-r_approx1;
% f2 = q-q_approx1;
% 
% % solve for the value of vH2 and A considering tau as a variable
% % take positive root S(1)
% S = solve(f1,f2,vH2,A)
% %substiture it in the tau formula
% tau_new =   simple(subs(  simple( subs(func_tau.^2,vH2,S.vH2(1))),A,S.A(1)));
% 
% % find the value of tau respect to the other variables
% % solve tau = f(p,r,tau0,tau) for tau 
% tau0_map = solve(tau.^2-tau_new,tau0)
% pretty(tau0_map(1))
%% per il processing tau-p VTI
% % write VTI taup  moveout (func_tau is the expression, tau is the
% % variable )
clear all,clc,close all
syms r q tau0 tau vH2 A p
func_tau = tau0*sqrt((1-p.^2*vH2)*(1+p.^2*A));
r_ex = diff(func_tau,1,p);
q_ex = diff(func_tau,2,p);

%pretty(simple(3*p.^4*vH2^2*A-6*p.^2*vH2*A+2*p.^6*vH2^2*A^2-3*p.^4*vH2*A^2-vH2+A))

%r_approx1 =  -tau0^2*p./tau.*((vH2-A+2*vH2*p.^2*A));
%q_approx1 = tau0.^4./tau.^3 .* (3*p.^4*vH2^2*A-6*p.^2*vH2*A-vH2+A);
r_approx1 = -tau0^2*p*vH2./tau.*((1+2*p.^2*A)); 
q_approx1= tau0.^4./tau.^3 .* (-6*p.^2*vH2*A-vH2+A);

pretty(r_approx1)
pretty(q_approx1)

f1 = r-r_approx1;
f2 = q-q_approx1;

% solve for the value of vH2 and A considering tau as a variable
% take positive root S(1)
S = solve(f1,f2,vH2,A)
%substiture it in the tau formula
tau_new =   simple(subs(  simple(subs(func_tau.^2,vH2,S.vH2(1))),A,S.A(1)));


