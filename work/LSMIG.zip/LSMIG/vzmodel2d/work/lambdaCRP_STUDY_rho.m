%%%
clc
close all
clear all
A = 10/180*pi;

RHO = 1.1;
rho=1/RHO;
Lambda = linspace(-60,60,361)/180*pi;
Teta = linspace(-60,60,181)/180*pi;
z_LCRP = zeros(numel(Teta),numel(Lambda));
NUM= z_LCRP;
DEN=z_LCRP;
RAD=z_LCRP;
for i=1:numel(Lambda)
    for j=1:numel(Teta)
L = Lambda(i);
T = Teta(j);
NUM(j,i)=cos(A)*(sin(L)^2-cos(T)^2)*RHO;
RAD(j,i) = (1-sin(T)^2/cos(L)^2*cos(A)^2*RHO^2);

NUM_DIFF(j,i) = -1*(sin(L)^2-cos(T)^2)*RHO;
RAD_DIFF(j,i) = (1-sin(T)^2*RHO^2);

if RAD(j,i)<1e-12
    RAD(j,i)=NaN;
    
end
if RAD_DIFF(j,i)<1e-12
    RAD_DIFF(j,i)=NaN;
    
end

DEN(j,i) = cos(L)*(sin(A)*sin(L)*RHO-cos(T)*sqrt(RAD(j,i)));
DEN_DIFF(j,i)=-sin(L)^2*RHO+cos(T)*sqrt(RAD_DIFF(j,i));
z_LCRP(j,i)= NUM(j,i)/DEN(j,i);
%z_LCRP(j,i) = (NUM(j,i)*DEN(j,i))/(DEN(j,i)+eps).^2;
z_DIFF(j,i) = NUM_DIFF(j,i)/DEN_DIFF(j,i);

    end
end
%%
figure,subplot(211)
imagesc(Lambda/pi*180,Teta/pi*180,z_LCRP);
caxis([-2,2])
dL = diff(Lambda(1:2));
dT = diff(Teta(1:2));
[F_L,F_T] = gradient(z_LCRP,dL,dT);
subplot(212)
a = sqrt(F_L.^2+F_T.^2);
imagesc(Lambda/pi*180,Teta/pi*180,sqrt(F_L.^2));
caxis([-5 5])
hold on
[c,h] = contour(Lambda/pi*180,Teta/pi*180,(sqrt(F_L.^2)),[-1:0.1:1],'k'); clabel(c,h)
%%
figure,
surf(Lambda/pi*180,Teta/pi*180,z_LCRP);set(gca,'zlim',[-2 2]),shading interp
caxis([-2 2])
% 
% figure
% imagesc(Lambda/pi*180,Teta/pi*180,z_DIFF);caxis([-2,2])



indA = round((A-Lambda(1))/dL)+1;
% figure
% Z_Teta0=1/(-sin(A)^2*RHO+1)*cos(A)^2*RHO;
% %plot(Teta/pi*180,z_LCRP(:,indA)-z_LCRP(1,indA),'.');set(gca,'ylim',[-2 2],'ydir','reverse')
% plot(Teta/pi*180,z_LCRP(:,indA)-Z_Teta0,'.');set(gca,'ylim',[-2 2],'ydir','reverse')
% 
% hold on
% 
% %z_biondo = -(rho-1)/rho*tan(Teta).^2
% z_biondo = -(rho-1)/rho/cos(A)*(sin(Teta).^2)./(cos(A).^2-sin(Teta).^2)
% plot(Teta/pi*180,z_biondo,'ro')

%% THETA RMO horiz
z_RMOhor_exact = cos(Teta).*RHO./(1-sin(Teta).^2*RHO^2).^(1/2)-RHO
z_RMOhor_us= (RHO-1)*tan(Teta).^2;
z_RMOhor_biond = -(rho-1)/rho*tan(Teta).^2;
figure('name','linearized RMO for horizontal reflector')
plot(Teta/pi*180,z_RMOhor_exact,'k',Teta/pi*180,z_RMOhor_us,'b.',Teta/pi*180,z_RMOhor_biond,'ro','linewidth',2.0);
xlabel('\theta [deg]')
set(gca,'ylim',[-1 1],'ydir','reverse')

%% THETA RMO dipping
z_RMOdip_exact = (-cos(A)^2+1-cos(Teta).^2).*cos(A)*RHO./(cos(A)*sin(A)^2*RHO-(cos(A)^2-sin(Teta).^2*cos(A).^2*RHO^2).^(1/2).*cos(Teta))-1./(-sin(A)^2*RHO+1)*cos(A)^2*RHO;
z_RMOdip_us= (1./(-sin(A)^2+cos(Teta).^2)-1/cos(A)^2)*(RHO-1);
z_RMOdip_biond = -(rho-1)/rho/cos(A)*(sin(Teta).^2)./(cos(A).^2-sin(Teta).^2);
figure('name','linearized RMO for dipping reflector')
plot(Teta/pi*180,z_RMOdip_exact,'k',Teta/pi*180,z_RMOdip_us,'.',Teta/pi*180,z_RMOdip_biond,'ro','linewidth',2.0);
xlabel('\theta [deg]')
set(gca,'ylim',[-1 1],'ydir','reverse')

%%
% indTETA = round ((([0 15 30 45 60]/180*pi)-Teta(1))/dT)+1
% figure('name','RMO extended for reflection')
% hold on
% for i = 1:numel(indTETA)
% plot(Lambda/pi*180,z_LCRP(indTETA(i),:),'r','linewidth',2.0),
% end
% set(gca,'ydir','reverse','ylim',[-2 2])
% 
% plot([A A]*180/pi,[-2 2],'r','linewidth',2.0)
% 
% %% DIFFRAZIONI
% 
% indTETA = round ((([0 15 30 45 60]/180*pi)-Teta(1))/dT)+1
% figure('name','Diffraction')
% hold on
% for i = 1:numel(indTETA)
%     
% plot(Lambda/pi*180,z_DIFF(indTETA(i),:),'k','linewidth',2.0),
% end
% set(gca,'ydir','reverse','ylim',[-2 2])
% 
% plot([A A]*180/pi,[-1 1],'r','linewidth',2.0)

%% COMPARISON REFLECTION DIFFRACTION
% figure('name','Reflection Vs Diffraction')
% indTETA = round ((([0]/180*pi)-Teta(1))/dT)+1
% plot(Lambda/pi*180,z_LCRP(indTETA(1),:),'r','linewidth',4.0),
% hold on
% plot(Lambda/pi*180,z_DIFF(indTETA(1),:),'k','linewidth',4.0),
% legend('reflection','diffraction')
% set(gca,'ydir','reverse','ylim',[-2 2])
%% DIFFRACTION LAMDA RMOVEOUT per theta = 0; (zero offset)
indTETA = round ((([0]/180*pi)-Teta(1))/dT)+1
figure('name','linearized RMO for diffractor seen at theta = 0')
plot(Lambda/pi*180,z_LCRP(indTETA(1),:)-RHO,'r','linewidth',4.0),hold on
LRMO_0 =-cos(Lambda).^2*RHO./(sin(Lambda).^2*RHO-1)-RHO;
LRMO_0_lin =(RHO-1)./cos(Lambda).^2.*sin(Lambda).^2;

plot(Lambda/pi*180,LRMO_0,'k',Lambda/pi*180,LRMO_0_lin,'b','linewidth',4.0),
xlabel('\lambda')
legend('reflection','diffraction','diffraction lin')
set(gca,'ylim',[-1 1],'ydir','reverse') 

%% DIFFRACTION LAMDA RMOVEOUT per theta  generico; 
T = [20]/180*pi;
indTETA = round (((T)-Teta(1))/dT)+1;

figure('name','linearized RMO for diffractor seen at generic theta ')
plot(Lambda/pi*180,z_LCRP(indTETA(1),:)-max(abs(z_LCRP(indTETA(1),:))),'r','linewidth',4.0),hold on
LRMO_T =(-cos(Lambda).^2+1-cos(T)^2)*RHO./(sin(Lambda).^2*RHO-(1-sin(T)^2*RHO^2)^(1/2)*cos(T))-cos(T)*RHO/(1-sin(T)^2*RHO^2)^(1/2);
LRMO_T_lin =sin(Lambda).^2./(cos(Lambda).^2-sin(T)^2)/cos(T)^2*(RHO-1)


plot(Lambda/pi*180,LRMO_T,'k',Lambda/pi*180,LRMO_T_lin,'b','linewidth',4.0),
xlabel('\lambda')
legend('reflection','diffraction','diffraction lin')
set(gca,'ylim',[-1 1],'ydir','reverse') 
%% Comparison US vs FOMEL (zero offset lambda CRP for reflection moveout
indTETA = round ((([0]/180*pi)-Teta(1))/dT)+1
z0 = 500

NUM_FOMEL = z0*cos(A).*RHO.*cos(Lambda);
DEN_FOMEL = 1-RHO*sin(A)*sin(Lambda);
z_LCRP_FOMEL = NUM_FOMEL./DEN_FOMEL; 
figure('name','COMPARISON US vs FOMEL (zero offset lambda CRP for reflection moveout')
plot(Lambda/pi*180,z_LCRP(indTETA,:)*z0,'b.','linewidth',2.0),
hold on
plot(Lambda/pi*180,z_LCRP_FOMEL,'ro','linewidth',2.0),

%% COMPARISON US vs FOMEL (zero offset lambda CRP for diffraction moveout
x0 = 1;  %diffractor position
xmig = x0-500; % LCRP position
indTETA = round ((([0]/180*pi)-Teta(1))/dT)+1
figure('name','COMPARISON US vs FOMEL (zero offset lambda CRP for diffraction moveout')
%z_diff0 =-cos(Lambda).^2*RHO./(sin(Lambda).^2*RHO-1)*(z0);
%z_diff0_0_lin =(RHO-1)./cos(Lambda).^2.*sin(Lambda).^2*RHO*z0+RHO*z0;
%plot(Lambda/pi*180,z_diff0,'b.','linewidth',2.0),
%ylabel('z depth [km]') 
%xlabel('\lambda'),set(gca,'ydir','reverse')
hold on

v=1;
vM = RHO*v;
D = sqrt(z0^2*(v^2-vM^2*sin(Lambda).^2)+(xmig-x0)^2*v^2);
NUM_FOMEL= vM*cos(Lambda).*(vM*(xmig-x0)*sin(Lambda)+D);
DEN_FOMEL = v^2-vM^2*sin(Lambda).^2;
z_diff0_FOMEL = NUM_FOMEL./DEN_FOMEL;

z_diff0_FOMEL_1 = RHO*cos(Lambda)./(-xmig*RHO*sin(Lambda)+x0*RHO*sin(Lambda)...
    +(xmig^2-2*x0*xmig+x0^2-z0^2*RHO^2*sin(Lambda).^2+z0^2).^(1/2)).*(xmig^2-2*x0*xmig+x0^2+z0^2);


plot(Lambda/pi*180,z_diff0_FOMEL,'ro','linewidth',2.0),
hold on
plot(Lambda/pi*180,z_diff0_FOMEL_1,'b.','linewidth',2.0),
%plot(Lambda/pi*180,RHO*cos(Lambda)./sqrt(1-RHO^2*sin(Lambda).^2)*z0,'r.','linewidth',2.0),


%indLAMBDA= round ((([0]/180*pi)-Lambda(1))/dL)+1
%plot(Teta/pi*180,z_LCRP(:,181)*z0,'sm')
%plot(Teta/pi*180,z_DIFF(:,181)*z0,'k*')
%plot(Lambda/pi*180,z_DIFF(indTETA,:)*z0,'gv')
