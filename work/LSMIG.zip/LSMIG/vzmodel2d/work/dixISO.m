syms tau0 R Rtau p

dtau0 = 1/2/tau0*(2*tau-p*(R+tau*Rtau))
pretty(dtau0)

den =(p*R-tau);
vn2 = R/p/den

dvn2 =simple(1/p*Rtau/den+1/p*R*(-1)/den^2*(p*Rtau-1))
pretty(dvn2)

dtau0dvn = simple(dtau0*vn2+tau0*dvn2)
dtau0dvn=simple(subs(dtau0dvn,tau0^2,(tau*(tau-p*R))))


pretty(dtau0dvn)

vI = simple(expand(dtau0dvn/dtau0))


% T-X

% syms t0 t P Pt p h 
% 
% dt0 = 1/2/t0*(2*t-h*(P+t*Pt))
% vn2 = h*(P*t)^(-1)
% pretty(dt0*vn2)
% dvn2 = -h*(P*t)^(-2)*(Pt*t+P)
% pretty(t0*dvn2)
% 
% dvn2dt0=factor(expand(dt0*vn2+t0*dvn2))
% dvn2dt0=simple(subs(dvn2dt0,t0^2,(t*(t-P*h))))
% pretty(dvn2dt0)
% 
% vI=simple(factor(expand(dvn2dt0/dt0)))
% pretty(vI)