clear all,close all
syms y x A G V z0 z t Vmig rho zmig xmig

func_y = x+(tan(A)*x+z0)*(sin(A)*cos(A))/(cos(A)^2-sin(G)^2)
xS = simple(solve(func_y-y,x))


t_func = 2*(tan(A)*x+z0)/V*(cos(A)*cos(G))/(cos(A)^2-sin(G)^2)
t_rifl = simple(subs(t_func,x,xS))


%%
syms L T
zmig_func = .5*Vmig*t*(cos(L).^2-sin(T).^2)/cos(L)/cos(T);
zmig_func = (subs(simple(subs(zmig_func,t,t_rifl)),Vmig,V*rho))
%yS = solve(zmig-zmig_func,y)


xmig_func = y-.5*Vmig*t*sin(L)/cos(T)
xmig_func = (subs(simple(subs(xmig_func,t,t_rifl)),Vmig,V*rho))
yS = solve(xmig-xmig_func,y)


zmig_func = simple(subs(zmig_func,y,yS))
zmig_func_z0 = simple (subs(subs(zmig_func,T,0),G,0))

%%
syms t z zmig
t = 2*z/V*(cos(A)*cos(G))/(cos(A)^2-sin(G)^2)
tmig = 2*zmig/Vmig*(cos(L)*cos(T))/(cos(L)^2-sin(T)^2)

h=(sin(G)*cos(G))/(cos(A)^2-sin(G)^2)*z
hmig=(sin(T)*cos(T))/(cos(L)^2-sin(T)^2)*zmig
%%
clc
syms z0 x0 B m_diff xmig
t_diff_func = 2*z0/V*(cos(B)*cos(G))/(cos(B)^2-sin(G)^2)
m_diff_func = x0+z0*(sin(B)*cos(B))/(cos(B)^2-sin(G)^2)
BS = simple(solve(m_diff_func-m_diff,(B)))
%BS=simple(solve(subs(m_diff_func,G,0)-m_diff,B))
t_diff_func = simple(subs(t_diff_func,B,BS(1)))
pretty(simple(subs(t_diff_func,G,0)))

%% GAMMA = 0 , zero offset
clc
zmig_func = z0*rho*cos(L)/cos(B);
xmig_func = x0+z0/cos(B)*(sin(B)-rho*sin(L));
%xmig_func = x0+z0*(tan(B)-rho*sin(L)*sqrt((tan(B)^2+1)));

BS = simple(solve(xmig-xmig_func,B))
zmig_func = simple(subs(zmig_func,B,BS(1)))
zmig_func_0 = simple(subs(zmig_func,xmig,x0))
pretty(zmig_func)
pretty(zmig_func_0)
%BS(1)
%(-xmig^2+2*x0*xmig-x0^2-z0^2)*rho*cos(L)/(xmig*rho*sin(L)-x0*rho*sin(L)-(xmig^2-2*x0*xmig+x0^2-z0^2*rho^2*sin(L)^2+z0^2)^(1/2))

NUM = (-xmig^2+2*x0*xmig-x0^2-z0^2)*rho*cos(L)
DEN = (xmig*rho*sin(L)-x0*rho*sin(L)-(xmig^2-2*x0*xmig+x0^2-z0^2*rho^2*sin(L)^2+z0^2)^(1/2))
DEN_1 = (xmig*rho*sin(L)-x0*rho*sin(L)+(xmig^2-2*x0*xmig+x0^2-z0^2*rho^2*sin(L)^2+z0^2)^(1/2))
NUM_new = simple(NUM*DEN_1)
DEN_new = simple(DEN*DEN_1)
pretty(simple(NUM_new/DEN_new))
%% gaMMA != 0 
clc
zmig_func = z0*rho*(cos(B)*cos(G))/(cos(B)^2-sin(G)^2)/ ( (cos(L)*cos(T))/(cos(L)^2-sin(T)^2))
xmig_func = x0+z0*(cos(B))/(cos(B)^2-sin(G)^2)*(sin(B)-rho*cos(G)*cos(L)/cos(T))

BS = simple(solve(xmig-xmig_func,B))
zmig_func = factor(expand(subs(zmig_func,B,BS(1))))
