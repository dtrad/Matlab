clear all, clc, close all
syms S s02 sN2 sH2 G 
sin2 = sin(G)^2
cos2 = cos(G)^2
S_ELL = sH2*sin2+(s02)*cos2; % function of eta
S_func = sqrt(( S_ELL + ((sN2)-(sH2))*(sin2.*cos2)));

pretty((diff(S_func,1,sN2)))
pretty((diff(S_func,1,sH2)))
%%
clc
syms vN2 vH2
S_func = subs(subs(S_func,sN2,1/vN2),sH2,1/vH2);
pretty((diff(S_func,1,vN2)))
pretty((diff(S_func,1,vH2)))
%%
clc
syms vN vH
S_func = subs(subs(S_func,vN2,vN^2),vH2,vH^2);
pretty((diff(S_func,1,vN)))
pretty((diff(S_func,1,vH)))
%%
clc
syms n
vH_func = vN*sqrt(1+2*n)
S_func = simple(subs(S_func,vH,vH_func));
pretty((diff(S_func,1,vN)))
pretty((diff(S_func,1,n)))