 function E = T_frac_3param(C,par)
 xm = par.xm;

 tn = par.tn;
 temp = inv(par.P)*C;
 c0 = temp(1);
 c2 = temp(2);
 c4 = temp(3);

 
fracfatt =1-2*c4/c2*xm.^2;
t = c0+c2*xm.^2+c4./fracfatt.*xm.^4;
 
 %t = (k20*k42-k40-x.^2*k42+x.^4)*a4+a0-k20*a2+x.^2*a2;
% figure
% plot(x,tn,'b.',x,t,'ro')
% pause
 E = tn-t;
