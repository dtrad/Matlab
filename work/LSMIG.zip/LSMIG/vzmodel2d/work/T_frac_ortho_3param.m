 function E = T_frac_ortho_3param(A,par)
 xm = par.xm;
 k20 = par.k20;
 k40 = par.k40;
 k42 = par.k42;
 tn = par.tn;
 temp = inv(par.P)*A;
 a0 = temp(1);
 a2 = temp(2);
 a4 = temp(3);
 %t = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*xm.^2+a4./(1-2*a4./(a2-k42*a4).*xm.^2).*xm.^4;
 
fracfatt = 2*a4./(a2-k42*a4);
t = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*xm.^2+a4./(1-fracfatt.*xm.^2).*xm.^4;
 
 %t = (k20*k42-k40-x.^2*k42+x.^4)*a4+a0-k20*a2+x.^2*a2;
% figure
% plot(x,tn,'b.',x,t,'ro')
% pause
 E = tn-t;
