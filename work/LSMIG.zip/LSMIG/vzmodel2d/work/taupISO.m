%% per il processing tau-p isotropo...
clear all, clc
syms TAU tau0 p vH2 r

% write standar taup iso moveout (func_tau is the expression, tau is the
% variable )
func_tau = tau0*sqrt((1-p.^2*vH2))
% compute derivatives (eq.6 FOMEL)
r_exact = simple(diff(func_tau,1,p));
%q = simple(diff(tau,2,p));

clear tau,syms tau
% solve for the value of vH2 considering tau as a variable
% take positive root S(1)
S = solve(r+p*vH2*tau0^2/TAU,vH2);
%
tau_new = simple( subs(func_tau,vH2,S(1)));

%% find the value of tau respect to the other variables
% solve tau = f(p,r,tau0,tau) for tau 
tau0_map = solve(tau-tau_new,tau0)
pretty(tau0_map(1))

%% substitue tau0 above found in the original expression for taup function 
% and the find the mapping relation for vH
S_new = subs(func_tau,tau0,tau0_map(1))
pretty(solve(tau-S_new,vH2))