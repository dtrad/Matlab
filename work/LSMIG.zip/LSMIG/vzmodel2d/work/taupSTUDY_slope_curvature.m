%% this code test the goodness of some practical VTI approximations for
% moveout kinematic in taup domain

addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
close all,
clear all,
clc,
e = 0.1;
d = 0.1;
vp0 = 3.2;
z0 = 1240;
eta = (e-d)/(1+2*d)
tau0 = 2*z0/vp0;


phi = linspace(1,89.9,25);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;
[V_EX_,phi_ex,vphase_ex]=group_from_phase(teta/180*pi,vp0,vp0*0.7,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = INTERP1(phi_ex/pi*180,V_EX_,phi);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')
vN2 = (vp0*sqrt(1+2*d)).^2;
vH2 = (vp0*sqrt(1+2*e)).^2;
sqrt(vN2)
sqrt(vH2)
p = sind(phi)./vphase_ex;
%% ESATTA tau(p) = vp0*q(p)*tau0
q = sqrt((1./vphase_ex.^2)-p.^2);
taup_ex = q*vp0*tau0;

%% MIUR 
ell = vp0^2*cos2+vH2*sin2;
v_MIUR = sqrt( ell + (vp0^2*(vN2-vH2))./ell.*sin2.*cos2) ;
q_MIUR = sqrt((1./v_MIUR.^2)-p.^2);
taup_MIUR = q_MIUR*vp0*tau0;
%% FOMEL 
v_FOMEL = sqrt(1/2*ell+1/2*sqrt(ell.^2+4*(vp0^2*(vN2-vH2)).*sin2.*cos2));

q_FOMEL= sqrt((1./v_FOMEL.^2)-p.^2);
taup_FOMEL = q_FOMEL*vp0*tau0;


%% ISO
taup = tau0*sqrt(1-p.^2*vH2);

%% ALKHA
NUM_ALKHA = 1-vH2*p.^2;
DEN_ALKHA = 1 - (vH2-vN2)*p.^2;
taup_ALKHA = tau0*(NUM_ALKHA./DEN_ALKHA ).^(1/2);
TAU=taup_ALKHA;
%%ALKHA approx
A = (vH2-vN2);

r = 1/2*tau0./((1-p.^2*vH2)./(1-p.^2*A)).^(1/2).*(-2*p*vH2./(1-p.^2*A)+2*(1-p.^2*vH2)./(1-p.^2*A).^2.*p*A);
% r1 = tau0^2./TAU.*p.*(A-vH2)./(1-p.^2*A).^2;
% r_approx = tau0^2./TAU.*p.*(A-vH2)./(1-p.^2*A).^2;
% figure
% subplot(221)
% semilogy(p,abs(r),'r.',p,abs(r_approx),'bo');%,p,abs(r_approx_1),'k.')
% subplot(223)
% plot(p,(r-r_approx)./r*100,'bo');%,p,(r-r_approx_1)./r*100,'k.')
% set(gca,'Ylim',[-100 100])
%%
q = (vH2-A)*(3*p.^4*vH2*A-2*p.^2*A-1)*tau0./((-1+p.^2*vH2)./(-1+p.^2*A)).^(3/2)./(-1+p.^2*A).^4;

P = -(3*p.^4*vH2*A-2*p.^2*A-1);
% q1 = -tau0.^4*(vH2-A)*P./TAU.^3./(1-p.^2*A).^4;
% q_approx = -tau0.^4*(vH2-A)./TAU.^3./(1-p.^2*A).^4;
%  subplot(222)
%  semilogy(p,abs(q),'r.',p,abs(q_approx),'bo');%,p,abs(q_approx_1),'k.')
%  subplot(224)
%  plot(p,(q-q_approx)./q*100,'bo');%,p,(q-q_approx_1)./q*100,'k.')
% set(gca,'Ylim',[-100 100])
%%
figure('name','tau-p')
plot(p,taup_ex,'r','linewidth',3.0)
hold on
plot(p,taup,'ko-',...
     p,taup_MIUR,'k*-',...
     p,taup_FOMEL,'kd-',...
     p,taup_ALKHA,'ks-','linewidth',1.0);
    
     
title('$\tau-p$ reflection moveout','interpreter','LATEX','Fontsize',18)

set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/km]','interpreter','LATEX','Fontsize',14)
ylabel('$\tau(p)$ [ms]','interpreter','LATEX','Fontsize',14)
set(gca,'ydir','reverse'),box on,
legend('exact','ISO $v_n = v_h$','MIUR','FOMEL','ALKHA','APPROX','location','Best')
%%
figure('name','tau-p error')


plot(p,(taup-taup_ex)./taup_ex*100,'ko-',...
     p,(taup_MIUR-taup_ex)./taup_ex*100,'k*-',...
     p,(taup_FOMEL-taup_ex)./taup_ex*100,'kd-',...
     p,(taup_ALKHA-taup_ex)./taup_ex*100,'ks-','linewidth',1.0);
     
     
title('$\tau-p$ error $\%$','interpreter','LATEX','Fontsize',18)

set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/km]','interpreter','LATEX','Fontsize',14)
ylabel('Error $\%$','interpreter','LATEX','Fontsize',14)
set(gca,'ydir','reverse'),box on,
legend('ISO $v_n = v_h$','MIUR','FOMEL','ALKHA','APPROX','location','Best')

figure('name','check su TAU')
TAU_APP = tau0^2-tau0./(p.*q.*r).^(1/2).*r.^2.*p;
plot(p,TAU,'r.',p,sqrt(TAU_APP),'bo')



%%

pvec = p;rvec=r;qvec=q;TAUvec=TAU;
clear p r q TAU,
for i=1:numel(pvec)
    p=pvec(i);
    r=rvec(i);
    q=qvec(i);
    TAU=TAUvec(i);
%%%%%%%%%%%% EXACT VALUES %%%%%%%%%%%%%%%%%%%
%%%%%%%%% VH2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%S.vH(1)
%vH2_ex(i) = ...
%-1/18*(9*p*r^4*TAU-6*p*q*TAU^2*r^2-3*r^3*tau0^2-3*(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2)*r^2+TAU^3*q^2*p+3*TAU*q*r*tau0^2+TAU*q*(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2))/r^3/tau0^2/p^2

%S.vH(2)
%vH2_ex(i) = ...
%1/18*(-9*p*r^4*TAU+6*p*q*TAU^2*r^2+3*r^3*tau0^2-3*(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2)*r^2-TAU^3*q^2*p-3*TAU*q*r*tau0^2+TAU*q*(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2))/r^3/tau0^2/p^2;

%VH2 tau0 independent
vH2_ex(i) = ...
 (-3*r^2*p+q*TAU*p-TAU*r)/(-3*r^2*p+q*TAU*p+3*TAU*r)/p^2;
%vH2_ex(i) = ...
%-1/9*(TAU^2*p*q^2+3*TAU^2*r*q-2*p*q*TAU*r^2-6*r^3*TAU-3*p*r^4)/TAU/p^2/r^3
 


%%%%%%%%% A %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%S.A(1)
%A_ex(i) = ...
%1/6/p^3/r^2/TAU*(3*p*r^2*TAU+p*q*TAU^2+3*r*tau0^2+(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2))

%S.A(2)
%A_ex(i) = ...
%1/6/p^3/r^2/TAU*(3*p*r^2*TAU+p*q*TAU^2+3*r*tau0^2-(9*p^2*r^4*TAU^2-6*p^2*r^2*TAU^3*q+30*p*r^3*TAU*tau0^2+p^2*q^2*TAU^4+6*p*q*TAU^2*r*tau0^2+9*r^2*tau0^4)^(1/2))
    
%A_ex(i) = ...
%1/3*((3*r+p*q)*TAU)/(p^3*r^2+eps)

A_ex(i) = ...
1/p^2*(-TAU*r+r^2*p+q*TAU*p)/(3*TAU*r+r^2*p+q*TAU*p);

%%%%%% TAU0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%tau0_ex(i)=...
%-1/(r^2*p+p*TAU*q+3*r*TAU)*((r^2*p+p*TAU*q+3*r*TAU)*(-3*r^2*p+p*TAU*q+3*r*TAU))^(1/2)*TAU;
N_p = 3*TAU*r+TAU*p*q-3*r^2*p;
D_p = 3*TAU*r+TAU*p*q+r^2*p;
tau0_ex(i)= sqrt(N_p)/sqrt(D_p)*TAU;
%vH2_ex(i) = (-3*r^2*p+q*TAU*p-TAU*r)/N_p/p^2;
vH2_ex(i) = (N_p-4*TAU*r)/N_p/p^2;
%A_ex(i) =(-TAU*r+r^2*p+q*TAU*p)/D_p/p^2;
A_ex(i) = (D_p-4*TAU*r)/D_p/p^2;
%%%%%%%%%%%%%% P = 1
tau0_app(i) = 1/2/(p*q*r)^(1/2)*(r^2*p+(r^4*p^2+4*q*TAU^2*p*r)^(1/2));

%vH2_app(i) = ((p*TAU*q+tau0*(p*q*r)^(1/2))/p-r^2)/q/TAU/p^2;
%vH2_app(i) = ((p*TAU*q+tau0_app(i)*(p*q*r)^(1/2))/p-r^2)/q/TAU/p^2;
vH2_app(i) = ((TAU*p*q+1/2*r^2*p+1/2*(p^2*r^4+4*r*p*q*TAU^2)^(1/2))/p-r^2)/TAU/q/p^2;


%A_app(i) = (p*TAU*q+tau0*(p*q*r)^(1/2))/p^3/q/TAU;
%A_app(i) = (p*TAU*q+tau0_app(i)*(p*q*r)^(1/2))/p^3/q/TAU;
A_app(i) = (TAU*p*q+1/2*r^2*p+1/2*(p^2*r^4+4*r*p*q*TAU^2)^(1/2))/p^3/q/TAU;



%%%%%%%%%%%%%%% P =(2*p.^2*A+1);
tau0_app_2(i) =   1/2*2^(1/2)*((3*r^3*p*TAU+2*TAU^3*q-2*TAU^2*r^2-(r^3*TAU^2*(9*r^3*p^2+12*p*q*TAU^2-12*p*r^2*TAU+4*TAU^2*r))^(1/2))...
    /(TAU*q-2*r^2))^(1/2);
TAU0 = tau0_app(i); 
vH2_app_2(i) =(1/p*(p*q*TAU^2+r*TAU0^2+(3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/TAU-2/p*(p*q*TAU^2+r*TAU0^2+...
      (3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/q/TAU^2*r^2-r^2)/TAU/p^2/q;
%vH2_app(i) = (-(-p*q*TAU^2-r*TAU0^2+(3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/p/TAU+2*...
%    (-p*q*TAU^2-r*TAU0^2+(3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/p/q/TAU^2*r^2-r^2)/TAU/p^2/q;
A_app_2(i) = ...
         1/p^3*(p*q*TAU^2+r*TAU0^2+(3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/q/TAU^2;
%A_app(i) = ...
%-(-p*q*TAU^2-r*TAU0^2+(3*p*q*TAU^2*r*TAU0^2+r^2*TAU0^4)^(1/2))/p^3/q/TAU^2;


%%ISOTROPIC TAUP
tau0_ISO(i) = sqrt(TAU^2-TAU*r*p);
%vH2_ISO(i) = -r/p/tau0^2*TAU;

vH2_ISO(i)=r/(p^2*r-p*TAU); 

end
%%
Msize = 12;
figure
subplot(132)
plot(pvec,vH2*ones(size(pvec)),'r.',pvec,vH2_ex,'bo',pvec,vH2_app_2,'^k',pvec,vH2_app,'sk',pvec,vH2_ISO,'gv','linewidth',2.0,'Markersize',Msize);
legend('TRUE','EXACT','$f(p)=1+2p^2A$','$f(p)=1$','ISO','location','Best')
title('$v_h^2 [km/s]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
%hold on
%semilogy(p,vH2*ones(size(p)),'r.',p,((TAU.*q.*p-tau0*(p.*q.*r).^(1/2))./p-r.^2)./q./p.^2./TAU,'bo');

subplot(131)

plot(pvec,A*ones(size(p)),'r.',pvec,A_ex,'bo',pvec,A_app_2,'^k',pvec,A_app,'sk','linewidth',2.0,'Markersize',Msize);
title('$A=v_h^2-v_n^2 [km/s]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
subplot(133)

plot(pvec,tau0*ones(size(p)),'r.',pvec,tau0_ex,'bo',pvec,tau0_app_2,'^k',pvec,tau0_app,'sk',pvec,tau0_ISO,'gv','linewidth',2.0,'Markersize',Msize);
title('$\tau_0 [ms]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
%hold on
%semilogy(p,A*ones(size(p)),'r.',p,(TAU.*q.*p-tau0.*(p.*q.*r).^(1/2))./p.^3./q./TAU,'bo');
%%
figure
subplot(132)
plot(pvec,vH2*ones(size(pvec)),'r.',pvec,vH2_ex,'bo',pvec,vH2_app_2,'^k',pvec,vH2_app,'sk',pvec,vH2_ISO,'gv','linewidth',2.0,'Markersize',Msize);
legend('TRUE','EXACT','$f(p)=1+2p^2A$','$f(p)=1$','ISO','location','Best')
title('$v_h^2 [km/s]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
%hold on
%semilogy(p,vH2*ones(size(p)),'r.',p,((TAU.*q.*p-tau0*(p.*q.*r).^(1/2))./p-r.^2)./q./p.^2./TAU,'bo');

subplot(131)

plot(pvec,(vH2-A)*ones(size(p)),'r.',pvec,(vH2_ex-A_ex),'bo',pvec,(vH2_app_2-A_app_2),'^k',pvec,(vH2_app-A_app),'sk',pvec,vH2_ISO,'gv','linewidth',2.0,'Markersize',Msize);
title('$v_n^2 [km/s]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
subplot(133)

plot(pvec,tau0*ones(size(p)),'r.',pvec,tau0_ex,'bo',pvec,tau0_app_2,'^k',pvec,tau0_app,'sk',pvec,tau0_ISO,'gv','linewidth',2.0,'Markersize',Msize);
title('$\tau_0 [ms]$','interpreter','LATEX','FontSize',20)
xlabel('p [s/km]','interpreter','LATEX','FontSize',18)
set(gca,'Xlim',[pvec(1) pvec(end)])
%hold on
%semilogy(p,A*ones(size(p)),'r.',p,(TAU.*q.*p-tau0.*(p.*q.*r).^(1/2))./p.^3
%./q./TAU,'bo');


