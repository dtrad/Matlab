 function E = T_siliqi(m0,par)
 xm = par.xm;
 M = numel(xm);
 T0 = m0(1);
 tau0 = m0(2);

 m = [0:numel(xm)-1]';
 tn = par.tn;
 
 tn = par.tn;
 
 if par.par == 2
 Asili = m0(3);
 %dtM= (-1+(1+Asili*M^2-2*Asili*M+Asili)^(1/2))*tau0;
 %dtM=    (-1-(1+Asili*M^2-2*Asili*M+Asili)^(1/2))*tau0;
 else

 dtM = m0(3);
 Asili = (dtM^2+2*dtM*tau0)/tau0^2/(M-1)^2;
 end
 tsili = T0-tau0 + tau0*sqrt(1+ Asili*m.^2);
 %figure
 %plot(xm,tn,'b.',xm,tsili,'ro')
 
 E = tn-tsili;
