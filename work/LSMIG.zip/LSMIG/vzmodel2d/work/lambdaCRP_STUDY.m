%%%
clc
close all
clear all
A = 15/180*pi;
Lambda = linspace(-90,90,91)/180*pi;
Teta = linspace(0,90,181)/180*pi;
z_LCRP = zeros(numel(Teta),numel(Lambda));
NUM= z_LCRP;
DEN=z_LCRP;
RAD=z_LCRP;
for i=1:numel(Lambda)
    for j=1:numel(Teta)
L = Lambda(i);
T = Teta(j);
NUM(j,i)=cos(A)*(sin(L)^2-cos(T)^2);
RAD(j,i) = (1-sin(T)^2/cos(L)^2*cos(A)^2);
if RAD(j,i)<1e-12
    RAD(j,i)=NaN;
    
end
DEN(j,i) = cos(L)*(sin(A)*sin(L)-cos(T)*sqrt(RAD(j,i)));
z_LCRP(j,i)= NUM(j,i)/DEN(j,i);
%z_LCRP(j,i) = (NUM(j,i)*DEN(j,i))/(DEN(j,i)+eps).^2;


    end
end

figure,
imagesc(Lambda/pi*180,Teta/pi*180,z_LCRP);
caxis([0,1])
