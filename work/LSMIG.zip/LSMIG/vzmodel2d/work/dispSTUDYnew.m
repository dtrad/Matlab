%% this code test the goodness of some practical VTI approximations
% for dispersion relation... or christoffel relation q = f(p) | kz = f(kx)

%addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
addpath('/geodata10/casasanta/MATLAB/work/ferla/')
close all,
clear all,
clc,
e = 0.25;
d = -0.1;
vp0 = 3.2;
z0 = 1.240;
t0=2*z0/vp0;
eta = (e-d)/(1+2*d);
%%% f = 1-vs0^2/vp0^2 
VSVP=0.5;
f =  1-VSVP^2;

phi = linspace(0,90,45);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;
[V_EX_,phi_ex,vphase_ex]=group_from_phase(teta/180*pi,vp0,vp0*VSVP,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = interp1(phi_ex/pi*180,V_EX_,phi);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')
vn = vp0*sqrt(1+2*d);
vh = vp0*sqrt(1+2*e);
vn*sqrt(1+2*eta);

p = sind(phi)./vphase_ex;
taup_ex=vp0*t0*sqrt(1./vphase_ex.^2-p.^2);
%% taylor tau-p
p_int=linspace(p(1),p(end),2001);dp=diff(p_int(1:2));
taup_ex_i = interp1(p,taup_ex,p_int);
X=-gradient(taup_ex_i,dp);
t2=t0^2+X.^2/vn^2-2*eta*X.^4./(vn^2*(t0^2*vn^2+(1+2*eta)*X.^2));
taup_TAYLOR_i=sqrt(t2)-p_int.*X;
taup_TAYLOR=interp1(p_int,taup_TAYLOR_i,p);
%% ALKHA
NUM_ALKHA = 1-vh^2*p.^2;
DEN_ALKHA = 1 + (vn^2-vh^2)*p.^2;
taup_ALKHA = t0*(NUM_ALKHA./DEN_ALKHA ).^(1/2);

%%ALKHA approx
%q_ALKHA = 1/vp0*(NUM_ALKHA.*(1-(vn^2-vh^2)*p.^2)).^(1/2)
taup_ALKHA_approx = t0*(1-p.^2*vn^2-p.^4*vh^2*(vh^2-vn^2)).^(1/2)

%figure
%plot(p,(NUM_ALKHA./DEN_ALKHA ),'r.',p,NUM_ALKHA.*(1-(vn^2-vh^2)*p.^2),'bo')
%% BYUN
%NUM_BYUN = 1-vh^2*p.^2;
%DEN_BYUN = vp0^2 + (vn^2-vh^2)*p.^2-1;
S_ELL = ((vn^2)*(1+2*eta))*sin2+(vp0^2)*cos2
vf_BYUN = sqrt(( S_ELL + ((vn^2)-(vh^2))*(sin2.*cos2)));
Q = -1/2*(vp0^2*p.^2-1+vn^2*p.^2-(vp0^4*p.^4+2*vp0^2*p.^2+2*vp0^2*p.^4*vn^2+1-2*vn^2*p.^2+vn^4*p.^4-4*vp0^2*vh^2*p.^4).^(1/2))/vp0^2
A = vp0^2;
B = vp0^2*p.^2-1+vn^2*p.^2;
C = vh^2*p.^4-p.^2;
q = ((-B+sqrt(B.^2-4.*A.*C))/2./A)


figure
plot(p,sqrt(Q),p,sqrt(q))




taup_BYUN = vp0*t0*sqrt(vf_BYUN.^-2-p.^2);
%%

figure('name','taup')



plot(p,taup_ALKHA,'k^-',...
     p,taup_BYUN,'ks-',...
     p,taup_TAYLOR,'kv-','Markersize',8.0);     hold on
plot(p,taup_ex,'r','linewidth',2.0);
title('\tau(p) relation','interpreter','TEX','Fontsize',18)
legend('alkha','wea','taylor','exact','location','NorthWest')
set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness p (s/km)','interpreter','TEX','Fontsize',18)
ylabel('\tau (s)','interpreter','TEX','Fontsize',18)
set(gca,'Xlim',[min(p) max(p)*1.005],'Fontsize',18,'ydir','reverse')
%%
figure('name','error_taup')
plot(p,(taup_ALKHA-taup_ex)./taup_ex*100,'k^-',...
    p,(taup_BYUN-taup_ex)./taup_ex*100,'ks-',...
    p,(taup_TAYLOR-taup_ex)./taup_ex*100,'kv-','linewidth',1.0,'Markersize',8.0);
title('\tau(p) error','interpreter','TEX','Fontsize',18)
legend('alkha','wea','taylor','location','Best')
set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness p (s/km)','interpreter','TEX','Fontsize',18)
ylabel('Error %','interpreter','TEX','Fontsize',18)
set(gca,'Xlim',[min(p) max(p)*.99],'Fontsize',18)
%% 

