%% this code test the goodness of some practical VTI approximations
% for dispersion relation... or christoffel relation q = f(p) | kz = f(kx)

addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
close all,
clear all,
clc,
e = 0.25;
d = -0.1;
vp0 = 3.2;
z0 = 1240;
eta = (e-d)/(1+2*d);



phi = linspace(0,90,45);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;
[V_EX_,phi_ex,vphase_ex]=group_from_phase(teta/180*pi,vp0,vp0*0.6,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = INTERP1(phi_ex/pi*180,V_EX_,phi);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')
vn = vp0*sqrt(1+2*d);
vh = vp0*sqrt(1+2*e);
vn*sqrt(1+2*eta);

p = sind(phi)./vphase_ex;
%% ALKHA
NUM_ALKHA = 1-vh^2*p.^2;
DEN_ALKHA = 1 + (vn^2-vh^2)*p.^2;
q_ALKHA = 1/vp0*(NUM_ALKHA./DEN_ALKHA ).^(1/2);

%%ALKHA approx
%q_ALKHA = 1/vp0*(NUM_ALKHA.*(1-(vn^2-vh^2)*p.^2)).^(1/2)
q_ALKHA_approx = 1/vp0*(1-p.^2*vn^2-p.^4*vh^2*(vh^2-vn^2)).^(1/2)

%figure
%plot(p,(NUM_ALKHA./DEN_ALKHA ),'r.',p,NUM_ALKHA.*(1-(vn^2-vh^2)*p.^2),'bo')
%% BYUN
%NUM_BYUN = 1-vh^2*p.^2;
%DEN_BYUN = vp0^2 + (vn^2-vh^2)*p.^2-1;
%q_BYUN = (NUM_BYUN./DEN_BYUN ).^(1/2);
Q = -1/2*(vp0^2*p.^2-1+vn^2*p.^2-(vp0^4*p.^4+2*vp0^2*p.^2+2*vp0^2*p.^4*vn^2+1-2*vn^2*p.^2+vn^4*p.^4-4*vp0^2*vh^2*p.^4).^(1/2))/vp0^2
q_BYUN = sqrt(Q);
%%
figure('name','dipsersion relation q(p)')



plot(p,q_ALKHA,'k.-',...
     p,q_ALKHA_approx,'ks-',...
     p,q_BYUN,'k^-',...
     p,sqrt(1./vphase_ex.^2-p.^2),'r','linewidth',1.0);
title('Dispersion relation $q(p)$ [s/m]','interpreter','LATEX','Fontsize',18)
legend('ALKHA','BYUN','location','Best')
set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/m]','interpreter','LATEX','Fontsize',14)
ylabel('Vertical slowness $q(p)$ [s/m]','interpreter','LATEX','Fontsize',14)

%%
figure('name','phase velocity  v(p)')
plot(p,(1./sqrt(p.^2+q_ALKHA.^2)-vphase_ex)./vphase_ex*100,'k.-',...
    p,(1./sqrt(p.^2+q_ALKHA_approx.^2)-vphase_ex)./vphase_ex*100,'ks-',...
     p,(1./sqrt(p.^2+q_BYUN.^2)-vphase_ex)./vphase_ex*100,'k^-');
title('Phase velocity error \%','interpreter','LATEX','Fontsize',18)
legend('ALKHA','BYUN','location','Best')
set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/m]','interpreter','LATEX','Fontsize',14)
ylabel('Phase velocity $v_{ph}(p)$ [s/m]','interpreter','LATEX','Fontsize',14)
%%

