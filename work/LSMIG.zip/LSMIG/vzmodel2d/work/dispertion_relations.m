close all,clear all, clc

syms p q vp0 vh vn

F=(vh^2*p^2+vp0^2*q^2)+((vn^2-vh^2)*p^2*q^2)/(p^2+q^2)-1
simple(F)
Q = solve('(vh^2*p^2+vp0^2*Q)+((vn^2-vh^2)*p^2*Q)/(p^2+Q)-1','Q')
(simplify(q))

Q1  = -1/2*(vp0^2*p^2-1+vn^2*p^2-(vp0^4*p^4+2*vp0^2*p^2+2*vp0^2*p^4*vn^2+1-2*vn^2*p^2+vn^4*p^4-4*vp0^2*vh^2*p^4)^(1/2))/vp0^2
Q2  = -1/2*(vp0^2*p^2-1+vn^2*p^2+(vp0^4*p^4+2*vp0^2*p^2+2*vp0^2*p^4*vn^2+1-2*vn^2*p^2+vn^4*p^4-4*vp0^2*vh^2*p^4)^(1/2))/vp0^2
 
 A = (vp0^4*p^4+2*vp0^2*p^2+2*vp0^2*p^4*vn^2+1-2*vn^2*p^2+vn^4*p^4-4*vp0^2*vh^2*p^4)
 
A_collect =  collect(A,p)
 

 