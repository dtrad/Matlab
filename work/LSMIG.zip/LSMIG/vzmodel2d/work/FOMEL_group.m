clear all
syms eta vh vp0 vn S_ELL theta
sin2 = sin(theta)^2;
cos2 = cos(theta)^2;




A_FOMEL = 1/4/(1+eta);
B_FOMEL = (3+4*eta)*S_ELL;

NUM_C = (16*eta*(1+eta)*sin2.*cos2);
DEN_C = (1+2*eta)*vn^2*vp0^2 ;
C_FOMEL = S_ELL.^2 + NUM_C./ DEN_C ;
S_FOMEL =( A_FOMEL.*(B_FOMEL+sqrt(C_FOMEL)));
S_FOMEL_NEW = subs(S_FOMEL,eta, 1/2*( (vh^2/vn^2) - 1) );
a = (simple(S_FOMEL_NEW));
V_FOMEL = 1./S_FOMEL; 


1/4/(1/2+1/2*vh^2/vn^2)*((1+2*vh^2/vn^2)*S_ELL+(S_ELL^2+16*(1/2*vh^2/vn^2-1/2)*(1/2+1/2*vh^2/vn^2)*sin(theta)^2*cos(theta)^2/vh^2/vp0^2)^(1/2))

%1/2*(S_ELL*vn^2+2*S_ELL*vh^2+((S_ELL^2*vn^4*vh^2*vp0^2+4*cos(theta)^2*vh^4-4*cos(theta)^2*vn^4-4*cos(theta)^4*vh^4+4*cos(theta)^4*vn^4)/vn^4/vh^2/vp0^2)^(1/2)*vn^2)/(vn^2+vh^2)