syms t T0 S vn xm dtn tau0 xmax

t = T0+T0/S* (sqrt(1+(xm^2*S)/(T0^2*vn^2))-1 );
pretty(t)

dt_dvn = simple(diff(t,'vn',1))
%-1/vn^2/(T0^2*vn^2+xm^2*S)^(1/2)*xm^2

dt_dS = diff(t,'S',1)
%-T0/S^2*((1+xm^2*S/T0^2/vn^2)^(1/2)-1)+1/2/T0/S/(1+xm^2*S/T0^2/vn^2)^(1/2)*xm^2/vn^2

tsili = (T0-tau0)+ sqrt(tau0^2 + xm^2*(dtn*(2*tau0+dtn))/(xmax^2));
pretty(tsili)
dtsili_dtau0 = diff(tsili,'tau0',1) 
%-1+1/2/(tau0^2+xm^2*dtn*(2*tau0+dtn)/xmax^2)^(1/2)*(2*tau0+2*xm^2*dtn/xmax^2)
dtsili_dtn = diff(tsili,'dtn',1) 
%1/2/(tau0^2+xm^2*dtn*(2*tau0+dtn)/xmax^2)^(1/2)*(xm^2*(2*tau0+dtn)/xmax^2+xm^2*dtn/xmax^2)
