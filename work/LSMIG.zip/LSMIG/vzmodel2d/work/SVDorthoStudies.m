%% orthogonal parameteri zation for NMO... SVD studies
clear all
close all
addpath c:\P'rogram Files'\MATLAB\R2007b\work\OPTIMIZED\

%vn = 2537;
z0=1000;vp0=2000;del=-0.1;EPS=0.3;
vn = vp0*(sqrt(1+2*del));
eta = (EPS-del)/(1+2*del);
T0 = 1;


S = 8*eta+1;
vh = sqrt(vn^2*(1+2*eta));
M = 41;
dh = 50;
xm = (0:M-1)'*dh;
xCMP=3000;
xs = xCMP-xm/2;
xr = xm/2+xCMP;


% chiamo il tracciatore  per calcolare i tempi esatti
riflettore = [z0 0 0 0 0 0 1] ;
dati =[ vp0 vp0/2 EPS del 0 0 1000];
geometria = [xs zeros(size(xs)) zeros(size(xs))...
                                  xr zeros(size(xr)) zeros(size(xr)) ];
%[tempo,xp,yp,zp]=calcolo_tempi3D(dati,riflettore,nstrati,geometria,flag,M_
%depth,X_depth,Y_depth)
[t_EXACT,xp,yp,zp]=calcolo_tempi3D(dati,riflettore,1,geometria,1,[],[],[]);
t_EXACT=t_EXACT(:);
close

%%
C =  [T0;vn^-2/(2*T0);-S/(8*T0^3*vn^4)];
C2 = [T0;vn^-2; (1-S)/(4*T0^2*vn^4)];




k20 = (1/M)*sum(xm.^2);
k40 = (1/M)*sum(xm.^4);
k60 = (1/M)*sum(xm.^6);
k42 = (k60-k20*k40)/(k40-k20^2);
P = diag([1,k20,k40])

% matrice di trasformazione per i parametri ortogonali
R = [1 k20 k40; 0 1 k42; 0 0 1];
A = R*C;
A2 = R*C2;

R_2 = [1 k60/k40;0 1];
A_2 = R_2*C(2:3);



V = [ones(size(xm)) xm.^2 xm.^4]
VP = V*inv(P)
u0 = V(:,1); u2 = V(:,2)-k20*V(:,1); u4 = V(:,3)-k42*u2-k40*V(:,1);

%% parametrizzazione ortogonale assumendo che TO sia stimanto correttamente
% (t+n-T0) = V_2*C_2 = U_2*A_2
u2_2 = V(:,2); u4_2 =  V(:,3)-k60/k40*u2_2;
U_2 = [u2_2 u4_2];
U_2N = [u2_2/norm(u2_2) u4_2/norm(u4_2)];



U = [u0 u2 u4]
UP = U*inv(P);
UN = [u0/norm(u0) u2/norm(u2) u4/norm(u4)]


%solo 3 coeff
L = [ones(size(xm)) .5*(3*(xm/xm(end)).^2-1) (1/8)*(35*(xm/xm(end)).^4-30*(xm/xm(end)).^2+3)]
LN = [L(:,1)/norm(L(:,1)) L(:,2)/norm(L(:,2)) L(:,3)/norm(L(:,3))]

% solo 2 coeff;
l_2_1 = .5*(3*(xm/xm(end)).^2);
l_2_2 = (xm/xm(end)).^4-(10/21)*l_2_1;

L_2 = [l_2_1 l_2_2]
L_2N = [L_2(:,1)/norm(L_2(:,1)) L_2(:,2)/norm(L_2(:,2)) ]

[UV,SV,VV] = svd(V(:,1:3))
UVN = [ UV(:,1) UV(:,2) UV(:,3)];

%[UV,SV,VV] = svd(V(:,2:3))
%UVN = [UN(:,1) UV(:,1) UV(:,2)];

xx = xm/max(xm);

figure('name','basis function')
subplot(311)
plot(xx,UN(:,1),'bo'),hold on, plot(xx,LN(:,1),'r.');plot(xx,UVN(:,1),'k','linewidth',2.0);
legend('QR basis','Legendre','SVD basis')
subplot(312)
plot(xx,UN(:,2),'bo'),hold on, plot(xx,LN(:,2),'r.');plot(xx,UVN(:,2),'k','linewidth',2.0);
subplot(313)
plot(xx,UN(:,3),'bo'),hold on, plot(xx,LN(:,3),'r.');plot(xx,UVN(:,3),'k','linewidth',2.0);


figure('name','basis function 2 coeff')

subplot(211)
legend('QR basis','Legendre','SVD basis')
plot(xx,U_2N(:,1),'bo');hold on, plot(xx,L_2N(:,1),'r.');plot(xx,UVN(:,1),'k','linewidth',2.0);
subplot(212)
plot(xx,U_2N(:,2),'bo');hold on, plot(xx,L_2N(:,2),'r.');plot(xx,UVN(:,2),'k','linewidth',2.0);


%figure('name','difference')
%subplot(211)
%plot(xx,U_2N(:,1)-L_2N(:,1),'bo');
%subplot(212)
%plot(xx,U_2N(:,2)-L_2N(:,2),'bo');
%%



ht = figure('name','time models')
t= V*C;t2 =sqrt( V*C2);

%plot(xm,t_EXACT,'g','linewidth',2.0)
plot(xm,t_EXACT-t,'k>')
hold on
plot(xm,t_EXACT-t2,'k^')

corr_fact = 1.1
NUMalk =  2 *eta * V(:,3)
DENalk = (4*T0^2*vn^4) + corr_fact * vn^2*(1+2*eta)* V(:,2);
talk = V(:,1:2)*C2(1:2) + NUMalk./DENalk;
plot(xm,t_EXACT-sqrt(talk),'rv')


D = S/2;  % DA URSIN... 
%D = S-1;
NUMc =  C(3)*V(:,3);
DENc = 1+(D/(T0^2*vn^2))*V(:,2);
t_frac_C = V(:,1:2)*C(1:2) + NUMc./DENc
%fracfatt =1-2*C(3)/C(2)*xm.^2;
%t_frac_C_1 = C(1)+C(2)*xm.^2+C(3)./fracfatt.*xm.^4;

plot(xm,t_EXACT-t_frac_C,'b<')
%plot(xm,t_EXACT-t_frac_C_1,'b.')
tau0 = T0/S; %Siliqi
TM =[T0+T0/S*((1+(xm(end).^2*S)/(T0^2*vn^2)).^(1/2)-1)]';
tsili1 =[T0+T0/S*((1+(xm.^2*S)/(T0^2*vn^2)).^(1/2)-1)]';

dtM=(real(TM(end))-T0);

m = (0:M-1)';
Asili = (dtM^2+2*dtM*tau0)/tau0^2/(M-1)^2;
tsili = T0-tau0 + tau0*sqrt(1+m.^2/(M-1)^2*(dtM^2+2*dtM*tau0)/tau0^2);
tsili = T0-tau0 + tau0*sqrt(1+ Asili*m.^2);
tsili_tay = T0-tau0 + tau0*(1+Asili/2*m.^2-1/8*Asili.^2*m.^4);

plot(xm,t_EXACT-tsili,'mx')
hold on
%plot(xm,t_EXACT-tsili_tay,'ms')
legend('taylor','taylor2','Alkha','URSIN','Siliqi')

%% scrittura con parametri ortogonali
% taylor
K = [k20;k40];
invR = [1 -k20 k42*k20-k40;0 1 -k42;0 0 1];
unoM =ones(size(xm));
%t_ortho = T0+U(:,2:3)*A(2:3)+K'*invR(2:3,2:3)*A(2:3);
%t_ortho = T0+U(:,2:3)*A(2:3)+unoM*K'*invR(2:3,2:3)*A(2:3);
Q = (U(:,2:3)+unoM*K'*invR(2:3,2:3));
QN = [Q(:,1)/norm(Q(:,1)) Q(:,2)/norm(Q(:,2))];
t_ortho =  T0+Q*A(2:3);
%t_ortho = T0+U(:,2:3)*A(2:3)
Q2 = (U(:,2:3)+unoM*K'*invR(2:3,2:3));
t_ortho2 = sqrt(T0+Q2*A2(2:3));

figure(ht)
plot(xm,t_EXACT-t_ortho,'k.')
plot(xm,t_EXACT-t_ortho2,'k.')



ts = 0.004;
Niter = 1000;
Cstim = zeros(2,Niter);
Astim = Cstim;
%%
for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = t+n;
    tn=t_EXACT+n;
    Cstim(:,i) = pinv(V(:,2:3))*(tn-T0*V(:,1));
    Astim(:,i) = pinv(Q)*(tn-T0*V(:,1));
        
end
    
CC=corrcoef(Cstim(1,:)-C(2),Cstim(2,:)-C(3))
CA=corrcoef(Astim(1,:)-A(2),Astim(2,:)-A(3))

figure('name','orthogonal parameterization scatter plot')
subplot(131)
plot((Cstim(1,:)-C(2))/C(2)*100,(Cstim(2,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-A(2))/A(2)*100,(Astim(2,:)-A(3))/A(3)*100,'r.')
axis square

%%
Cstim = zeros(3,Niter);
Astim = zeros(3,Niter);

for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = t+n;
        tn=t_EXACT+n;
    Cstim(:,i) = inv(P)*pinv(VP)*(tn);
    Astim(:,i) = pinv(U)*(tn);
        
end

%CC=corrcoef(Cstim(1,:)-C(2),Cstim(2,:)-C(3))
CA=corrcoef(Astim(1,:)-A(2),Astim(2,:)-A(3))

subplot(132)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-A(2))/A(2)*100,(Astim(3,:)-A(3))/A(3)*100,'r.')
axis square



%%

Cstim = zeros(2,Niter)
Astim = Cstim;

for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = t+n;
        tn=t_EXACT+n;
    Cstim(:,i) = pinv(V(:,2:3))*(tn-T0*V(:,1));
    Astim(:,i) = pinv(U_2)*(tn-T0*V(:,1));
        
end
    


CC=corrcoef(Cstim(1,:)-C(2),Cstim(2,:)-C(3))
CA=corrcoef(Astim(1,:)-A_2(2),Astim(2,:)-A_2(2))

subplot(133)
plot((Cstim(1,:)-C(2))/C(2)*100,(Cstim(2,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-A_2(1))/A_2(1)*100,(Astim(2,:)-A_2(2))/A_2(2)*100,'r.')
axis square
%% applico la correzione per stimare correttamente c4
Cstim = zeros(3,Niter);
Astim = zeros(3,Niter);

for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = t+n;
        tn=t_EXACT+n;
    Cstim(:,i) = inv(P)*pinv(VP)*(tn);
    Astim(:,i) = pinv(U)*(tn);
        
end
    
Cstim_2 = inv(R)*Astim
c4_stim = Cstim_2(3)*Cstim_2(2)./(2*Cstim_2(3)*xm.^2+Cstim_2(2))


CC=corrcoef(Cstim_2(2,:)-C(2),Cstim_2(3,:)-C(3))
CA=corrcoef(Astim(2,:)-A(2),Astim(2,:)-A(3))

figure('name','orthogonal parameterization scatter plot')
subplot(130)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-A(2))/A(2)*100,(Astim(3,:)-A(3))/A(3)*100,'r.')
axis square


%%  vedo se con fractional approximaqtion la stima rimane orthogonale
%T_frac_ortho_3param = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*x^2+a4/(1+a4/(a2-k42*a4)*x^2)*x^4
Niter = 200
Cstim = zeros(3,Niter);
Astim = Cstim;

  par.xm = xm;
par.k20 =  k20;
par.k40 = k40 ;
par.k42 = k42 ;
par.P = P;

a0=A(1);
a2=A(2);
a4=A(3);

fracfatt = 2*a4./(a2-k42*a4);

C0 = P*C;
A0 = P*A;

tortho_frac = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*xm.^2+a4./(1-fracfatt.*xm.^2).*xm.^4;

OPTIONS = optimset
OPTIONS.MaxFunEvals = 1000;
OPTIONS.MaxIter = 1000;
OPTIONS.Display = 'On';
for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = t_frac_C+n;
    tn=t_EXACT+n;
    par.tn = tn;
    tempC =  lsqnonlin(@(m) T_frac_3param(m,par),C0,[],[],OPTIONS);
    Cstim(:,i) = inv(P)*tempC;    
    tempA =  lsqnonlin(@(m) T_frac_ortho_3param(m,par),A0,[],[],OPTIONS);
    Astim(:,i) = inv(P)*tempA;    
end
    



figure('name','normal(blue) VS ortho applied to frac approx (red)')


CC=corrcoef(Cstim(1,:)-C(1),Cstim(3,:)-C(3))
CA=corrcoef(Astim(1,:)-A(1),Astim(3,:)-A(3))
subplot(131)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-A(1))/A(1)*100,(Astim(3,:)-A(3))/A(3)*100,'r.')
axis square

CC=corrcoef(Cstim(1,:)-C(1),Cstim(2,:)-C(2))
CA=corrcoef(Astim(1,:)-A(1),Astim(2,:)-A(2))
subplot(132)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(2,:)-C(2))/C(2)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-A(1))/A(1)*100,(Astim(2,:)-A(2))/A(2)*100,'r.')
axis square

CC=corrcoef(Cstim(2,:)-C(2),Cstim(3,:)-C(3))
CA=corrcoef(Astim(2,:)-A(2),Astim(3,:)-A(3))
subplot(133)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-A(2))/A(2)*100,(Astim(3,:)-A(3))/A(3)*100,'r.')
axis square

%% vedo Siliqi orthogonal parameterization approximaqtion la stima rimane orthogonale
%T_frac_ortho_3param = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*x^2+a4/(1+a4/(a2-k42*a4)*x^2)*x^4
Niter = 200
Cstim = zeros(3,Niter);
Astim = Cstim;
par.xm = xm;
Asili = (dtM^2+2*dtM*tau0)/tau0^2/(M-1)^2;
tsili = T0-tau0 + tau0*sqrt(1+ Asili*m.^2)
tsili_tay = T0-tau0 + tau0*(1+Asili/2*m.^2-1/8*Asili.^2*m.^4)

C = A;
a0=A(1);
a2=A(2);
a4=A(3);

fracfatt = 2*a4./(a2-k42*a4);
tortho_frac_1 = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*xm.^2+a4./(1-fracfatt.*xm.^2).*xm.^4;

%tortho_frac = a0-k20*a2+(k20*k42-k40)*a4+(a2-k42*a4)*xm.^2+a4./(1-2*a4./(a2-k42*a4).*xm.^2).*xm.^4;


par.xm = xm;
par.k20 =  k20;
par.k40 = k40 ;
par.k42 = k42 ;
par.P = P;

m0_sili = [T0;tau0;dtM];
OPTIONS = optimset
OPTIONS.MaxFunEvals = 1000;
OPTIONS.MaxIter = 1000;
OPTIONS.Display = 'Off';
par.par=3;
for i = 1:Niter
    n = ts*randn(size(xm));
    %tn = tortho_frac+n;
    %tn = tsili+n;
        tn=t_EXACT+n;
    par.tn = tn;
    temp =  lsqnonlin(@(m) T_frac_ortho_3param(m,par),P*A,[],[],OPTIONS);
    Cstim(:,i) = inv(P)*temp; 
    Astim(:,i) =  lsqnonlin(@(m) T_siliqi(m,par),m0_sili,[],[],OPTIONS);
      
end
    



figure('name','ortho applied to frac approx (blue) vs Siliqi ortho (red)')


CC=corrcoef(Cstim(1,:)-C(1),Cstim(3,:)-C(3))
CA=corrcoef(Astim(1,:)-m0_sili(1),Astim(3,:)-m0_sili(3))
subplot(131)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0_sili(1))/m0_sili(1)*100,(Astim(3,:)-m0_sili(3))/m0_sili(3)*100,'r.')
axis square
xlabel('coeff 0'),ylabel('coeff 4')

CC=corrcoef(Cstim(1,:)-C(1),Cstim(2,:)-C(2))
CA=corrcoef(Astim(1,:)-m0_sili(1),Astim(2,:)-m0_sili(2))
subplot(132)
plot((Cstim(1,:)-C(1))/C(1)*100,(Cstim(2,:)-C(2))/C(2)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(1,:)-m0_sili(1))/m0_sili(1)*100,(Astim(2,:)-m0_sili(2))/m0_sili(2)*100,'r.')
axis square
xlabel('coeff 0'),ylabel('coeff 2')

CC=corrcoef(Cstim(2,:)-C(2),Cstim(3,:)-C(3))
CA=corrcoef(Astim(2,:)-m0_sili(2),Astim(3,:)-m0_sili(3))
subplot(133)
plot((Cstim(2,:)-C(2))/C(2)*100,(Cstim(3,:)-C(3))/C(3)*100,'.')
title(['\rho(c) = ',num2str(CC(1,2)),' \rho(a) = ',num2str(CA(1,2))])
hold on
plot((Astim(2,:)-m0_sili(2))/m0_sili(2)*100,(Astim(3,:)-m0_sili(3))/m0_sili(3)*100,'r.')
axis square
xlabel('coeff 2'),ylabel('coeff 4')



%%










