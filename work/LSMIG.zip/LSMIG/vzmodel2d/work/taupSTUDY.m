%% this code test the goodness of some practical VTI approximations for
% moveout kinematic in taup domain

addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
close all,
clear all,
clc,
e = 0.2;
d = -0.1;
vp0 = 3.2;
z0 = 1240;
eta = (e-d)/(1+2*d)
tau0 = 2*z0/vp0;


phi = linspace(1,89.9,25);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;
[V_EX_,phi_ex,vphase_ex]=group_from_phase(teta/180*pi,vp0,vp0*0.5,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = INTERP1(phi_ex/pi*180,V_EX_,phi);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')
vN2 = (vp0*sqrt(1+2*d)).^2;
vH2 = (vp0*sqrt(1+2*e)).^2;
sqrt(vN2)
sqrt(vH2)
p = sind(phi)./vphase_ex;
%% ESATTA tau(p) = vp0*q(p)*tau0
q = sqrt((1./vphase_ex.^2)-p.^2);
taup_ex = q*vp0*tau0;

%% ALKHA
NUM_ALKHA = 1-vH2*p.^2;
DEN_ALKHA = 1 - (vH2-vN2)*p.^2;


taup_ALKHA = tau0*(NUM_ALKHA./DEN_ALKHA ).^(1/2);
TAU=taup_ALKHA;
%%ALKHA approx
A = (vH2-vN2);
DEN_ALKHA_1 = 1 + (vH2-vN2)*p.^2;
taup_ALKHA_1=tau0*NUM_ALKHA.^(1/2).*DEN_ALKHA_1.^(1/2);
taup_ALKHA_1=tau0*(1-p.^2*(vN2)-p.^4*(vH2*(vH2-vN2))).^(1/2);

%NUM_ALKA_2=1-vH2/2*p.^2;
DEN_ALKHA_2 = 1 + (vH2-vN2)/2*p.^2;
taup_ALKHA_2 = tau0*NUM_ALKHA.^(1/2).*DEN_ALKHA_2;

% r1 = tau0^2./TAU.*p.*(A-vH2)./(1-p.^2*A).^2;

% r_approx = tau0^2./TAU.*p.*(A-vH2)./(1-p.^2*A).^2;
% figure
% subplot(221)
% semilogy(p,abs(r),'r.',p,abs(r_approx),'bo');%,p,abs(r_approx_1),'k.')
% subplot(223)
% plot(p,(r-r_approx)./r*100,'bo');%,p,(r-r_approx_1)./r*100,'k.')
% set(gca,'Ylim',[-100 100])

%%
figure('name','tau-p')
plot(p,taup_ex,'r','linewidth',3.0)
hold on
plot(p,taup_ALKHA,'ks-',...
     p,taup_ALKHA_1,'k>-',...
     p,taup_ALKHA_2,'k<-','linewidth',1.0);
    
     
title('$\tau-p$ reflection moveout','interpreter','LATEX','Fontsize',18)

set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/km]','interpreter','LATEX','Fontsize',14)
ylabel('$\tau(p)$ [ms]','interpreter','LATEX','Fontsize',14)
set(gca,'ydir','reverse'),box on,
legend('exact','ALKHA','ALKHA_1','ALKHA_2','location','Best')
%%
figure('name','tau-p error')


plot(p,(taup_ALKHA-taup_ex)./taup_ex*100,'ks-',...
     p,(taup_ALKHA_1-taup_ex)./taup_ex*100,'k>-',...
     p,(taup_ALKHA_2-taup_ex)./taup_ex*100,'k<-','linewidth',1.0);
     
     
title('$\tau-p$ error $\%$','interpreter','LATEX','Fontsize',18)

set(gca','ygrid','on','box','on')
xlabel('Horizontal slowness $p$ [s/km]','interpreter','LATEX','Fontsize',14)
ylabel('Error $\%$','interpreter','LATEX','Fontsize',14)
set(gca,'ydir','reverse'),box on,
legend('ALKHA','ALKHA_1','ALKHA_2','location','Best')






