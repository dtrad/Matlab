%% this code test the goodness of some practical VTI approximations

addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
%close all,
clear all
e = 0.25
d = -0.1
vp0 = 3.2;
z0 = 1240;
eta = (e-d)/(1+2*d);



phi = linspace(0,90,45);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;
[V_EX_,phi_ex,v_EX,dv_EX]=group_from_phase(teta/180*pi,vp0,vp0*0.6,e,d,sind(teta),sin2,cosd(teta),cos2);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')
%% derivata dv/dtheta = v*n*etheta
for i=1:numel(phi)
N = [sin(phi_ex(i)) cos(phi_ex(i))]'; % versore di gruppo
e_phi = [cosd(phi(i)) -sind(phi(i))]'; % derivata versore n di fase
f(i) = N'*e_phi;
dv_EX_1(i) = V_EX_(i)*N'*e_phi
end

s_EX = 1./(v_EX);


vn = vp0*sqrt(1+2*d);
vh = vp0*sqrt(1+2*e);
vn*sqrt(1+2*eta);

%% Elliptical square group Slowness
%S_ELL = (vh^-2)*sin2+(vp0^-2)*cos2; % function of Vhorizontal
S_ELL = vh^2*sin2+(vp0^2)*cos2; % function of eta
%% Thomsen WEA approximation
%S_WEA = sqrt( (vp0^-2)*(1-2*d*sin2-2*(e-d)*(sin2.*sin2)));
%S_WEA = (vp0^-2)*(1-2*d*sin2-2*eta*(sin2.*sin2));
v_WEA = vp0*(1+.5*((vn^2/vp0^2)-1)*sin2.*cos2+.5*((vh^2/vp0^2)-1)*sin2.*sin2);


%S_WEA = (vp0)^(-1)*(1+.5*((vn^2/vp0^2).^(-1)-1)*sin2.*cos2+.5*((vh^2/vp0^2).^(-1)-1)*sin2.*sin2);
%S_WEA = .5*(vp0)^(-1)*(1+cos2+((vn^2/vp0^2).^(-1))*sin2.*cos2+((vh^2/vp0^2).^(-1))*sin2.*sin2);
s_WEA = 1./v_WEA;%.5*(vp0)^(-1)*(1+cos2+vp0^2*(vn^-2-vh^-2)*sin2.*cos2+((vh^2/vp0^2).^(-1))*sin2);
%sqrt( vp0^2(1+(vn^2/vp0^2-1)*sin2.*cos2+(vh^2-vp0^2)*sin2.*sin2));

%% HARLAN similar to Byun (Byun leaves free the choice of the third
% constrain on velocity) 
v_P4 = sqrt(( S_ELL + ((vn^2)-(vh^2))*(sin2.*cos2)));
%S_P4 = sqrt(( S_ELL + (vn^-2)* (2*eta)/(1+2*eta)*(sin2.*cos2)));
%S_P4 =sqrt( (vp0^-2)*cos2 + (vn^-2).*sin2.*cos2+ (vh^-2).*(sin2.*sin2));

s_P4 = 1./(v_P4);



%% FOMEL (Shifted Hyperbola...)
A_FOMEL = 1/4/(1+eta);
B_FOMEL = (3+4*eta)*S_ELL;
NUM_C = (16*eta*(1+eta)*sin2.*cos2);
DEN_C = (1+2*eta)*vn^-2*vp0^-2 ;
C_FOMEL = S_ELL.^2 + NUM_C./ DEN_C ;
%C_FOMEL = S_ELL.^2 + (16*eta*(1+eta)*sin2.*cos2)./ ( (1+2*eta)*vn^2*vp0^2 ) ;

S_FOMEL =sqrt( A_FOMEL.*(B_FOMEL+sqrt(C_FOMEL)));

A_FOMEL = 1/2/(vn^2+vh^2)*vh^2;
B_FOMEL = (vh^2+2*vn^2)/vh^2*S_ELL;
A_FOMEL.*B_FOMEL 

A_FOMEL = 1;
B_FOMEL = (1/2)*(vh^2+vn^2+vn-2)/(vn^2+vh^2)*S_ELL;
B_FOMEL = (1/2)*(1+vn^2/(vn^2+vh^2))*S_ELL;
A_FOMEL.*B_FOMEL
c = 1/2/(vn^2+vh^2)*vh^2; 

NUM_C = sin22*(+vn^2-vh^2)*(+vn^2+vh^2);
DEN_C = vh^2*vp0^-2;
C_FOMEL = S_ELL.^2 + NUM_C./ DEN_C ;
v_FOMEL =sqrt( A_FOMEL.*(B_FOMEL+c*sqrt(C_FOMEL)));



s_FOMEL = 1./v_FOMEL; 





%% TSVAN
%A_TSVAN = cos2/vp0^2+sin2/vn^2;
A_TSVAN = S_ELL+((vn^2)-(vh^2))*(sin2);
%B_TSVAN = -(2*eta*sin2.*sin2) ./ ( vn.^2*( (vn^2/vp0^2)*cos2+(1+2*eta)*sin2));
%B_TSVAN = (-1) *((vn^-4) * ((vn^-2)-(vh^-2))*(sin2).*sin2)./(cos2*(vp0^-2*vh^-2)+vn^-4*sin2);
%S_TSVAN = sqrt(A_TSVAN +B_TSVAN );
NUM_TSVAN  = ((vn^2)-(vh^2))*(sin2).*cos2;
DEN_TSVAN = cos2+((vn^4)/(vp0^2)/(vh^2))*(sin2);
v_TSVAN = sqrt(S_ELL+NUM_TSVAN./DEN_TSVAN);
s_TSVAN = 1./v_TSVAN;

%% SP_1 STOPIN AND ALKHA

%S_P1 =sqrt(.5*( S_ELL + sqrt(S_ELL.^2+(vp0^(-2))*(vn^(-2)-vh^(-2))*sin22)));
v_P1 =sqrt(.5*( S_ELL + sqrt(S_ELL.^2+(vp0^(2))*(vn^(2)-vh^(2))*sin22)));
s_P1 = 1./v_P1;
%%
figure('name','phase velocity error plot')



plot(phi,(v_EX-v_WEA)./v_EX*100,'k.-',...
     phi,(v_EX-v_P4)./v_EX*100,'k--',...
     phi,(v_EX-v_FOMEL)./v_EX*100,'ko-',...
     phi,(v_EX-v_TSVAN)./v_EX*100,'kv-',...
     phi,(v_EX-v_P1)./v_EX*100,'k^-','linewidth',1.0);
title('Phase velocity $v(\theta)$ [s/m] error','interpreter','LATEX','Fontsize',18)
legend('WEA','BYUN','FOMEL','TSVAN','ALKHA','location','Best')
set(gca','ygrid','on','box','on')
xlabel('Phase angle $\theta$ [deg]','interpreter','LATEX','Fontsize',14)
ylabel('Relative error (\%)','interpreter','LATEX','Fontsize',14)
%%
figure('name','group velocity error plot')

plot(phi,(s_EX-s_WEA)./s_EX*100,'k.-',...
     phi,(s_EX-s_P4)./s_EX*100,'k--',...
     phi,(s_EX-s_FOMEL)./s_EX*100,'ko-',...
     phi,(s_EX-s_TSVAN)./s_EX*100,'kv-',...
     phi,(s_EX-s_P1)./s_EX*100,'k^-');%
 legend('WEA','BYUN','FOMEL','TSVAN','ALKHA','location','Best')
title('Phase slowness $s(\theta)$ [s/m] error','interpreter','LATEX','Fontsize',18)
set(gca','ygrid','on','box','on')
xlabel('Phase angle $\theta$ [deg]','interpreter','LATEX','Fontsize',14)
ylabel('Relative error (\%)','interpreter','LATEX','Fontsize',14)
%%



