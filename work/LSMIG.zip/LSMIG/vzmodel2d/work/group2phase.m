syms th Sv Sh Sn tanG

c2 = cos(th)^2;
s2 = sin(th)^2;
s22 = sin(2*th)^2;

Sell = Sv^2*c2+Sh^2*s2;


Svti =sqrt(.5*( Sell + sqrt(Sell^2+Sv^2*(Sn^2-Sh^2)*s22)));

pretty(Svti)

dSvti_dth = (simple(diff(Svti,1,'th')))

%1/4/(2*Sv^2*cos(th)^2+2*Sh^2*sin(th)^2+2*((Sv^2*cos(th)^2+Sh^2*sin(th)^2)^2+...
%Sv^2*(Sn^2-Sh^2)*sin(2*th)^2)^(1/2))^(1/2)*(-4*Sv^2*cos(th)*sin(th)+4*Sh^2*sin(th)*cos(th)+...
%1/((Sv^2*cos(th)^2+Sh^2*sin(th)^2)^2+Sv^2*(Sn^2-Sh^2)*sin(2*th)^2)^(1/2)*...
%(2*(Sv^2*cos(th)^2+Sh^2*sin(th)^2)*(-2*Sv^2*cos(th)*sin(th)+2*Sh^2*sin(th)*cos(th))+4*Sv^2*(Sn^2-Sh^2)*sin(2*th)*cos(2*th)))

pretty(dSvti_dth)

S_P = sqrt(Svti.^2+dSvti_dth);

A_G = (1./Svti)+dSvti_dth
tanP = (tanG+A_G)./ (1-A_G.*tanG) 

pretty(tanP)