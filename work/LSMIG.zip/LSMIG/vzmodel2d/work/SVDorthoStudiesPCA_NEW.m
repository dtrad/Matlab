%% orthogonal parameteri zation for NMO... SVD studies
clear all,warning off
close all
addpath ./OPTIMIZED
%vn = 2537;
z0=1000;vp0=2386;del=0.1;EPS=0.3520;
vN = vp0*(sqrt(1+2*del));
eta = (EPS-del)/(1+2*del);
S = 8*eta+1;
vH = sqrt(vN^2*(1+2*eta));
M = 81;
dh = 50;
xm = (0:M-1)'*dh;
X = [ones(size(xm)) xm.^2 xm.^4];
xCMP=3000;
xs = xCMP-xm/2;
xr = xm/2+xCMP;

T0 = 2*z0/vp0;
ts = 4*1e-3;
% chiamo il traccivISOatore  per calcolare i tempi esatti
riflettore = [z0 0 0 0 0 0 1] ;
dati =[ vp0 vp0/2 EPS del 0 0 1000];
geometria = [xs zeros(size(xs)) zeros(size(xs))...
    xr zeros(size(xr)) zeros(size(xr)) ];


C_EXACT =  [T0;vN^-2/(2*T0);-S/(8*T0^3*vN^4)];
% different model for validation... does the ortho function for model
% EXACT work for another model with different depth and parameters ?
T0_VALID = T0;
vN_VALID=vN*0.7;
S_VALID=S*1.3;
eta_VALID=1/8*(S_VALID-1);
C_VALID = [T0_VALID;vN_VALID^-2/(2*T0_VALID);-S_VALID/(8*T0_VALID^3*vN_VALID^4)];
z0_VALID=T0_VALID/2*vp0;
riflettore_VALID =  [z0_VALID 0 0 0 0 0 1] ;
delta_VALID= .5*((vN_VALID/vp0)^2-1);
eps_VALID=.5*((vN_VALID*sqrt(1+2*eta_VALID)/vp0)^2-1);
dati_VALID=[ vp0 vp0/2 eps_VALID delta_VALID 0 0 1000];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

model =  1;test=1;
switch model
    case 1
        
        [t_EXACT]=calcolo_tempi3D(dati,riflettore,1,geometria,0,[],[],[]);     
        t_EXACT=t_EXACT(:);
        [t_VALID]=calcolo_tempi3D(dati_VALID,riflettore_VALID,1,geometria,0,[],[],[]);     
        t_VALID=t_VALID(:);
    case 2
        FRAC=1-2*C_EXACT(3)/C_EXACT(2)*xm.^2;
        t_EXACT = T0+xm.^2*C_EXACT(2)+C_EXACT(3)./FRAC.*xm.^4;
        
        FRAC_VALID=1-2*C_VALID(3)/C_VALID(2)*xm.^2;
        t_VALID = T0_VALID+xm.^2*C_VALID(2)+C_VALID(3)./FRAC_VALID.*xm.^4;
    case 3,
        t_EXACT = T0+xm.^2*C_EXACT(2)+C_EXACT(3).*xm.^4;
        t_VALID = T0_VALID+xm.^2*C_VALID(2)+C_VALID(3).*xm.^4;
    otherwise
end
sigma_noise=0;%10*0.004;
t_EXACT=t_EXACT+sigma_noise*randn(size(t_EXACT));

%% Intervalli di parametri anisotropici
%vp0min=1500;vp0max=4750;
perc=.50;

C2_min=(1-perc)*C_EXACT(2);C2_max=(1+perc)*C_EXACT(2);
C3_min=(1-perc)*C_EXACT(3);C3_max=(1+perc)*C_EXACT(3);
%T0min = 0; T0max=3;

N = 51;

%C2_test=linspace(C2_min,C2_max,N);
%C3_test=linspace(C3_min,C3_max,N);
T = zeros(numel(xm),N);
Cmat = zeros(2,N);
if test==1,hwait=waitbar(0,'Computing reference functions');end
j=1;
while j<=N % this generate refernce function for orthogonal basis coputations
    
    %Generate uniform values from the interval [a, b].
    %r = a + (b-a).*rand(100,1);  
    C2_test = C2_min+(C2_max-C2_min)*rand(1,1);
    C3_test = C3_min+(C3_max-C3_min)*rand(1,1);
    CC =  [T0,C2_test,C3_test];
    
    T0_test=CC(1);
    vp0_test=2*z0/(T0_test);
    
    
    vN_test= sqrt(1/2/C2_test/T0_test);
    delta_test= .5*((vN_test/vp0_test)^2-1);
    S_test  = -2*T0_test*C3_test/C2_test^2;
    eta_test = 1/8*(S_test-1);
    eps_test=.5*((vN_test*sqrt(1+2*eta_test)/vp0_test)^2-1);
    if eps_test>0.5 || eps_test<-0.2 || delta_test>0.5 || delta_test<-0.3
    
    else
    eps_test
    %equal spaced sampled model
    %CC = [T0,C2_test(j),C3_test(j)];
    %CC = [T0,C2_test(N-j+1),C3_test(j)];
    
    
    switch test
        case 1
           
            riflettore_test =  [z0 0 0 0 0 0 1] ;
            
            dati_test=[ vp0_test vp0_test/2 eps_test delta_test 0 0 1000];
            
            
            
            t_j=calcolo_tempi3D(dati_test,riflettore_test,1,geometria,0,[],[],[])-T0_test;            
            waitbar(j/N,hwait)
        case 2
            fracfatt =1-2*CC(3)/CC(2)*xm.^2;
            t_j = CC(2)*xm.^2+CC(3)./fracfatt.*xm.^4;
        case 3,
            t_j = CC(2)*xm.^2+CC(3).*xm.^4;
        otherwise
    end


T(:,j) = t_j(:);
Cmat(:,j) = [CC(2);CC(3)];
j=j+1;
    end


end
if test==1,close(hwait);end

figure
plot(xm,t_EXACT-T0,'k','linewidth',2.0),hold on
plot(xm,t_VALID-t_VALID(1),'b','linewidth',2.0)
legend('exact','valid')
plot(xm,T,'r:')

%% SVD
[U,LAMBDA,V] = svd(T);
p=min(M,N);
Up = U(:,1:p);
LAMBDAp = LAMBDA(1:p,1:p);
Vp = V(:,1:p);
W = LAMBDAp*Vp';
H = Vp*diag(1./diag((LAMBDAp)));
f=T*H;
eigenvalues=diag(LAMBDA);
figure
plot(xm,U(:,1),'k-','linewidth',3.0),hold on
plot(xm,U(:,2),'k--','linewidth',3.0),
plot(xm,U(:,3),'k-.','linewidth',3.0),
plot(xm,U(:,4),':','linewidth',1.0,'color',[0.3 0.3 0.3])
plot(xm,U(:,5),'o-','linewidth',1.0,'color',[0.3 0.3 0.3])
legend('u_2(x)','u_3(x)','u_4(x)','u_5(x)','u_6(x)')
figure
subplot(1,4,[1:3]);
imagesc(real(10*log10(W))),
subplot(1,4,4)
semilogy(eigenvalues,'k','Linewidth',3.0)
Ncoeff=2;
T_Ncoeff = U(:,1:Ncoeff)*W(1:Ncoeff,:);
%figure
%plot(T-T_Ncoeff,'k:')

Usvd = U(:,1:Ncoeff);
Hsvd = H(:,1:Ncoeff);
%t_EXACT=t_VALID
%C_EXACT=C_VALID
%vN=vN_VALID
%eta=eta_VALID
%%
A_stim = pinv(Usvd)*(t_EXACT-t_EXACT(1));
t_svd = Usvd*A_stim+t_EXACT(1);
t_new = X(:,2:3)*Cmat*Hsvd(:,1:2)*A_stim(1:2)+t_EXACT(1);
C_stim_SVD = Cmat*Hsvd(:,1:2)*A_stim(1:2);

fracfatt_new =1-2*C_stim_SVD(2)/C_stim_SVD(1)*xm.^2;
%t_new_frac = C_stim_SVD(1)+ C_stim_SVD(2)*xm.^2+C_stim_SVD(3)./fracfatt_new.*xm.^4;
t_new_frac = t_EXACT(1) + C_stim_SVD(1)*xm.^2+C_stim_SVD(2)./fracfatt_new.*xm.^4;


C_stim_LS = pinv(X(:,2:3))*(t_EXACT-t_EXACT(1));
t_LS = X(:,2:3)*C_stim_LS+t_EXACT(1);

figure('name','estimated traveltimes')
plot(xm,t_EXACT,'k','linewidth',2.0),set(gca,'ydir','reverse'),hold on
plot(xm,t_svd,'bo-'), % T by SVD
hold on
plot(xm,t_new_frac,'rv-')
plot(xm,t_LS,'gs-')
legend('exact','svd','frac recon','LS')
figure('name','error in traveltime estimation')
plot(xm,(t_svd-t_EXACT)./t_EXACT*100,'bo-','linewidth',1.0),hold on

plot( xm,(t_new_frac-t_EXACT)./t_EXACT*100,'rv-','linewidth',1.0)
plot( xm,(t_LS-t_EXACT)./t_EXACT*100,'gs-','linewidth',1.0),
legend('svd','frac recon','LS')
set(gca,'ylim',[-0.25 0.25])



%%%

errC_LS = [C_stim_LS-C_EXACT(2:3)]./C_EXACT(2:3)*100;
vN_LS = sqrt(1/2/C_stim_LS(1)/t_EXACT(1));
S_LS  = -2*T0*C_stim_LS(2)/C_stim_LS(1)^2;
eta_LS = 1/8*(S_LS-1);
err_LS=[(vN_LS-vN)/vN*100 (eta_LS-eta)/eta*100];
clc
fprintf('\nESTIMATION ERRORS\n\n')
fprintf('LS Error VN: %2.2f %% eta : %2.2f %%\n\n',err_LS(1),err_LS(2))
%%% 
errC_svd = [C_stim_SVD-C_EXACT(2:3)]./C_EXACT(2:3)*100;
vN_svd = sqrt(1/2/C_stim_SVD(1)/t_EXACT(1));
S_svd  = -2*T0*C_stim_SVD(2)/C_stim_SVD(1)^2;
eta_svd = 1/8*(S_svd-1);
err_svd=[(vN_svd-vN)/vN*100 (eta_svd-eta)/eta*100];
fprintf('SVD Error VN: %2.2f %% eta : %2.2f %%\n\n',err_svd(1),err_svd(2))
%% VALIDAZIONE su modello a profondit? diversa
A_stim_VALID = pinv(Usvd)*(t_VALID-t_VALID(1));
C_stim_VALID_SVD = Cmat*Hsvd(:,1:2)*A_stim_VALID(1:2);
C_stim_VALID_LS = pinv(X(:,2:3))*(t_VALID-t_VALID(1));


figure('name','validation')
plot(xm,t_VALID,'k','linewidth',2.0);hold on
t_svd_VALID = Usvd*A_stim_VALID+t_VALID(1);
t_LS_VALID = X(:,2:3)*C_stim_VALID_LS+t_VALID(1);
plot(xm,t_svd_VALID,'bo-');
fracfatt_VALID =1-2*C_stim_VALID_SVD(2)/C_stim_VALID_SVD(1)*xm.^2;
t_new_frac_VALID = t_VALID(1)+ C_stim_VALID_SVD(1)*xm.^2+C_stim_VALID_SVD(2)./fracfatt_VALID.*xm.^4;
plot(xm,t_new_frac_VALID,'rv-')
plot(xm,t_LS_VALID,'gs-')
legend('exact','svd','frac recon','LS')
figure('name','error in traveltime estimation (VALIDATION)')
plot(xm,(t_svd_VALID-t_VALID)./t_VALID*100,'bo-','linewidth',1.0),hold on
plot( xm,(t_new_frac_VALID-t_VALID)./t_VALID*100,'rv-','linewidth',1.0)
plot( xm,(t_LS_VALID-t_VALID)./t_VALID*100,'gs-','linewidth',1.0),
set(gca,'ylim',[-0.25 0.25])
legend('svd','frac recon','LS')

%%%

errC_VALID_LS = [C_stim_VALID_LS-C_VALID(2:3)]./C_VALID(2:3)*100;
vN_VALID_LS = sqrt(1/2/C_stim_VALID_LS(1)/t_VALID(1));
S_VALID_LS  = -2*t_VALID(1)*C_stim_VALID_LS(2)/C_stim_VALID_LS(1)^2;
eta_VALID_LS = 1/8*(S_VALID_LS-1);
err_VALID_LS=[(vN_VALID_LS-vN_VALID)/vN_VALID*100 (eta_VALID_LS-eta_VALID)/eta_VALID*100];
fprintf('ESTIMATION ERRORS (VALIDATION)\n\n')
fprintf('LS Error VN: %2.2f %% eta : %2.2f %%\n\n',err_VALID_LS(1),err_VALID_LS(2))
%%% 
errC_VALID_svd = [C_stim_VALID_SVD-C_VALID(2:3)]./C_VALID(2:3)*100;
vN_VALID_svd = sqrt(1/2/C_stim_VALID_SVD(1)/t_VALID(1));
S_VALID_svd  = -2*t_VALID(1)*C_stim_VALID_SVD(2)/C_stim_VALID_SVD(1)^2;
eta_VALID_svd = 1/8*(S_VALID_svd-1);
err_VALID_svd=[(vN_VALID_svd-vN_VALID)/vN_VALID*100 (eta_VALID_svd-eta_VALID)/eta_VALID*100];
fprintf('SVD Error VN: %2.2f %% eta : %2.2f %%\n\n',err_VALID_svd(1),err_VALID_svd(2))




