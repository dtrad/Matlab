%% orthogonal parameteri zation for NMO... SVD studies
clear all
close all
addpath C:\P'rogram Files'\MATLAB\R2007b\work\OPTIMIZED\
%vn = 2537;
z0=4000;vp0=2386;del=0.1;EPS=0.3520;
vN = vp0*(sqrt(1+2*del));
eta = (EPS-del)/(1+2*del);
S = 8*eta+1;
vH = sqrt(vN^2*(1+2*eta));
M = 161;
dh = 50;
xm = (0:M-1)'*dh;
X = [ones(size(xm)) xm.^2 xm.^4];
xCMP=3000;
xs = xCMP-xm/2;
xr = xm/2+xCMP;
V = [ones(size(xm)) xm.^2 xm.^4];
T0 = 2*z0/vp0;
% ts = 4*1e-3;
% chiamo il traccivISOatore  per calcolare i tempi esatti
riflettore = [z0 0 0 0 0 0 1] ;
dati =[ vp0 vp0/2 EPS del 0 0 1000];
geometria = [xs zeros(size(xs)) zeros(size(xs))...
    xr zeros(size(xr)) zeros(size(xr)) ];
C_EXACT =  [T0;vN^-2/(2*T0);-S/(8*T0^3*vN^4)];


% modello a profondit� diversa per validazione
T0_VALID = 1.3*T0;
z0_VALID = vp0*T0_VALID/2;

C_VALID = [T0_VALID;vN^-2/(2*T0_VALID);-S/(8*T0_VALID^3*vN^4)];
riflettore_VALID =  [z0_VALID 0 0 0 0 0 1] ;

model =  2;
switch model
    case 1
        
        [t_EXACT]=calcolo_tempi3D(dati,riflettore,1,geometria,0,[],[],[]);     
        t_EXACT=t_EXACT(:);
        [t_VALID]=calcolo_tempi3D(dati,riflettore_VALID,1,geometria,0,[],[],[]);     
        t_VALID=t_VALID(:);
    case 2
        FRAC=1-2*C_EXACT(3)/C_EXACT(2)*xm.^2;
        t_EXACT = T0+xm.^2*C_EXACT(2)+C_EXACT(3)./FRAC.*xm.^4;
        
        FRAC_VALID=1-2*C_VALID(3)/C_VALID(2)*xm.^2;
        t_VALID = T0+xm.^2*C_VALID(2)+C_VALID(3)./FRAC_VALID.*xm.^4;
    case 3,
        t_VALID = T0+xm.^2*C_VALID(2)+C_VALID(3).*xm.^4;
    otherwise
end
sigma_noise=0;10*0.004;
t_EXACT=t_EXACT+sigma_noise*randn(size(t_EXACT));

%% Intervalli di parametri anisotropici
vp0min=1500;vp0max=4750;
delmin=-0.1;delmax=0.3;
etamin=0.0;etamax=0.5;
T0min = 0; T0max=3;

N = 501;
if model==1,hwait=waitbar(0,'Computing reference functions');end
for j=1:N % this generate refernce function for orthogonal basis coputations
    %Generate uniform values from the interval [a, b].
    %r = a + (b-a).*rand(100,1);
    %vN_test = vNmin+(vNmax-vNmin)*rand(1,1);

    vp0_test = vp0min+(vp0max-vp0min)*rand(1,1);
    del_test = delmin+(delmax-delmin)*rand(1,1);
    eta_test = etamin+(etamax-etamin)*rand(1,1);
    
    %T0_test  = T0min+(T0max-T0min)*rand(1,1);
    T0_test=2*z0/vp0_test;
    
    S_test = 8*eta_test+1;
    %T0_test=sigma*randn(1,1)+T0;
    vN_test=vp0_test*(1+2*del_test)^(1/2);


    CC =  [T0_test;vN_test^-2/(2*T0_test);-S_test/(8*T0_test^3*vN_test^4)];
    switch model
        case 1
            z0_test = T0_test/2*vp0_test;
            EPS_test=eta_test*(1+2*del_test)+del_test;
            dati_test =[ vp0_test vp0_test/2 EPS_test del_test 0 0 1000];
            riflettore_test = [z0_test 0 0 0 0 0 1] ;
            t_j=calcolo_tempi3D(dati_test,riflettore_test,1,geometria,0,[],[],[]);            
            waitbar(j/N,hwait)
        case 2
            fracfatt =1-2*CC(3)/CC(2)*xm.^2;
            t_j = CC(1)+ CC(2)*xm.^2+CC(3)./fracfatt.*xm.^4;
        case 3,
            t_j = CC(1)+CC(2)*xm.^2+CC(3).*xm.^4;
        otherwise
    end


T(:,j) = t_j(:);
Cmat(:,j) = [CC(1);CC(2);CC(3)];
end
if model==1,close(hwait);end

figure
plot(xm,t_EXACT,'k','linewidth',2.0)
hold
plot(xm,T,'r:')

%% SVD
[U,S,V] = svd(T);
p=min(M,N);
Up = U(:,1:p);
Sp = S(1:p,1:p);
Vp = V(:,1:p);
W = Sp*Vp';
H = Vp*diag(1./diag((Sp)));
f=T*H;
eigenvalues=diag(S);
figure
plot(xm,U(:,1),'k-','linewidth',3.0),hold on
plot(xm,U(:,2),'k--','linewidth',3.0),
plot(xm,U(:,3),'k-.','linewidth',3.0),
plot(xm,U(:,4),':','linewidth',1.0,'color',[0.3 0.3 0.3])
plot(xm,U(:,5),'o-','linewidth',1.0,'color',[0.3 0.3 0.3])
legend('u_1(x)','u_2(x)','u_3(x)','u_4(x)','u_5(x)')
figure
subplot(1,4,[1:3]);
imagesc(real(10*log10(W))),
subplot(1,4,4)
semilogy(eigenvalues,'k','Linewidth',3.0)
Ncoeff=3;
T_Ncoeff = U(:,1:Ncoeff)*W(1:Ncoeff,:);
figure
plot(T-T_Ncoeff,'k:')

Usvd = U(:,1:Ncoeff);
Hsvd = H(:,1:Ncoeff);
%%
A_stim = pinv(Usvd)*t_EXACT;
t_svd = Usvd*A_stim
t_new = X*Cmat*Hsvd*A_stim;
C_stim_SVD = Cmat*Hsvd*A_stim;

fracfatt_new =1-2*C_stim_SVD(3)/C_stim_SVD(2)*xm.^2;
t_new_frac = C_stim_SVD(1)+ C_stim_SVD(2)*xm.^2+C_stim_SVD(3)./fracfatt_new.*xm.^4;

C_stim_LS = pinv(X)*t_EXACT;
t_LS = X*C_stim_LS;
figure
plot(xm,t_EXACT,'b.'),set(gca,'ydir','reverse'),hold on
plot(xm,Usvd*A_stim,'ro'),
hold on
plot(xm,t_new_frac,'vr')
plot(xm,X*C_stim_LS,'ks')
figure
plot((t_svd-t_EXACT)./t_EXACT*100,'k-','linewidth',2.0),hold on
plot( (t_LS-t_EXACT)./t_EXACT*100,'k--','linewidth',2.0),
plot( (t_new_frac-t_EXACT)./t_EXACT*100,'k-.','linewidth',2.0)
set(gca,'ylim',[-20 20])

errC_LS = [C_stim_LS-C_EXACT]./C_EXACT*100
errC_svd = [C_stim_SVD-C_EXACT]./C_EXACT*100

%% VALIDAZIONE su modello a profondit� diversa
A_stim_VALID = pinv(Usvd)*t_VALID;
C_stim_VALID_SVD = Cmat*Hsvd*A_stim_VALID;
figure('name','validazione')
plot(xm,t_VALID,'b.');hold on
t_svd_VALID = Usvd*A_stim_VALID;
plot(xm,t_svd_VALID,'ro');
fracfatt_VALID =1-2*C_stim_VALID_SVD(3)/C_stim_VALID_SVD(2)*xm.^2;
t_new_frac_VALID = C_stim_VALID_SVD(1)+ C_stim_VALID_SVD(2)*xm.^2+C_stim_VALID_SVD(3)....
    ./fracfatt_VALID.*xm.^4;
plot(xm,t_new_frac_VALID,'vr')


errC_VALID_svd = [C_stim_VALID_SVD-C_VALID]./C_VALID*100




