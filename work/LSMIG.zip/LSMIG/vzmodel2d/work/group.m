%% this code test the goodness of some practical VTI approximations

addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
close all,
clear all
e = 0.2
d = -0.05
vp0 = 3.2;
z0 = 1240;
eta = (e-d)/(1+2*d);



phi = linspace(0,90,91);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);

[V_EX_,phi_ex]=group_from_phase(teta/180*pi,vp0,0,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = INTERP1(phi_ex/pi*180,V_EX_,phi);
%figure
%    plot(phi_ex*180/pi,V_EX_,'b.');hold on
%    plot(phi,V_EX,'ro')

S_EX = 1./(V_EX);


vn = vp0*sqrt(1+2*d);
vh = vp0*sqrt(1+2*e);
vn*sqrt(1+2*eta);

%% Elliptical square group Slowness
%S_ELL = (vh^-2)*sin2+(vp0^-2)*cos2; % function of Vhorizontal
S_ELL = 1/((vn^2)*(1+2*eta))*sin2+(vp0^-2)*cos2; % function of eta
%% Thomsen WEA approximation
%S_WEA = sqrt( (vp0^-2)*(1-2*d*sin2-2*(e-d)*(sin2.*sin2)));
%S_WEA = (vp0^-2)*(1-2*d*sin2-2*eta*(sin2.*sin2));
V_WEA = vp0*(1+.5*((vn^2/vp0^2)-1)*sin2.*cos2+.5*((vh^2/vp0^2)-1)*sin2.*sin2);
S_WEA = (vp0)^(-1)*(1+.5*((vn^2/vp0^2).^(-1)-1)*sin2.*cos2+.5*((vh^2/vp0^2).^(-1)-1)*sin2.*sin2);
%sqrt( vp0^2(1+(vn^2/vp0^2-1)*sin2.*cos2+(vh^2-vp0^2)*sin2.*sin2));

%% HARLAN similar to Byun (Byun leaves free the choice of the third
% constrain on velocity) 
%S_P4 = ( S_ELL + ((vn^-2)-(vh^-2))*(sin2.*cos2));
S_P4 = sqrt(( S_ELL + (vn^-2)* (2*eta)/(1+2*eta)*(sin2.*cos2)));
V_P4 = 1./(S_P4);

%%
alollo = (cos2+(vp0/vn)^2*sin2+((vp0/vh)^2-(vp0/vn)^2)*(sin2.*sin2));
%alollo2 = (cos2+(vp0/vn)^2*sin2+((vp0/vh)^2*


Slollo = (vp0^-2)*alollo;
%Slollo2 = (vp0^-2)*alollo2;
Slollo2 = (vp0^-2)*cos2+(1/vn)^2*sin2+(-2*eta)*(1/vh)^2*(sin2.*sin2);


aSG2 =.5*(1+cos2+(vp0/vn)^2*sin2+((vp0/vh)^2-(vp0/vn)^2)*(sin2.*sin2));
SG2 = (vp0^-1)*aSG2;
% FOMEL
VF2 = vp0^2*cos2+(vn^2-vh^2)*sin2.*cos2+vh^2*sin2;


%Sbyun = vh^(-2) + (vp0^(-2)-2*vh^(-2)+vn^(-2))*cos2+(vh^(-2)-vn^(-2))*cos2.*cos2;
Sbyun = vp0^(-2) + (+vn^(-2)- vp0^(-2))*sin2+(-vn^(-2)+vh^(-2))*(sin2.*sin2);

%%
figure('name','group slowness error plot')



plot(phi,(S_EX-S_WEA)./S_EX*100,'k',...
     phi,(S_EX-S_P4)./S_EX*100,'k--')%,...
     %phi,abs(S_EX-Slollo)./S_EX*100,'ko-',...
     %phi,abs(S_EX-SG2.^2)./S_EX*100,'k.-',...
     %phi,abs(S_EX-Slollo2)./S_EX*100,'k^-');
title('group slowness error')
set(gca','ygrid','on')
%%
figure('name','group velocity error plot')

plot(phi,(V_EX-V_WEA)./V_EX*100,'k',...
     phi,(V_EX-V_P4)./V_EX*100,'k--')%,...
%      phi,1./sqrt(S_P4),'r',...
%      phi,1./sqrt(Slollo),'ko',...
%      phi,1./SG2,'b.-',...
%      phi,1./sqrt(Slollo2),'ms',...
%      phi,sqrt(1./Sbyun),'b^',...
%      phi,sqrt(VF2),'gx');
title('group velocity  error')
set(gca','ygrid','on')
% figure
% plot(phi,sqrt(alollo),'b--',phi,(aSG2),'ro')


%% 

vp0_m = vp0*0.95;
d_m = d*1.18;
e_m = e*1.18;

%ISOTROPIC INVERSION
%vp0_m = vn;
%d_m = 0;
%e_m = 0;

vn_m = vp0_m*sqrt(1+2*d_m);
gamma = vp0_m/vp0;
eta_m = (e_m-d_m)/(1+2*d_m);
vh_m = vp0_m*sqrt(1+2*e_m);

 
 
% z0_m = z0*gamma;
% 
% figure
% plot(h/z0, 1./(z0.^2+h.^2),'b',h/z0,(h.^2)./(z0.^2),'r.',h/z0,(h.^2)./(z0.^2)-(h.^4)./(z0.^4),'k.')
% 
% 
% 
% figure
% plot(h/z0,(h.^4)./(z0_m.^2+h.^2),'b',h/z0,(h.^4)./(z0.^2+h.^2),'r.',h/z0,(h.^4)./(gamma^2*(z0.^2+h.^2)),'k.')



%%
RMO1 =((gamma*z0)^2+...
       vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...   
         ( (eta_m*vn^2/vn_m^2) - (eta*vn_m^2/vn^2))*(2*h.^4./(h.^2+z0.^2)));
    %( (eta_m*vn^2/vn_m^2) - (eta*vn_m^2/vn^2))*(2*h.^4./(0+z0.^2)));
RMOinterm = ((gamma*z0)^2+...
       vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...        
        ( (eta_m/gamma^2) - (eta*gamma^2))*(2*h.^4./(h.^2+z0.^2)));    
        %( (eta_m/gamma^2) - (eta*gamma^2))*(2*h.^4./(0+z0.^2)));   
 %bT = -2*eta*(vp0/vh)^2;
 %bM = -2*eta_m*(vp0_m/vh_m)^2;
  
 
 RMOlollo = ((gamma*z0)^2+...
       vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...       
     (eta_m*(vh/vh_m)^2-eta*(vh_m/vh)^2 )*(2*h.^4./(h.^2+z0.^2) ));
   %(bT*gamma^2-bM/gamma^2)*(h.^4./(h.^2+z0.^2) ));
   %( (eta_m/(1+2*eta_m)*vp0^2/vn_m^2) - (eta/(1+2*eta)*vp0_m^2/vn^2))*(2*h.^4./(h.^2+z0.^2)));
         %( (eta_m/(1+2*eta_m)*vp0^2/vn_m^2) - (eta/(1+2*eta)*vp0_m^2/vn^2))*(2*h.^4./(0+z0.^2))); 
      
      %   
figure('name','RMO h^4/(h^2+z0^2)')     
    subplot(211)
   
    plot(h/z0,RMO1,'b',h/z0,RMOinterm,'k',h/z0,RMOlollo,'r'),set(gca,'ydir','reverse')
     title('z^2_{RMO}(h)')
   subplot(212) 
  
    plot(h/z0,sqrt(RMO1),'b',h/z0,sqrt(RMOinterm),'k',h/z0,sqrt(RMOlollo),'r'),set(gca,'ydir','reverse')
     title('z_{RMO}(h)')
    
%     %%
% RMO1 =((gamma*z0)^2+...
%        vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...   
% ( (eta_m*vn^2/vn_m^2) - (eta*vn_m^2/vn^2))*(2*h.^4./(0+z0.^2)));
% RMOinterm = ((gamma*z0)^2+...
%        vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...        
% ( (eta_m/gamma^2) - (eta*gamma^2))*(2*h.^4./(0+z0.^2)));   
% RMOlollo = ((gamma*z0)^2+...
%        vp0_m^2*(vn^(-2)-vn_m^(-2))*h.^2+...     
% ( (eta_m/(1+2*eta_m)*vp0^2/vn_m^2) - (eta/(1+2*eta)*vp0_m^2/vn^2))*(2*h.^4./(0+z0.^2))); 
%     figure('name','RMO h^4/z0^2')    
%     subplot(211)
%     
%     
%     plot(h/z0,RMO1,'b',h/z0,RMOinterm,'k',h/z0,RMOlollo,'r')
%     title('z^2_{RMO}(h)'),set(gca,'ydir','reverse')
%    subplot(212)
%   
%     plot(h/z0,sqrt(RMO1),'b',h/z0,sqrt(RMOinterm),'k',h/z0,sqrt(RMOlollo),'r')
%      title('z_{RMO}(h)'),set(gca,'ydir','reverse')