clear all
close all
addpath c:\P'rogram Files'\MATLAB\R2007b\work\OPTIMIZED\

%vn = 2537;
z0=1000;vp0=2386-500;del=0.1;EPS=0.3520;
vN = vp0*(sqrt(1+2*del));
eta = (EPS-del)/(1+2*del);



S = 8*eta+1;
vH = sqrt(vN^2*(1+2*eta));
M = 31;
dh = 50;
xm = (0:M-1)'*dh;
xCMP=3000;
xs = xCMP-xm/2;
xr = xm/2+xCMP;
V = [ones(size(xm)) xm.^2 xm.^4];
T0 = 2*z0/vp0;
% chiamo il traccivISOatore  per calcolare i tempi esatti
riflettore = [z0 0 0 0 0 0 1] ;
dati =[ vp0 vp0/2 EPS del 0 0 1000];
geometria = [xs zeros(size(xs)) zeros(size(xs))...
                                  xr zeros(size(xr)) zeros(size(xr)) ];
C_EXACT =  [T0;vN^-2/(2*T0);-S/(8*T0^3*vN^4)];

model = 1
switch model
    case 1
[t_EXACT,xp,yp,zp]=calcolo_tempi3D(dati,riflettore,1,geometria,1,[],[],[]);
t_EXACT=t_EXACT(:);
close
    case 2
FRAC=1-2*C_EXACT(3)/C_EXACT(2)*xm.^2;
t_EXACT = T0+xm.^2*C_EXACT(2)+C_EXACT(3)./FRAC.*xm.^4;
    case 3,
t_EXACT = T0+xm.^2*C_EXACT(2)+C_EXACT(3)*xm.^4;
    otherwise
end
sigma_noise=0;2*0.004;
t_EXACT=t_EXACT+sigma_noise*randn(size(t_EXACT));

%% Compute traveltime relative to partial NMO Correction
%  imposing the shape parameters for partial correction
partialNMO = 0; 
if partialNMO
% fixing the velocity and eta parameters for the correction
vN_PARTIAL = vN*1.1;
eta_PARTIAL = eta*1.1;
S_PARTIAL = 8*eta_PARTIAL+1;
% compute the C0 C2 C4 coefficients
C_PARTIAL = [T0;vN_PARTIAL^-2/(2*T0);-S_PARTIAL/(8*T0^3*vN_PARTIAL^4)];

% compute the partial traveltime
FRAC_PARTIAL =1-2*C_PARTIAL(3)/C_PARTIAL(2)*xm.^2;
%t_PARTIAL = C_PARTIAL(1)+C_PARTIAL(2)*xm.^2+C_PARTIAL(3)./FRAC_PARTIAL.*xm.^4;
t_PARTIAL = C_PARTIAL(1)+C_PARTIAL(2)*xm.^2+C_PARTIAL(3)*xm.^4;
% compute the residual values
c2_NMO=C_EXACT(2)-C_PARTIAL(2);
c4_NMO=C_EXACT(3)-C_PARTIAL(3);

c4_siliqi  = -1/8/T0^3* ( -2*vN_PARTIAL.^(-2)*(vN^(-2)-vN_PARTIAL^(-2)) )

t_NMO_analitic = T0+c2_NMO*xm.^2+(c4_NMO)*xm.^4;
t_NMO_analitic_siliqi = T0+c2_NMO*xm.^2+(c4_NMO+c4_siliqi)*xm.^4;
t_NMO = T0+t_EXACT-t_PARTIAL;


else
% we perform an initial isotropic estimation and using that velocity
% we perform the partial NMO correction

% taylor fitting
        C_ISO = pinv(V(:,1:2))*t_EXACT
        %C_ISO = pinv(V(:,2))*(t_EXACT-T0);
        t_PARTIAL = T0 + V(:,2)*C_ISO(end);
        vN_PARTIAL = sqrt( (2*T0*C_ISO(end))^(-1))
% square taylor fitting
        %C_ISO = pinv(V(:,1:2))*t_EXACT.^2;
        %C_ISO = pinv(V(:,2))*(t_EXACT.^2-T0.^2);
        %t_PARTIAL = sqrt(T0.^2 + V(:,2)*C_ISO(end));
        %vN_PARTIAL = sqrt( (C_ISO(end))^(-1))
t_NMO = T0+t_EXACT-t_PARTIAL;


eta_PARTIAL=0;
S_PARTIAL = 8*eta_PARTIAL+1;
C_PARTIAL = [T0;vN_PARTIAL^-2/(2*T0(1));-S_PARTIAL/(8*T0(1)^3*vN_PARTIAL^4)];
%C_PARTIAL = [T0;vN_PARTIAL^-2/(2*T0);-S_PARTIAL/(8*T0^3*vN_PARTIAL^4)];

c2_NMO=C_EXACT(2)-C_PARTIAL(2);
c4_NMO=C_EXACT(3)-C_PARTIAL(3);

c4_siliqi  = -1/8/T0^3* ( -2*vN_PARTIAL.^(-2)*(vN^(-2)-vN_PARTIAL^(-2)))

t_NMO_analitic = T0+c2_NMO*xm.^2+(c4_NMO)*xm.^4;
t_NMO_analitic_siliqi = T0+c2_NMO*xm.^2+(c4_NMO+c4_siliqi)*xm.^4;

end
%%



ht = figure('name','traveltimes');
subplot(121)

plot(xm,t_EXACT,'k-','linewidth',3.0),hold on
set(gca,'ydir','reverse')
title(['traveltimes for X/D = ',num2str(xm(end)/z0)])
set(gca,'xlim',[xm(1)-10 xm(end)+10])
plot(xm,t_PARTIAL,'k--','linewidth',3.0)
legend('EXACT','PARTIAL NMO','location','best')
subplot(122)
title(['RMOs for X/D = ',num2str(xm(end)/z0)])


plot(xm,t_NMO,'r.','linewidth',2.0),hold on
plot(xm,t_NMO_analitic,'bo','linewidth',2.0)
plot(xm,t_NMO_analitic_siliqi,'bv','linewidth',2.0)
set(gca,'ylim',[T0*.9 T0*1.1])
set(gca,'xlim',[xm(1)-10 xm(end)+10])
set(gca,'ydir','reverse')
%% ORTHOGONAL PROCESSING
k20 = (1/M)*sum(xm.^2);
k40 = (1/M)*sum(xm.^4);
k60 = (1/M)*sum(xm.^6);
ORTHO=2;
switch ORTHO
    case 3,

k42 = (k60-k20*k40)/(k40-k20^2);

P = diag([1,k20*M,k40*M]);




R = [1 k20 k40; ... %transformation matrix
     0   1 k42; ...
     0   0  1]; 
invR = [1 -k20    k42*k20-k40 ; ... %back transformation matrix
        0    1           -k42 ; ...
        0    0              1];

%VP = V*inv(P);
% basis function
u0 = V(:,1); 
u2 = V(:,2)-k20*V(:,1); 
u4 = V(:,3)-k42*u2-k40*V(:,1);
U = [u0(:) u2(:) u4(:)];

%A_stim = pinv(U)*t_NMO;
A_stim(1) = pinv(U(:,1))*(t_NMO);
A_stim(2) = pinv(U(:,2))*(t_NMO);
A_stim(3) = pinv(U(:,3))*(t_NMO);
A_stim = A_stim(:);


C_stim = invR*A_stim;
plot(xm,U*A_stim,'mo')
    case 2,
k42 = k60/k40;
R = [1 k42; 0 1];
invR = inv(R);
u2 = V(:,2);
u4 = V(:,3)-k42*V(:,2);
U = [u2(:) u4(:)];
%A_stim = pinv(U)*(t_NMO-T0);
A_stim(1) = pinv(U(:,1))*(t_NMO-T0);
A_stim(2) = pinv(U(:,2))*(t_NMO-T0);
A_stim = A_stim(:);

C_stim(1) = 0; C_stim(2:3) = invR*A_stim;  
plot(xm,U*A_stim+T0,'mo')
    otherwise
end

legend('true','analitical','analitical corr','best fit','location','best')
%vNstim = sqrt( (Cstim(2)*2*Cstim(1)+vN_PARTIAL.^(-2))^(-1))
vN_stim = sqrt( (C_stim(2)*2*T0+vN_PARTIAL.^(-2))^(-1));

S_stim = -1*(8*T0^3*C_stim(3)-S_PARTIAL*vN_PARTIAL.^(-4))*vN_stim^4;
eta_stim = 1/8*(S_stim-1);


err_perc_vN = (vN_stim-vN)/vN*100



err_perc_S  = (S_stim-S)/S*100
err_perc_eta= (eta_stim-eta)/eta*100

% considering siliqi correction factor
S_stim_siliqi = -1*(8*T0^3*(C_stim(3)-c4_siliqi)-S_PARTIAL*vN_PARTIAL.^(-4))*vN_stim^4;
err_perc_S_siliqi  = (S_stim_siliqi-S)/S*100

eta_stim_siliqi = 1/8*(S_stim_siliqi-1);
err_perc_eta_siliqi = (eta_stim_siliqi-eta)/eta*100








