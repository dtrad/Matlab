syms G L A T z z0 z1 rho 
% A = alpha
% T = theta
% G = gamma
% L = lambda
% rho = rho = v/v'= vmig/vtrue

t_z1 = cos(A)*cos(G)/(cos(A)^2-sin(G)^2);
t_z  = cos(L)*cos(T)/(cos(L)^2-sin(T)^2);

% z1 = f(z)
z1 = t_z/t_z1*z/rho;
%pretty(z1)
% sin(G) = f(A,L,T)

fG=((sin(T)/cos(L)*cos(A)))*rho;

%z0 = f

h_z0_1 = - (sin(L)*cos(L))/(cos(L)^2-sin(T)^2);
%h_z0_2 = simple(subs((1-sin(G)^2)/(cos(A)^2-sin(G)^2),sin(G),fG))
h_z0_2 = (cos(G)^2)/(cos(A)^2-sin(G)^2);

z0 = simple(tan(A) * h_z0_1*z+h_z0_2*z1);
z0_subs =simple( subs(z0,(G),fG));

N = simple(cos(L)*z*(-sin(A)*sin(L)*rho+cos(G)*cos(T)));
D = (cos(L)^2-1+cos(T)^2)*cos(A)*rho;

simple(z0_subs-N/D);

cosG = cos(asin(fG));


LCRP = solve(N/D-1,z)
LCRP = simple(subs(solve(N/D-1,z),cos(G),cosG));



%% RMO alla biondo  %DZ = Z(T)-Z(T=0)
Z_Teta0 = simple(subs(subs(LCRP,T,0),L,A));
RMO = simple(subs(LCRP,L,A)-Z_Teta0);

%% horizontal reflectors
HOR = simple(subs(RMO,A,0)) ;


DHOR = subs(simple(diff(HOR,1,rho)),rho,1)  ; %% = Tan(T).^2
DHOR =(simple(subs(DHOR,1-sin(T)^2,cos(T)^2)))

linHOR = DHOR*(rho-1); % linearized version
%% dipping reflector
DDIP1 = subs(diff(subs(LCRP,L,A),1,rho),rho,1)
DDIP1 =(simple(subs(DDIP1,1-sin(A)^2,cos(A)^2)))
DDIP1 =(simple(subs(DDIP1,-1+sin(A)^2,-cos(A)^2)))
DDIP1 =(simple(subs(DDIP1,1-sin(T)^2,cos(T)^2)))


DDIP2 =  subs(diff(Z_Teta0,1,rho),rho,1)
DDIP2 =(simple(subs(DDIP2,1-sin(A)^2,cos(A)^2)))

DDIP =(simple(DDIP1-DDIP2))
linDIP = DDIP*(rho-1)
%% Storiaccie con i difrattori
DIFF_T=simple(subs(LCRP,A,L));
%simple(subs(subs(LCRP,A,0),T,0))
% per teta=0


LRMO_T = simple(DIFF_T-subs(DIFF_T,L,0));

%% LRMO per difrattore a theta = 0 (zero offset)
DIFF_0=simple(subs(DIFF_T,T,0));
LRMO_0 = DIFF_0-subs(DIFF_0,L,0);
DLRMO_0 = simple(subs(diff(LRMO_0,1,rho),rho,1));
LRMO_0_lin = (rho-1)*DLRMO_0;

%% LRMO per diffratore a theta generale


DLRMO_T = simple(subs(diff(LRMO_T,1,rho),rho,1));
DLRMO_T =(simple(subs(DLRMO_T,1-sin(T)^2,cos(T)^2)))
DLRMO_T =(simple(subs(DLRMO_T,1-sin(T)^2,cos(T)^2)))
DLRMO_T =(simple(subs(DLRMO_T,1-cos(L)^2,sin(L)^2)))
DLRMO_T =(simple(subs(DLRMO_T,1-sin(T)^2,cos(T)^2)))
LRMO_T_lin = (rho-1)*DLRMO_T;

%% traiettoria a tangenza nulla


NUM = (sin(L)^2-cos(T)^2)*cos(A);
RAD = (1/rho^2 - sin(T)^2*cos(A)^2/cos(L)^2);
DEN = cos(L)*(sin(A)*sin(L)-sqrt(RAD)*cos(T));
z_LCRP = NUM/DEN;
simple(z_LCRP-LCRP);

%pretty(simple(diff(z_LCRP,1,L)))
%solve(dL,L)
%%
clc

sprintf('equation for theta = 0, that is zero offset\n')
pretty(simple(subs(LCRP,T,0)))
sprintf('RMO for horizontal reflectors\n')
pretty(HOR)
sprintf('linearized RMO (rho=1) for horizontal reflectors')
pretty(linHOR)
sprintf('RMO for dipping reflectors\n')
pretty(RMO)
sprintf('linearized RMO (rho=1) for dipping reflectors')
pretty(linDIP)

%%
sprintf('equation for espressing moveout of a diffractor when L-CRP is sxactly on the top of it\n')
pretty(DIFF_T)
sprintf('lambda-RMO for zero reflection theta angle \n')
pretty(LRMO_0)
sprintf('linearized lambda-RMO (rho=1) for zero reflection theta angle')
pretty(LRMO_0_lin)
sprintf('lambda-RMO for general reflection theta angle \n')
pretty(LRMO_T)
sprintf('linearized lambda-RMO (rho=1) for general reflection theta angle')
pretty(LRMO_T_lin)







