clear all, clc, close all
syms T T0 c2 c4 x a0 a2 a4


%standard taylor  
T = T0+c2*x^2+c4*x^4
T_frac = T0+c2*x^2+(c4/(1-2*c4/c2*x^2))*x^4

%ortho param
syms k20 k40 k60 k42 k22
%k42 = (k60-k20*k40)/(k40-k20^2);
%k22 = k60/k40

% matrice di trasformazione per i parametri ortogonali
C3param = [T0 c2 c4].';
C2param = [c2 c4].';
R3param = [1 k20 k40; 0 1 k42; 0 0 1];
 R2param = [1 k22;0 1];

A3_param = R3param*C3param;
A2_param = R2param*C2param;

C3_A = inv(R3param)*[a0 a2 a4].'
C2_A =inv(R2param)*[a2 a4].'

%% 3 param formulation
% 
T_ortho_3param = subs(T,T0,C3_A(1))
T_ortho_3param = subs(T_ortho_3param,c2,C3_A(2))
T_ortho_3param = collect(expand(subs(T_ortho_3param,c4,C3_A(3))),a4)



%% 2 param formulation
T_ortho_2param = subs(T,T0,C3_A(1))
T_ortho_2param = subs(T_ortho_2param,c2,C3_A(2))

%% FRACTIONAL APPROXIMATION

%% 3 param formulation
% 
T_frac_ortho_3param = subs(T_frac,T0,C3_A(1))
T_frac_ortho_3param = subs(T_frac_ortho_3param,c2,C3_A(2))
T_frac_ortho_3param = collect(subs(T_frac_ortho_3param,c4,C3_A(3)))




%% 2 param formulation
T_ortho_2param = subs(T,T0,C3_A(1))
T_ortho_2param = subs(T_ortho_2param,c2,C3_A(2))