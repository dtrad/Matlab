 function E = T_siliqi_Lin(m0,par)
 xm = par.xm;
 M = numel(xm);
 T0 = m0(1);
 tau0 = m0(2);

 m = [0:numel(xm)-1]';
 tn = par.tn;
 
 if par.par == 2
    Asili = m0(3);
 %dtM= (-1+(1+Asili*M^2-2*Asili*M+Asili)^(1/2))*tau0;
 %dtM=    (-1-(1+Asili*M^2-2*Asili*M+Asili)^(1/2))*tau0;
 else
     dtM = m0(3);
 Asili = (dtM^2+2*dtM*tau0)/tau0^2/(M-1)^2;
 end
 %tsili = T0-tau0 + tau0*sqrt(1+((xm).^2/(xm(end))^2)*(dtM^2+2*dtM*tau0)/tau0^2);
 %tsili = T0-tau0 + tau0*sqrt(1+ Asili*m.^2);
 tsili = T0-tau0 + tau0*(1+Asili/2*m.^2-1/8*Asili.^2*m.^4);
% figure
% plot(x,tn,'b.',x,t,'ro')
% pause
 E = tn-tsili;
