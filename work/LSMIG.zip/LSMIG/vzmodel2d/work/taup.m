%% tau-p VTI relation
close all
clc,clear all
syms tau tau0 p vN vH 

%isotropic
tau = tau0*sqrt(1-p^2*vN^2);

r = diff(tau,1,p);
r1 = -p*vN^2*tau0^2/tau;
diff_r = simple(r-r1);
% oriented velocity-free taup NMO
tau0_1 = sqrt(tau^2-tau*r*p);
tau0_ISO = simple(tau0_1)


% % VTI 
% tau = tau0*((1-p^2*vH^2 )/(1-p^2*(vH^2-vN^2)))^(1/2)
% 
% r = diff(tau,1,p)
% %r_par = diff((1-p^2*vH^2 )/(1-p^2*(vH^2-vN^2)),1,p)
% %A = (1-(tau/tau0)^2)*(1/p/(1-p^2*(vH^2-vN^2)))
% 
% %r1 = -tau0^2/tau*(1-(tau/tau0)^2)*(1/p/(1-p^2*(vH^2-vN^2)))
% A = (1-p^2*(vH^2-vN^2))*p;
% r2 = (tau-tau0^2/tau)/A
% 
% q = diff(tau,2,p)
% q1 =( r+r*tau0^2/tau^2-r*diff(A,1,p))/A
% B = (1+tau0^2/tau^2-diff(A,1,p));
% q2 = r/A*B
% simple(q-q2)

%%
A = (1-p^2*vN^2-p^4*vH^2*(vH^2-vN^2));
tau = tau0*A^(1/2);
%A_primo = 2*tau*r/tau0^2;
A_primo = -2*p*vN^2-4*p^3*vH^2*(vH^2-vN^2)
%simple(A_primo-diff(A,1,p))
%A_secondo = 2*(r^2+tau*q)/tau0^2
A_secondo = -2*vN^2-12*p^2*vH^2*(vH^2-vN^2)
%simple(A_secondo-diff(A,2,p))
%%
r = diff(tau,1,p);
%pretty(simple(r))
r1 = tau0^2/tau/2*A_primo;
%simple(r-r1);

q = diff(r,1,p)
pretty(q)

%q1 = -r^2/tau+tau0^2/2/tau*diff(A,2,p)
q1 = tau0^2/2/tau*(diff(A,2,p)-2*r^2/tau0^2)
%q1 = tau0^2/2/tau*(diff(A,2,p)-diff(A,1,p)/tau*r)
B = r/tau;
q2 =  tau0^2/tau*.5*(-diff(A,1,p)*B+diff(A,2,p));
q3 =  tau0^2/tau*.5*(-diff(A,1,p)^2*tau0^2/2/tau^2+diff(A,2,p));
simple(q-q3)
A_primo = 2*tau*r/tau0^2
simple(A_primo-diff(A,1,p))
A_secondo = 2*(r^2+tau*q)/tau0^2
simple(A_secondo-diff(A,2,p))

tau0*(3*p^4*vN^2*vH^4-3*p^4*vN^4*vH^2+2*p^6*vH^8-4*p^6*vH^6...
*vN^2+2*p^6*vH^4*vN^4-vN^2-6*p^2*vH^4+6*p^2*vH^2*vN^2)
%%


% vN2 = sqrt((r*2*tau/tau0^2+4*p^3*vH^4)/(-2*p+4*p^3*vH^2))
% syms r tau
% vN2 = sqrt((r*2*tau/tau0^2+4*p^3*vH^4)/(-2*p+4*p^3*vH^2))
% q = tau0^2/tau*.5*(-diff(A,1,p)*B+diff(A,2,p));

%%
 clc,close all, clear all
d = +0.1;
e = -0.12;
vp0 = 1.5;
vN = vp0*sqrt(1+2*d);
vH = vp0*sqrt(1+2*e);
eta = (e-d)/(1+2*d)
tau0 = 1;
p = sind(linspace(0,90,45))/vH;


taup_iso = tau0*sqrt(1-p.^2*vH^2) ;
taup_alkha = tau0*sqrt((1-p.^2*vH^2)./(1-p.^2*(vH^2-vN^2) ));
taup_alkha1 = tau0*sqrt((1-p.^2*vH^2).*(1+p.^2*(vH^2-vN^2) ));
taup_alkha2 = tau0*sqrt((1-p.^2*vH^2)).*(1+p.^2*(vH^2-vN^2)/2 );
figure,
plot(p,taup_iso,'kv-',p,taup_alkha,'rs-',p,taup_alkha1,'b^-',p,taup_alkha2,'g>-');
set(gca,'ydir','reverse')














