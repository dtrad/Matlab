clear al,

close all
M=51;
dh = 100;
xm = (0:M-1)'*dh;
V = [ones(M,1)  xm.^2 xm.^4];
g0 = ones(M,1);


k20 = 1/M*sum(xm.^2);
k40 = 1/M*sum(xm.^4);
k60 = 1/M*sum(xm.^6);
k80 = 1/M*sum(xm.^8);

k42 = ((k60-k20*k40))/(k40-k20^2);

g2 = xm.^2 - k20*g0;
g4 = xm.^4 - k42*g2-k40*g0;

figure,
subplot(311)
plot(xm/xm(end),g0,'r.');hold on
subplot(312)
plot(xm/xm(end),g2/norm(g2),'r.');hold on
subplot(313)
plot(xm/xm(end),g4/norm(g4),'r.');hold on

% Shifted Legendre polinomials [a b] q(x)=p[ (2x-a-b)/(b-a) ]  
a = -1;
b = 1;
xm_s = xm/xm(end);%(2*xm-a-b)/(b-a);


 q0 = g0;
 

subplot(311)
plot(xm/xm(end),q0,'bo');
xlabel('x/xmax')
legend('u_0(x_m)','P_0(x_m)')
q2 = 1/2*(3*xm_s.^2-1);
subplot(312)
plot(xm/xm(end),q2/norm(q2),'bo');
xlabel('x/xmax')
q4 = 1/8*(35*xm_s.^4-30*xm_s.^2+3) 
legend('u_2(x_m)','P_2(x_m)')
subplot(313)
plot(xm/xm(end),q4/norm(q4),'bo');
xlabel('x/xmax')
legend('u_4(x_m)','P_4(x_m)')
Q= [g0(:) g2(:) g4(:)];

figure
subplot(311)
plot(xm/xm(end),q0-g0,'bo');

q2 = 1/2*(3*xm_s.^2-1);
subplot(312)
plot(xm/xm(end),q2/norm(q2)-g2/norm(g2),'bo');

q4 = 1/8*(35*xm_s.^4-30*xm_s.^2+3) 
subplot(313)
plot(xm/xm(end),q4/norm(q4)-g4/norm(g4),'bo');


Q = [g0(:) g2(:) g4(:)];

R = Q'*V

Rana = M*[1 k20 k40 ;...
          0 k40-k20^2 k60-k20*k40; ...
          0   0       k80-k42*(k60-k20*k40)-k40^2]

a = Rana*[c0 c2 c4];



