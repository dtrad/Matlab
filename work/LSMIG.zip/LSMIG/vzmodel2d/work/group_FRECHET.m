%% studio derivatives...
close all
clear all
clc

%addpath('C:\Program Files\MATLAB\R2007b\work\ferla\')
addpath('/geodata10/casasanta/MATLAB/work/ferla/')

e = 0.2
d = 0.1
vp0 = 1.5;
z0 = 1240;
eta = (e-d)/(1+2*d);



phi = linspace(0,90,90);
teta = phi;
h = 2*tand(phi)*z0;
sin2 = sind(phi).*sind(phi);
cos2 = cosd(phi).*cosd(phi);
sin22 = sind(2*phi).^2;

vn = vp0*sqrt(1+2*d);
vh = vp0*sqrt(1+2*e);
vn*sqrt(1+2*eta);

[V_EX_,phi_ex]=group_from_phase(teta/180*pi,vp0,0,e,d,sind(teta),sin2,cosd(teta),cos2);
V_EX = INTERP1(phi_ex/pi*180,V_EX_,phi);
h1 = figure
    %plot(phi_ex*180/pi,V_EX_,'b.');hold on
    plot(phi,1./V_EX,'ro'),hold on
    

sn2 = (1/vn)^2;
sh2 = (1/vh)^2;    
%S = sqrt( (vp0^-2)*cos2 + (sn2).*sin2.*cos2+ (sh2).*(sin2.*sin2))


S_ELL = sh2*sin2+(vp0^-2)*cos2;
S = sqrt(( S_ELL + ((vn^-2)-(vh^-2))*(sin2.*cos2)));
k =0.001;
%% FRECHET w.r.t. slowness square

S_sn2 = 1/2./(S).*sin2.*(1-sin2)
S_sh2 = 1/2./(S).*(sin2.*sin2)

figure(h1)
plot(phi,S,'b.')

% numerica...
sn2_up = sn2*(1+k);sh2_up = sh2*(1+k);
S_sn2_up = sqrt( (vp0^-2)*cos2 + (sn2_up).*sin2.*cos2+ (sh2).*(sin2.*sin2));
S_sn2_N = (S_sn2_up-S)/k/sn2;
S_sh2_up = sqrt( (vp0^-2)*cos2 + (sn2).*sin2.*cos2+ (sh2_up).*(sin2.*sin2));
S_sh2_N = (S_sh2_up-S)/k/sh2;
figure('name','S_sn2 e S_sh2')
plot(phi,S_sn2,'ro',phi,S_sh2,'bo'),hold on
a=legend('$dS/ds^2_N$','$dS/ds^2_H$','location','best'),set(a,'interpreter','LAtex','Fontsize',16)
%set(gca,'yScale','log')

plot(phi,S_sn2_N,'r.',phi,S_sh2_N,'b.')
%% FRECHET w.r.t vn r vh
S_vn=-2*vn^(-3)*S_sn2;
S_vh=-2*vh^(-3)*S_sh2;

% numerica...
vn_up = vn*(1+k);vh_up = vh*(1+k);
S_vn_up = sqrt( (vp0^-2)*cos2 + (vn_up.^(-2)).*sin2.*cos2+ (sh2).*(sin2.*sin2));
S_vn_N = (S_vn_up-S)/k/vn;
S_vh_up = sqrt( (vp0^-2)*cos2 + (sn2).*sin2.*cos2+ (vh_up.^(-2)).*(sin2.*sin2));
S_vh_N = (S_vh_up-S)/k/vh;
figure('name','S_vn e S_vh'),hold on
plot(phi,S_vn,'ro',phi,S_vh,'bo'),hold on
a=legend('$dS/dv_N$','$dS/dv_H$','location','best'),set(a,'interpreter','LAtex','Fontsize',16)
%set(gca,'yScale','log')
plot(phi,S_vn_N,'r.',phi,S_vh_N,'b.')
%% FRECHET w.r.t. vn e eta

%S_vn = 1/2./(S).*sin2.*cos2 * (-2*vn^(-3)); 
%S_eta = 1/2./(S).*(-1*sin2.*cos2+sin2) * (-2*vh^(-4)*vn^(2)); 

S_vn = -1./S./vn^3.*(sin2.*cos2+sin2.*sin2/(1+2*eta));
S_eta = -2/vn^2/(1+2*eta)^2*S_sh2;




% numerica...
vn_up = vn*(1+k)
sn2_up = (1/vn_up)^2
sh2_up_vn = (vn_up*sqrt(1+2*eta))^(-2);

if eta==0
    eta_up=0.001;
    deta=eta_up;
else
   eta_up = eta*(1+k)
   deta=eta_up-eta;
end
    

sh2_up = (vn*sqrt(1+2*eta_up))^(-2);

S_vn_up  =  sqrt( (vp0^-2)*cos2 + (sn2_up).*sin2.*cos2+ (sh2_up_vn).*(sin2.*sin2));
S_vn_N   = (S_vn_up-S)/k/vn;
S_eta_up =  sqrt( (vp0^-2)*cos2 + (sn2).*sin2.*cos2+ (sh2_up).*(sin2.*sin2));
S_eta_N  = (S_eta_up-S)/deta;
figure('name','S_vn e S_eta')
plot(phi,S_vn,'ro',phi,S_eta,'bo')
a=legend('$dS/dv_N$','$dS/d\eta$'),set(a,'interpreter','LAtex','Fontsize',16)
hold on
%set(gca,'yScale','log')
plot(phi,S_vn_N,'r.',phi,S_eta_N,'b.')







