%% per inversione diretta nel dominio tau-p VTI
% % write VTI taup  moveout (func_tau is the expression, tau is the
% % variable )
clear all,clc,close all
syms tau0 vH2 vz A AA BB p DT0 q p
func_q = 1/vz*sqrt((1-p.^2*vH2)/(1-p.^2*A)); % dispersion relation
pretty(func_q);
dqdp = diff(func_q,1,p);
pretty(simple(dqdp));


func_q_1 = 1/vz*sqrt(AA^2/BB^2)
%% relation between stepout and traveltime for a ray segment
% dt = p dx + q dz = p*dz+ q * vp0 *dt0;
DXfun = simple(-vz* DT0*dqdp);
DXfun = subs(DXfun,-1+vH2*p^2,-AA^2);
DXfun = subs(DXfun,-1+A*p^2,-BB^2);
DXfun = subs(DXfun,vH2,-(AA^2-1)/p^2);
DXfun = factor((expand(subs(DXfun,A,-(BB^2-1)/p^2))));

pretty(DXfun)
%%
DTfun = simple(vz*DT0*(q-p*dqdp));
DTfun = simple(subs(DTfun,q,func_q_1));
DTfun = simple(subs(DTfun,1-vH2*p^2,AA^2));
DTfun = simple(subs(DTfun,1-A*p^2,BB^2));
DTfun = simple(subs(DTfun,vH2,-(AA^2-1)/p^2));
DTfun = factor(expand(subs(DTfun,A,-(BB^2-1)/p^2)));

pretty(DTfun)
%% 
syms DX DT DTAU
DXfun_iso = subs(factor((expand(subs(DXfun,A,-(BB^2-1)/p^2)))),BB,1);
DTfun_iso = subs(factor(expand(subs(DTfun,A,-(BB^2-1)/p^2))),BB,1);

S_iso = solve(DX/DT-simple(DXfun_iso/DTfun_iso),AA)

v2 = simple(1/p^2*(1-S_iso(1).^2))
%% solve for the value of vH2 and A considering tau as a variable
% take positive root S(1)
syms DX DT DTAU
S1 = solve(DXfun-DX,DTfun-DT,BB,AA);

Vh2 = factor((subs(simple(-(S1.AA(1)^2-1)/p^2),DT,DTAU+p*DX)))
A = factor((subs(simple(-(S1.BB(1)^2-1)/p^2),DT,DTAU+p*DX)));
Vn2 = factor(expand(Vh2-A))




