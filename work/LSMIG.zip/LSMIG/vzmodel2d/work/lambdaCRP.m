clear all, close all
syms G L A T z z0 z1
% A = alpha
% T = theta
% G = gamma
% L = lambda

h_z1 = sin(G)*cos(G)/(cos(A)^2-sin(G)^2)
h_z = sin(T)*cos(T)/(cos(L)^2-sin(T)^2)

% z1 = f(z)
z1 = h_z/h_z1*z
pretty(z1)
% sin(G) = f(A,L,T)

fG=((sin(T)/cos(L)*cos(A)))

 %SUBS(S,OLD,NEW)

%pretty(z1_subs)

%z0 = f

h_z0_1 = - (sin(L)*cos(L))/(cos(L)^2-sin(T)^2)
%h_z0_2 = simple(subs((1-sin(G)^2)/(cos(A)^2-sin(G)^2),sin(G),fG))
h_z0_2 = (cos(G)^2)/(cos(A)^2-sin(G)^2)

z0 = simple(tan(A) * h_z0_1*z+h_z0_2*z1)
z0_subs =simple( subs(z0,(G),fG))

N = -simple(sin(A)*sin(L)*sin(T)*cos(A)-sin(T)*cos(T)*cos(A)*cos(G))*z*cos(L)
D = cos(A)^2*(-sin(L)^2+cos(T)^2)*sin(T)

simple(z0_subs-N/D)

cosG = cos(asin(fG))



LCRP = simple(subs(solve(N/D-1,z),cos(G),cosG))

pretty(simple(subs(LCRP,T,0)))

pretty(simple(subs(LCRP,A,L)))


