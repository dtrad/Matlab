%% per il processing tau-p VTI
% % write VTI taup  moveout (func_tau is the expression, tau is the
% % variable )
clear all,clc,close all
syms r q tau0 TAU vH2 A p P
func_tau = tau0*sqrt((1-p.^2*vH2)/(1-p.^2*A));
pretty(func_tau)
r_ex = diff(func_tau,1,p);
q_ex = diff(func_tau,2,p);

pretty(simple(r_ex))

pretty(simple(q_ex))


r_approx1 = -tau0^2*( vH2-A)*p/TAU/(1-p.^2*A)^2;
pretty(r_approx1)

P = -(3*p.^4*vH2*A-2*p.^2*A-1);
%P=-(3*p.^4*vH2*A-1);
%P=-(-2*p.^2*A-1);
%P =1;

q_approx1 = -tau0.^4*(vH2-A)*P./TAU.^3./(1-p.^2*A).^4;
pretty(q_approx1)

f1 = r-r_approx1;
f2 = q-q_approx1;

%% solve for the value of vH2 and A considering tau as a variable
% take positive root S(1)
S = solve(f1,f2,vH2,A);
clc
A_stim = S.A(2);
vH2_stim = S.vH2(2);

pretty(simple(A_stim))
pretty(simple(vH2_stim))
%% substiture it in the func_tau formula
tau_new =   simple(subs(  simple(subs(func_tau.^2,vH2,S.vH2(1))),A,S.A(1)));
clc
pretty(simple(sqrt(tau_new)))
%% find the value of tau respect to the other variables
% solve tau = f(p,r,tau0,tau) for tau 
tau0_map = simple(solve(TAU-sqrt(tau_new),tau0))


%% substitue tau0 above found in the original expression for taup function 
% and the find the mapping relation for vH
func_vH2_new = subs(vH2_stim,tau0,tau0_map(1))
func_A_new = subs(A_stim,tau0,tau0_map(1))
clc
pretty(tau0_map(1))
pretty(simple(func_vH2_new))
pretty(simple(func_A_new))
%pretty(simple(-func_A_new+func_vH2_new))
