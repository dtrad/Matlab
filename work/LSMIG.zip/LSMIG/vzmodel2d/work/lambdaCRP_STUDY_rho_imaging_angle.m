%%%
clc
close all
clear all

Teta = linspace(-90,90,181)/180*pi;
Teta_im = linspace(-20,50,181)/180*pi;

dT_im = diff(Teta_im(1:2));
dT = diff(Teta(1:2));
indTETA = round ((([-20:1.00:20]/180*pi)-Teta(1))/dT)+1;
RHOvec=[0.995 1 1.005];
%%
h1 = figure('name','RMO function of the imaging angle')
for irho = 1:numel(RHOvec)
RHO = RHOvec(irho);
rho = 1/RHO;
    A = 15/180*pi;



z_LCRP = zeros(numel(Teta),numel(Teta_im));
NUM= z_LCRP;
DEN=z_LCRP;
RAD=z_LCRP;
for i=1:numel(Teta_im)
    for j=1:numel(Teta)

T = Teta(j);
L = Teta_im(i)-T;
NUM(j,i)=cos(A)*(sin(L)^2-cos(T)^2)*RHO;
RAD(j,i) = (1-sin(T)^2/cos(L)^2*cos(A)^2*RHO^2);

NUM_DIFF(j,i) = -1*(sin(L)^2-cos(T)^2)*RHO;
RAD_DIFF(j,i) = (1-sin(T)^2*RHO^2);

if RAD(j,i)<1e-12
    RAD(j,i)=NaN;
    
end
if RAD_DIFF(j,i)<1e-12
    RAD_DIFF(j,i)=NaN;
    
end

DEN(j,i) = cos(L)*(sin(A)*sin(L)*RHO-cos(T)*sqrt(RAD(j,i)));
DEN_DIFF(j,i)=-sin(L)^2*RHO+cos(T)*sqrt(RAD_DIFF(j,i));
z_LCRP(j,i)= NUM(j,i)/DEN(j,i);
%z_LCRP(j,i) = (NUM(j,i)*DEN(j,i))/(DEN(j,i)+eps).^2;
z_DIFF(j,i) = NUM_DIFF(j,i)/DEN_DIFF(j,i);

    end
end






for i = 1:numel(indTETA)
figure(h1)
    subplot(1, numel(RHOvec), irho),hold on
plot(Teta_im/pi*180,z_LCRP(indTETA(i),:),'k','linewidth',2.0),
end
xlabel('imaging angle \theta_{\psi}')
set(gca,'ydir','reverse')
 ax = axis;
figure(h1)
subplot(1, numel(RHOvec), irho)
plot([A A]*180/pi,[0.5 1.5],'r','linewidth',2.0)
set(gca,'ydir','reverse','ylim',[0.5 1.5])
end

%%
figure('name','RMO extended in the scattering - imaging angle domain')
imagesc(Teta_im/pi*180,Teta/pi*180,z_LCRP);
caxis([-2,2])
xlabel('imaging angle \theta_{\psi}')
ylabel('scattering angle \theta{_\psi}')
