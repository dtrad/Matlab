%% PP and PS-wave raytracing in V(z) = V0 + az * z or V(x) = V0+ ax * x models

clc, close all, clear all
%warning off;
addpath('C:\Users\lcasasan\Documents\MATLAB\src\OPTIMIZED')

%% layers definition
% parameters = [ Vpo_1 Vso_1 epsilon_1 delta_1 incl_asse_1 rho1; ...
%                Vpo_n Vso_n epsilon_n delta_n incl_asse_n rho_n];

z0 = [0];
dip = 15;kdip=tand(dip);

%--------- Isotropic single layer (Rosales)
%vP0(1) = 1700;   azP=0.15;
%vS0(1) =  300;   azS=0.35;

%--------- Isotropic single layer
vP0(1) = 1500; azP = 0.0;  
vS0(1) =  385; azS = 0.0; 
epsi(1)=  .0;
del(1)=   .0;
ti(1) = 0;
rho(1)=1000;


parameters = [vP0(:),vS0(:),epsi(:),del(:),ti(:),rho(:)];
reflectors = [z0(:),kdip, zeros(numel(z0(:)),4), 1 ];

%% aquisition geometry
m = 2500;
h_min = -500; h_max = 500; dh = 12.5; %half offset
h = [h_min:dh:h_max]';
%h = [h_min:dh:h_max]'/2000;
h2 = 2 * h;
xs = m - h;
xr = m + h;
zs = 0.0;
zr = 0.0;
geometry = [xs,zeros(size(xs)),zs*ones(size(xs)),xr,zeros(size(xr)),zr*ones(size(xr))];

%% straight rays computation (reference)
[tpp,xpp,zpp]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PP');
[tps,xps,zps]=calcolo_tempi2D(parameters,reflectors,1,geometry,1,'PS');

%% V(z) ray tracing
xpp_RP= zeros(size(h)); tpp_vz = zeros(size(h));
xps_CP= zeros(size(h)); tps_vz = zeros(size(h));
polpp_vz= zeros(size(h));
polps_vz= zeros(size(h));
tol = 1e-6;


%for ih=41
for ih=1:numel(h)
   
 
    if kdip==0
        kdip=kdip+1e-6;
    end
    
    x0 =-z0/kdip;
    shtx=xs(ih);
    recx=xr(ih);
    a=(shtx+recx)/2.0;
    if (kdip==)
        b=my.;
    [a,b,c,fa,fb,fc] = mnbrak(@(x) vzmodel2d_tway_time(x,shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip,'PP'),a,b);    
    % reflection point (RP)
    [xpp_RP(ih)] = ...
        NewtonSafe(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip), ...
        (a+c)/2,a,c,tol);
    
    % traveltimes
    [tpp_vz(ih),polpp_vz(ih)] = vzmodel2d_tway_time(xpp_RP(ih),shtx,recx,vP0(1),azP,vP0(1),azP,z0,kdip,'PP');
    
    
    [a,b,c,fa,fb,fc] = mnbrak(@(x) vzmodel2d_tway_time(x,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip,'PS'),a,b);  
    % conversion point (CP)
    [xps_CP(ih)] = ...
        NewtonSafe(@(x) vzmodel2d_tway_timedx(x,shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip), ...
        (a+c)/2,a,c,tol);
    % traveltimes
    [tps_vz(ih),polps_vz(ih)] = vzmodel2d_tway_time(xps_CP(ih),shtx,recx,vP0(1),azP,vS0(1),azS,z0,kdip,'PS');
    
    
    
end

%% plot
figure('name','traveltime comparison')
set(gca,'ydir','reverse')
subplot(121)
plot(h,tpp,'b-.','linewidth',2.0); hold on
set(gca,'Ylim',[min([tps;tpp])*.8,max([tps;tpp])*1.1],'ydir','reverse')
%plot(h,tpp1_vz,'r-x','linewidth',2.0); hold on
plot(h,tpp_vz,'g-o','linewidth',2.0); hold on
title('PP')
%plot
subplot(122)
plot(h,tps,'b-.','linewidth',2.0); hold on
set(gca,'Ylim',[min([tps;tpp])*.8,max([tps;tpp])*1.1],'ydir','reverse')

%plot(h,tps1_vz,'r-x','linewidth',2.0); hold on
plot(h,tps_vz,'g-s','linewidth',2.0); hold on
title('PS')

% plot
figure('name','polarity change vs offset')
subplot(121)
plot(h,polpp_vz,'k','linewidth',2.0); hold on
plot(h,ones(size(h)),'k'); 
set(gca,'Ylim',[0;2],'Xgrid','on')

title('PP')
subplot(122)
plot(h,polps_vz,'k','linewidth',2.0); hold on
plot(h,zeros(size(h)),'k'); 
set(gca,'Ylim',[-1;1],'Xgrid','on')

title('PS')







