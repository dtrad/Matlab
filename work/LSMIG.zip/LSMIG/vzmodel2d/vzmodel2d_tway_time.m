
function [t,polarity] = vzmodel2d_tway_time(x,shtx,recx,v0_dw,az_dw,v0_up,az_up,z0,kdip,wavemode)

    if(kdip==0)
        kdip=1e-6;
    end
    z = z0 + kdip * x; 
    %traveltime
    tsht=vzmodel2d_calctime(x-shtx,z,v0_dw,az_dw);
    trec=vzmodel2d_calctime(x-recx,z,v0_up,az_up);
    t = tsht+trec;
    
    %polarity angle at the reflector
    v_dw = v0_dw + az_dw * z;
    v_up = v0_up + az_up * z;
    
    sinsht = vzmodel2d_calctimedx(x-shtx,z,v0_dw,az_dw,kdip)*v_dw;
    sinrec = vzmodel2d_calctimedx(x-recx,z,v0_up,az_up,kdip)*v_up;
    
    cossht = sqrt(1-sinsht.^2);
    cosrec = sqrt(1-sinrec.^2);
    if strcmp(wavemode,'PP')
        polarity = cossht*cosrec;
    elseif strcmp(wavemode,'PS')
        polarity = sinsht*cosrec;
    else
        disp('wavemode wrong! pls select PP or PS')        
    end
end
function [t] = vzmodel2d_calctime(x,z,v0,av)

    sml=1.e-6;
    lrg=1.e+6;

    v=v0+av*z;
    b=(x.*x+z.*z)./(2*v0*v);
    avb=av*b;

    %    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml) 
        if(abs(av)>sml) 
            t = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb.*avb));
        else
            t = avb + sqrt(2*b+avb.*avb);
        end
    else
       t=lrg;
    end

    return 
end


function [dtdx] = vzmodel2d_calctimedx(x,z,v0,av,kdip)

sml=1.e-6;
lrg=1.e+6;

r = sqrt(x.^2+z.^2);
v=v0+av*z;

%    check if velocity become negative, if it's the case traveltime becomes meaningless
    if (v>sml)
        if(abs(av)>sml)
            %t = 1./av * arcosh(1+ (av.^2 * r.^2) ./ (2 .* v0 .* v));  
            W = sqrt(4.*v0.*v.*r.^2 + av^2*r.^4);          
            dtdx = 1./W.*(2.*x + kdip.*(2.*z - av./v.*r.^2)); 
        else
            
            %t = sqrt(r.^2/v0^2);
            W = sqrt(4.*v0.*v0.*r.^2); 
            dtdx =  1./W.*(2.*x + kdip.*(2.*z)); 
        end
    else
        dtdx = lrg;
        %disp(['v=',num2str(v),'z=',num2str(z)])
    end

    return
end