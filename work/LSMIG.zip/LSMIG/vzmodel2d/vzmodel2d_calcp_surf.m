function [rayp] = vzmodel2d_calcp_surf(x,z,v0,av)

    r=sqrt( x.^2+z^2);
    v=v0+av*z;

    sml=1.e-6;
    if(abs(av)>sml) 
        if(x+1.0==1.0) % vertical incidence 
            rayp=0.0;
        else            
            W = av*av*r^4 + 4*v0*v*r^2;            
            rayp = 2*x / sqrt( W );
            
        end
    else
        rayp=1/v0 * (x/r);
    end

    return
end