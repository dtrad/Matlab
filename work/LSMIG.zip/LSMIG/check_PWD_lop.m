%check PWD_lop
clc; close all; clear all;
addpath('C:\Users\lcasasan\Documents\MATLAB\LocalDipFiltering\Predict_PWD\')

nz=21;
nx=11;




test_in = speye(nz*nx);
outop=zeros(nz*nx);
outop_adj=outop;

dip = tand(0) * ones(nz,nx);

predict_PWD_init(nz,nx,0.01,1,dip);precond = @predict_PWD_lop

%% ---- compute impulse response
for i=1:size(test_in,1)
    
    outop(:,i)=feval(precond,0,nx*nz,nx*nz,test_in(:,i));
    outop_adj(:,i)=feval(precond,1,nx*nz,nx*nz,test_in(:,i));
end
figure,subplot(221),spy(outop)
subplot(222),spy(outop'-outop_adj)

subplot(223),imagesc(outop),axis image
subplot(224),imagesc(outop'-outop_adj),caxis([-1 1]*1e-12),axis image

max(max(outop'-outop_adj))
max(min(outop'-outop_adj))
min(min(outop'-outop_adj))


%% ---- adjoint test
d = randn(nz*nx,1);
m = randn(nz*nx,1);

Lm  = feval(precond, 0 , nz*nx, nz*nx, m);
LTd = feval(precond, 1 , nz*nx, nz*nx, d);

dTLm =  d' * Lm;
LTdm = LTd' * m;
fprintf('Adjoint test lsmig_born_lop d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm);