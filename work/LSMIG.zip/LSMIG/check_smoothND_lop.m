%check gaussND_lop
clc; close all; clear all;
addpath('C:\Users\lcasasan\Documents\MATLAB\lop')

nz=41;
nx=21;

dim = 2;
rect = [1,5,1,1];
diff = [0,0,0,0];
box = [0,0,0,0];
n = [nz,nx,5,2];
nrep = 1;

smooth_init(dim,rect,diff,box,n,nrep); precon=@smooth_lop;

%% ---- adjoint test
d = randn(nz*nx,1);
m = randn(nz*nx,1);

Lm  = feval(precon, 0 , nz*nx, nz*nx, m);
LTd = feval(precon, 1 , nz*nx, nz*nx, d);

dTLm =  d' * Lm;
LTdm = LTd' * m;
fprintf('Adjoint test lsmig_born_lop d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm);


%% ---- compute impulse response
in = zeros(nz,nx);
in((nz+1)/2,(nx+1)/2)=1;
%in(1,(nx+1)/2)=1;
%in((nz+1)/2,1)=1;
outop=zeros(nz*nx,1);
outop_adj=outop;
for i=1:1%size(test_in,1)
    
    outop(:,i)    =feval(precon,0,nx*nz,nx*nz,in(:));
    outop_adj(:,i)=feval(precon,1,nx*nz,nx*nz,in(:));
end
figure
subplot(121),imagesc(reshape(outop,nz,nx)),axis image
colormap(1-gray),
subplot(122),imagesc(reshape(outop_adj,nz,nx)),axis image
colormap(1-gray),


%% 
%outop=zeros(nz*nx);
%outop_adj=outop;
% for i=1:size(test_in,1)
%     
%     outop(:,i)    =feval(precon,0,nx*nz,nx*nz,test_in(:,i));
%     outop_adj(:,i)=feval(precon,1,nx*nz,nx*nz,test_in(:,i));
% end
% figure,subplot(221),spy(outop)
% subplot(222),spy(outop_adj)
% 
% subplot(223),imagesc(outop),axis image
% subplot(224),imagesc(outop_adj),axis image

