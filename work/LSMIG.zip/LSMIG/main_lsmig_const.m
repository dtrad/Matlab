%%%%%%% LSMIG: born + ray Green's functions in constant v and rho  %%%%%%%%
addpath \Users\dtrad\Documents\MATLAB\LSMIG\vzmodel2d
%run('C:\Users\dtrad\Documents\MATLAB\SeismicLab\setpath.m')
addpath('C:\Users\dtrad\Documents\MATLAB\LSMIG\lop')
clc; close all; clear all;

%% ---- synthetic 2D subsurface model 
my = vzmodel2d_init();
my.z0s    =  [1000;2000;3000;4000]';
my.angles = zeros(size(my.z0s));
%my.angles = [   2.5;   5;   7.5;   10]; 

my.ndep = numel(my.z0s);
my.v0P = 2000;
my.tmax  = 5000; %record lenght (ms)
my.srate = 4;
my.nt = floor(my.tmax/my.srate) + 1;

my.IsBbwlt = 0; %apply broadband
my.IsSprd  = 1; %apply polarity
my.IsPlrty = 0; %apply polarity
if my.IsBbwlt %orsmby
   my.f1=2;
   my.f2=4;
   my.f3=20;
   my.f4=30;
else %ricker
   my.fpeak = 8;
end

%% ---- csg acquisition
my.dx = 25; %midpoint spacing
my.aperx = 2000;
my.maxoffset = 2000;
my.frecx = my.aperx + 500;
my.lrecx = my.frecx + my.maxoffset * 2;
my.fshotx = (my.frecx + my.lrecx)/2 ; % first shot location
my.ns=1;
my.ds=2000;  % number of common shot gathers/csg sampling

my.fcross = round((my.frecx + my.fshotx) / (2.0 * my.dx)) + 1; 
my.lcross = round((my.lrecx + my.fshotx) / (2.0 * my.dx)) + 1; 
my.nin = my.lcross - my.fcross + 1;

csg   = zeros(my.nt,my.nin*my.ns);
shtxs = zeros(my.nin*my.ns,1);
recxs = zeros(my.nin*my.ns,1);
XLs   = zeros(my.nin*my.ns,1);
cdpxs = zeros(my.nin*my.ns,1);
axist = (0:my.nt-1)*my.srate/1e3;

for is=0:my.ns-1
   
    is_loc = ( is*my.nin : (is+1)*my.nin-1 ) + 1; 
    %--- model data
    csg( : , is_loc )  = vzmodel2d(my);
    
    shtxs(is_loc) = my.fshotx*ones(my.nin,1);
    recxs(is_loc) = (my.frecx : my.dx*2:my.lrecx);
    XLs(is_loc) = (my.fcross: 1 : my.lcross);
    cdpxs(is_loc) = XLs(is_loc)*my.dx;
    %--- update shot poistion
    my.fshotx = my.fshotx + my.ds;
    my.frecx  = my.frecx  + my.ds;
    my.lrecx  = my.lrecx  + my.ds;
    my.fcross = round((my.frecx + my.fshotx) / (2.0 * my.dx)) + 1; 
    my.lcross = round((my.lrecx + my.fshotx) / (2.0 * my.dx)) + 1; 
    
end
minXLs = min(XLs);
maxXLs = max(XLs);

fig1=figure('name','1) input CSGs');
imagesc(recxs,axist,csg);colormap('gray');
title('input csg');
xlabel('recx [m])'); ylabel('time [s]')
rms_csg = rms(csg);
caxis([-rms_csg +rms_csg]); colorbar
%% ---- setup migration 
my.dz = 12.5; %depth interval for a 8Hz ricker wavelet
%my.dz = 10; %depth interval for a 20Hz ricker wavelet
my.maxdepth = 5000;
my.fXL = minXLs - round(my.aperx/my.dx) + 1;
my.lXL = maxXLs + round(my.aperx/my.dx) + 1;
my.nx = my.lXL - my.fXL + 1;
my.nz = floor(my.maxdepth/my.dz) + 1;
axisz = (0:my.dz:my.maxdepth);

disp(['data  minXL = ',num2str(minXLs),'  maxXL = ',num2str(maxXLs)])
disp(['image minXL = ',num2str(my.fXL),'  maxXL = ',num2str(my.lXL )])

%---- synthetic reflectivity trace (desired migration)
mig_des = zeros(my.nz,1);
if my.IsBbwlt
    
else
   [w,tw] = ricker(my.fpeak,my.dz/1e3);
   nw=numel(w);
   icai_init(nw,w(:),1);
   
   for idep=1:my.ndep
       z0=my.z0s(idep);
       mig_des = mig_des + ...
           icai_lop(0,my.nz,my.nz,sinc([0:my.nz-1]' - (z0+tw(1)*1e3)/my.dz));
   end
end



%% ---- init born operator and adjoint test
verb   =  1;        %verbosity flag
aper   = 90;        %max aperture in degrees
apertp =  10;       %aperture taper
aperx  = 1500;      %maximum aperture in mid-point distance
aperxtp = 500;      %aperture taper in mid-point distance
hd = 1;             %half differentiation 0=no 1=half 2=full
sign_hd = -1;       %sign half differentiation exp(+/-jwt)
src_wlt = 0;%       %include source wavelet
bp=[1,2,30,40];     %band pass for a 8hz ricker wavelet
%bp=[.5,5,45,55];   %band pass for a 20hz ricker wavelet
useAmp = 1;         %use analitical amplitudes
precon = 1;         %use preconditioner
localsm = 0;        %use local structural smoother
rectz=2;
rectx=10;
smoother='smooth';
%smoother='gauss2D';
mask=0;             %create a mask operator to simultate irregular acquisition            



if strcmp(smoother,'smooth')
    smoother_lop = @smooth_lop;
    precon_smoother_lop = @myBorn_lop_precondOp_smooth_lop;
elseif strcmp(smoother,'gauss2d')
    smoother_lop = @gauss2D_lop;
    precon_smoother_lop = @myBorn_lop_precondOp_gauss2D_lop;
end
clear global myBorn_lop
lsmig_born_init(my,shtxs,recxs ,...
                    aper,apertp,...
                    aperx,aperxtp,...
                    hd,sign_hd,bp,...
                    src_wlt,useAmp,...
                    precon,...
                    localsm,...
                    rectz,rectx,...
                    smoother,...
                    mask,...
                     verb);
ndata =  (my.nin * my.ns) * my.nt;
nmodel =  my.nx * my.nz;

%%  data decimation
mig_lop=@lsmig_born_lop;
mig_lop_char='lsmig_born_lop';
if mask
    csg_old = csg;
    csg = myBorn_mask_lop(0,ndata,ndata,csg_old);
    csg=reshape(csg,my.nt,my.nin*my.ns);
    
    fig1a=figure('name','1a) input CSGs');
    imagesc(recxs,axist,csg);colormap('gray');
    title('input csg');
    xlabel('recx [m])'); ylabel('time [s]')
    caxis([-rms_csg +rms_csg]); colorbar
    mig_lop=@lsmig_mask_born_lop;
    mig_lop_char='lsmig_mask_born_lop';

end


%% ---- adjoint test
adj_test=1;
if adj_test
    
    if (precon)
        
        d = randn(nmodel,1);
        m = randn(nmodel,1);
        if (localsm && precon)
            disp('localsm && precon...:');
            Lm  = feval(precon_smoother_lop, 0 , nmodel, nmodel, m);
            LTd = feval(precon_smoother_lop, 1 , nmodel, nmodel, d);
        else
            disp('precon...:');
            Lm  = myBorn_lop_precondOp_lop( 0 , nmodel, nmodel, m);
            LTd = myBorn_lop_precondOp_lop( 1 , nmodel, nmodel, d);
        end
        dTLm =  d' * Lm;
        LTdm = LTd' * m;
        fprintf('Adjoint test precond d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm);
        
    elseif (localsm)
        disp('localsm...:');
        Lm  = feval(smoother_lop, 0 , nmodel, nmodel, m);
        LTd = feval(smoother_lop, 1 , nmodel, nmodel, d);
        
        dTLm =  d' * Lm;
        LTdm = LTd' * m;
        fprintf('Adjoint test precond + local smoother d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm)
    end

    disp(['born...:',mig_lop_char]);
    d = randn(ndata,1);
    m = randn(nmodel,1);
    %if (~mask)
    %Lm  = lsmig_born_lop( 0 , ndata, nmodel, m);
    %LTd = lsmig_born_lop( 1 , ndata, nmodel, d);
    Lm  = feval(mig_lop, 0 , ndata, nmodel, m);
    LTd = feval(mig_lop, 1 , ndata, nmodel, d);
    %else
    %Lm  = myBorn_mask_lop(0, ndata, ndata, lsmig_born_lop( 0 , ndata, nmodel, m));
    %LTd = lsmig_born_lop( 1 , ndata, nmodel,   myBorn_mask_lop(1, ndata, ndata, d));
    %end
    
    
    dTLm =  d' * Lm;
    LTdm = LTd' * m;
    fprintf('Adjoint test lsmig_born_lop d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm);
end


%% run migration
adj = 1;

if (precon)
   tic
    mig_precond = feval(mig_lop, adj , ndata, nmodel, csg(:));
    % I have to apply twice the precond to have decon imaging condition
    mig = myBorn_lop_precondOp_lop(adj,nmodel,nmodel,mig_precond);
    mig = myBorn_lop_precondOp_lop(adj,nmodel,nmodel,mig);
    if (localsm)
        mig = feval(smoother_lop,adj,nmodel,nmodel,mig);
    end
    toc
elseif (localsm) 
    tic
    mig_sm = feval(mig_lop, adj , ndata, nmodel, csg(:));
    mig = feval(smoother_lop,adj,nmodel,nmodel,mig_sm);
    toc
else
    tic
    mig = feval(mig_lop, adj , ndata, nmodel, csg(:));
    toc
end


migxz = reshape(mig,my.nz,my.nx);                     
fig2=figure('name','2) migration');
set(fig2, 'Position',  [944   994-350   672   504+350])
subplot(5,1,1);
plot((my.fXL:my.lXL) , migxz(round(1000/my.dz)+1,:),'b','linewidth',2.0); hold on
plot((my.fXL:my.lXL) , migxz(round(2000/my.dz)+1,:),'r','linewidth',2.0); hold on
plot((my.fXL:my.lXL) , migxz(round(3000/my.dz)+1,:),'g','linewidth',2.0); hold on
plot((my.fXL:my.lXL) , migxz(round(4000/my.dz)+1,:),'k','linewidth',2.0); hold on
set(gca,'Xlim',[my.fXL,my.lXL])
subplot(5,1,[2:5])
imagesc( (my.fXL:my.lXL) ,axisz,migxz); hold on
plot([my.fXL,my.lXL] , [1000 1000],'b:','linewidth',1.0); hold on
plot([my.fXL,my.lXL] , [2000 2000],'r:','linewidth',1.0); hold on
plot([my.fXL,my.lXL] , [3000 3000],'g:','linewidth',1.0); hold on
plot([my.fXL,my.lXL] , [4000 4000],'k:','linewidth',1.0); hold on
set(gca,'Xlim',[my.fXL,my.lXL])
title('migrated csg');
xlabel('crossline #'); ylabel('depth [z]')
caxis([-rms(migxz),rms(migxz)]); 
colormap('gray'),colorbar('southoutside')
%% migrated trace amplitude and spectrum
fig3 = figure('name','3) migrated wavelet vs desired');
set(fig3, 'Position',  [944   994-350   672   504+350])
subplot(121)
plot(mig_des,axisz,'r--','linewidth',2.0);hold on
tr_migxz = sum(migxz,2)/size(migxz,2);
tr_migxz = tr_migxz/max(tr_migxz(:));
plot(tr_migxz,axisz,'b:','linewidth',2.0)
set(gca,'ydir','reverse','XLim',[-1.2 1.2],'ygrid','on')
xlabel('amplitude'); ylabel('depth [m]')

%subplot(122)
%h = spectrum.welch;    
%Hpsd_des = psd(h,mig_des,'Fs',1/my.dz*1000);  
%Hpsd_mig = psd(h,tr_migxz,'Fs',1/my.dz*1000);            
%h=plot(Hpsd_des);set(h,'Color','r','lineStyle','--','linewidth',2.0); hold on                           
%h=plot(Hpsd_mig);set(h,'Color','b','lineStyle',':','linewidth',2.0); 


%% run migration-prediction + residuals
adj=0;

if (localsm)
    disp('localsm...:');
    pred = feval(smoother_lop,adj,nmodel,nmodel,mig);
    if (precon)
        disp('&& precon...:');
    pred_precon = myBorn_lop_precondOp_lop(adj,nmodel,nmodel, pred );
    pred_precon = myBorn_lop_precondOp_lop(adj,nmodel,nmodel, pred_precon );
    pred = lsmig_born_lop( adj , ndata, nmodel,pred_precon );
    end
    
elseif (precon)
        disp('precon...:');
    pred_precon = myBorn_lop_precondOp_lop(adj,nmodel,nmodel, mig );
    pred_precon = myBorn_lop_precondOp_lop(adj,nmodel,nmodel, pred_precon );
    pred = lsmig_born_lop( adj , ndata, nmodel,pred_precon );
else
    pred = lsmig_born_lop( adj , ndata, nmodel,mig );
end

predtx = reshape(pred,my.nt,my.nin*my.ns);    
restx = csg-predtx;

%% csg-prediction-residul
fig4=figure('name','4) input-prediction-residul');
subplot(131)
imagesc(recxs,axist,csg);colormap('gray');
title('input csg');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); colorbar
subplot(132)
imagesc( recxs ,axist,predtx);colormap('gray')
title('predicted csg');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); colorbar
subplot(133)
imagesc( recxs ,axist,restx);colormap('gray')
title('resiual');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); colorbar

%% run inversion
epsi=1e-3;
liter=10;
if (precon)
    if (localsm)
        disp('precon && localsm...');
       
        [migLS_sm,res_ls,k,info]=cglsPRECOND(mig_lop,epsi,csg(:),ndata,nmodel,liter,1e-12,1,precon_smoother_lop);
        migLS = feval(precon_smoother_lop,0,nmodel,nmodel,migLS_sm);
    else
        disp('precon ...');
        [migLS_precond,res_ls,k,info]=cglsPRECOND(mig_lop,epsi,csg(:),ndata,nmodel,liter,1e-12,1,'myBorn_lop_precondOp_lop');
        migLS = myBorn_lop_precondOp_lop(0,nmodel,nmodel,migLS_precond);
    end
elseif (localsm)
    disp('localsm ...');
    [migLS_sm,res_ls,k,info]=cglsPRECOND(mig_lop,epsi,csg(:),ndata,nmodel,liter,1e-12,1,smoother_lop);
    migLS = smoother_lop(0,nmodel,nmodel,migLS_sm);
else
    [migLS,res_ls,k,info]=cgls_v1(mig_lop,zeros(nmodel,1),epsi,csg(:),ndata,nmodel,liter,1e-12,1);
    %[migLS,res_ls,k,info]=cgls(mig_lop,epsi,csg(:),ndata,nmodel,liter,1e-12,1);
end
migLS_zx = reshape(migLS,my.nz,my.nx);                     
fig5=figure('name','5 )inverted csg');
set(fig5, 'Position',  [944   994-350   672   504+350])

subplot(5,1,1)
plot((my.fXL:my.lXL) , migLS_zx(round(1000/my.dz)+1,:),'b','linewidth',2.0); hold on
plot((my.fXL:my.lXL) , migLS_zx(round(2000/my.dz)+1,:),'r','linewidth',2.0); 
plot((my.fXL:my.lXL) , migLS_zx(round(3000/my.dz)+1,:),'g','linewidth',2.0);
plot((my.fXL:my.lXL) , migLS_zx(round(4000/my.dz)+1,:),'k','linewidth',2.0); 
set(gca,'Xlim',[my.fXL,my.lXL])

subplot(5,1,[2:5])
imagesc( (my.fXL:my.lXL) ,axisz,migLS_zx);colormap('gray');hold on
plot([my.fXL,my.lXL] , [1000 1000],'b:','linewidth',1.0); 
plot([my.fXL,my.lXL] , [2000 2000],'r:','linewidth',1.0); 
plot([my.fXL,my.lXL] , [3000 3000],'g:','linewidth',1.0); 
plot([my.fXL,my.lXL] , [4000 4000],'k:','linewidth',1.0); 
set(gca,'Xlim',[my.fXL,my.lXL])
title('LS migrated csg');
xlabel('crossline #'); ylabel('depth [z]')
caxis([-rms(migLS_zx),rms(migLS_zx)]);
colorbar('southoutside')


%% LS migrated trace amplitude and spectrum
fig6 = figure('name','6) LS migrated wavelet vs desired')
set(fig6, 'Position',  [944   994-350   672   504+350])
subplot(121)
plot(mig_des,axisz,'r--','linewidth',2.0);hold on
tr_migLS_xz = sum(migLS_zx,2)/size(migLS_zx,2);
tr_migLS_xz = tr_migLS_xz/max(tr_migLS_xz(:));
plot(tr_migLS_xz,axisz,'b:','linewidth',2.0)
set(gca,'ydir','reverse','XLim',[-1.2 1.2],'ygrid','on')
xlabel('amplitude'); ylabel('depth [m]')

subplot(122)
h = spectrum.welch;    
Hpsd_des = psd(h,mig_des,'Fs',1/my.dz*1000);  
Hpsd_ls = psd(h,tr_migLS_xz,'Fs',1/my.dz*1000);            
h=plot(Hpsd_des);set(h,'Color','r','lineStyle','--','linewidth',2.0); hold on                           
h=plot(Hpsd_ls);set(h,'Color','b','lineStyle',':','linewidth',2.0); 

%% run inversion-prediction
adj = 0;
predLS = lsmig_born_lop( adj , ndata, nmodel, migLS );

predLS_tx = reshape(predLS,my.nt,my.nin*my.ns);    
resLS_tx = csg - predLS_tx;


%% csg-predictionLS-residulLS
fig7=figure('name','7) input-prediction-residul (LS)');
subplot(131)
imagesc(recxs,axist,csg);colormap('gray');
title('input csg');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); 
subplot(132)
imagesc( recxs ,axist,predLS_tx);colormap('gray')
title('predicted LS csg');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); 
subplot(133)
imagesc( recxs ,axist,resLS_tx);colormap('gray')
title('resiual LS');
xlabel('recx [m])'); ylabel('time [s]')
caxis([-rms_csg +rms_csg]); 

%% trace amplitude and spectrum
fig8 = figure('name','8) input vs prediction-residul');
set(fig8, 'Position',  [944   994-350   672   504+350])
subplot(121)
plot(csg(:,round((my.nin+1)/2)),axist,'r--','linewidth',2.0); hold on
plot(predLS_tx(:,round((my.nin+1)/2)),axist,'b:','linewidth',2.0)
title(['trace # ',num2str(round((my.nin+1)/2))])
set(gca,'ydir','reverse','Xlim',[-rms_csg +rms_csg]*2.5 )
xlabel('amplitude'); ylabel('time [s]')

subplot(122)
h = spectrum.welch;    
Hpsd_csg = psd(h,csg(:,round((my.nin+1)/2)),'Fs',1000/my.srate);  
Hpsd_pred = psd(h,predLS_tx(:,round((my.nin+1)/2)),'Fs',1000/my.srate);            
h=plot(Hpsd_csg);set(h,'Color','r','lineStyle','--','linewidth',2.0); hold on                           
h=plot(Hpsd_pred);set(h,'Color','b','lineStyle',':','linewidth',2.0);  

%% plot residul

fig9=figure('name','9) residual')
plot([0:k],res_ls,'bs-','linewidth',2.0,...
                        'MarkerEdgeColor','k',...
                        'MarkerFaceColor','b',...
                        'MarkerSize',6); hold on