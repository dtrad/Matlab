function smooth_init(dim,rect,diff,box,n,nrep)

global smooth;

smooth.dim  = dim;
smooth.rect = rect(1:dim); % smoothing radius on #-th axis 
smooth.diff = diff(1:dim); % diff=[n,n,  n] nth-order differentiation on #-th axis 
smooth.box = box(1:dim);   % box=[1 1,...1] (rather than triangle) on #-th axis
smooth.n = n(1:dim);       % size of the problem 
smooth.nrep = nrep;    % repeat filtering n times