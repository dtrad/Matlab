function out=sf_halfint_lop(adj,in)


global hint

if ( numel(in) ~= hint.n )
    fprintf('__ERROR__halfint_lop: data size problem: %d != %d',numel(in), hint.n );
    return
end

in_ftt=fft(in,hint.nfft);
in_ftt=in_ftt(1:hint.nw,:);
MASK=[1;2*ones(hint.nw-2,1);1];
in_ftt=in_ftt.*MASK;

if (adj)
    out_fft = in_ftt.*conj(hint.cf);
else
    out_fft = in_ftt.*(hint.cf);
end
    
out = real(ifft(out_fft,hint.nfft));
out = out(1:hint.n);



