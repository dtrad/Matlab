function lsmig_born_init(my,shtxs,recxs,aper,apertp,aperx,aperxtp,hd,hd_sign,bp,src_wlt,useAmp,precon,localsm,rectz,rectx,smoother,mask,verb)
%% init for seismic modelling linear operator
global myBorn_lop

%----- model space info
myBorn_lop.fXL  = my.fXL ; 
myBorn_lop.lXL  = my.lXL ; 
myBorn_lop.dx = my.dx; 
myBorn_lop.dz = my.dz;
myBorn_lop.nx = my.nx; 
myBorn_lop.nz = my.nz; 
myBorn_lop.vs = my.v0P; 
myBorn_lop.vr = my.v0P;
myBorn_lop.dvs = my.azP; 
myBorn_lop.dvr = my.azP; 

%----- data space size
myBorn_lop.ns = my.ns; 
myBorn_lop.nin = my.nin; 
myBorn_lop.nt = my.nt;
myBorn_lop.srate = my.srate/1e3;
myBorn_lop.tmax = my.tmax;

myBorn_lop.shtxs = shtxs; 
myBorn_lop.recxs = recxs; 
myBorn_lop.aper=aper;
myBorn_lop.apertp=apertp;

myBorn_lop.aperx=aperx;
myBorn_lop.aperxtp=aperxtp;


myBorn_lop.verb=verb;

%---- rised cosine aperture taper;
myBorn_lop.rc_T = 1;
myBorn_lop.rc_beta = 1;
myBorn_lop.rc_step = 0.01;
f = (0:myBorn_lop.rc_step:1)';
myBorn_lop.rc_taper = lsmig_born_lop_rc_taper(f);

%---- band pass
sf_bp_init(bp(1),bp(2),bp(3),bp(4),my.srate/1e3,my.nt);

%---- src_wlt (for now only ricker)
sf_srcwlt_init(src_wlt,my.fpeak);

%---- half differentiation 
myBorn_lop.hd=hd;

if (myBorn_lop.hd)
    inv = 1;
    rho = .95;
    sf_halfint_init(inv,my.nt,rho,hd_sign);
end

%---- traveltime computation
myBorn_lop.TTs=lsmig_born_lop_tt(myBorn_lop.vs,myBorn_lop.dvs);
myBorn_lop.TTr=lsmig_born_lop_tt(myBorn_lop.vr,myBorn_lop.dvr);

myBorn_lop.useAmp = useAmp;
if (myBorn_lop.useAmp)
    %---- slowness computation
    myBorn_lop.rayps=lsmig_born_lop_rayp(myBorn_lop.vs,myBorn_lop.dvs,myBorn_lop.TTs);
    myBorn_lop.taypr=lsmig_born_lop_rayp(myBorn_lop.vr,myBorn_lop.dvr,myBorn_lop.TTr);
    
    %---- amplitude computation
    
    myBorn_lop.As=lsmig_born_lop_A(myBorn_lop.vs,myBorn_lop.dvs,myBorn_lop.rayps);
    myBorn_lop.Ar=lsmig_born_lop_A(myBorn_lop.vr,myBorn_lop.dvr,myBorn_lop.taypr);
    

    x = ((1:myBorn_lop.nx)-1)*myBorn_lop.dx;
    z = ((1:myBorn_lop.nz)-1)*myBorn_lop.dz;
    if (0)
    figure('name','TT,rayP,Amp');
    subplot(131)
    imagesc( x,z, myBorn_lop.TTs);
    title('TT');xlabel('distance [m]');zlabel('depth [m]')
    subplot(132)
    imagesc(x,z, myBorn_lop.rayps);
    title('rayp');xlabel('distance [m]');zlabel('depth [m]')
    subplot(133)
    imagesc(x,z, myBorn_lop.As);
    title('AA');xlabel('distance [m]');zlabel('depth [m]')
    caxis([0,1])
    
    figure
    semilogy(z,myBorn_lop.As(:,1)/myBorn_lop.As(2,1),'r--');
    hold on
    semilogy(z,1./sqrt(z)*sqrt(z(2)),'b:')
    end
    
    if (precon)
        myBorn_lop_precondOp_init(myBorn_lop.As,myBorn_lop.Ar)
            figure('name','precond');
    imagesc((my.fXL:my.lXL),z, 10*log10(reshape(myBorn_lop.precondOp,myBorn_lop.nz,myBorn_lop.nx)));
    end
    

     %caxis([0,1])
    
end

%---- local smoothing as preconditioner
if localsm
    
    in = zeros(my.nz,my.nx);
    in((my.nz+1)/2,(my.nx+1)/2) = 1;
    
    if strcmp(smoother,'gauss2D')

        sigmaz=(rectz*rectz-1.)/12;
        sigmax=(rectx*rectx-1.)/12;
        gauss2D_init(my.nz,my.nx,sigmaz,sigmax)
        out_lop = feval(@gauss2D_lop,0,my.nz*my.nx,my.nz*my.nx,in(:));
    elseif strcmp(smoother,'smooth')

        dim = 2;
        rect = [rectz,rectx];
        diff = [0,0];
        box = [0,0];
        n = [my.nz,my.nx];
        nrep = 2;
        smooth_init(dim,rect,diff,box,n,nrep);
        out_lop = feval(@smooth_lop,0,my.nz*my.nx,my.nz*my.nx,in(:));
    end

    figure('name','local smoother impulse response')
    
    imagesc((my.fXL:my.lXL),z,reshape(out_lop,my.nz,my.nx)/max(out_lop)); colormap(1-gray),
    title([smoother,': rectz = ',num2str(rectz),' rectx = ',num2str(rectx)]);
    xlabel('crossline #'); ylabel('depth [z]')
    caxis([0,1])
       
end

if mask
    %it's a diagonal operator of size my.nt*my.nin*my.ns x my.nt*my.nin*my.ns
    myBorn_lop.mask=zeros(my.nt*my.nin*my.ns,1);
    % mask every jump trace 
    jump=4;
    for i=1:jump:my.nin*my.ns
       myBorn_lop.mask((i-1)*my.nt+1:i*my.nt) = 1;
    end
end


%---- raised cosine taper method
function out=lsmig_born_lop_rc_taper(fvec)

global myBorn_lop

T = myBorn_lop.rc_T;
beta = myBorn_lop.rc_beta;

for i=1:numel(fvec)
    
    f=fvec(i);
    
    if (beta~=0)
        if ( abs(f) <= (1-beta)/2/T )
            out(i)=T;
        elseif ( abs(f) > (1+beta)/2/T )
            out(i)= 0;
        elseif ( abs(f) > (1-beta)/2/T ) &&  ( abs(f) <= (1+beta)/2/T)
            arg = abs(f) - (1-beta)/2/T;
            out(i)= T/2 * ( 1 + cos(pi*T/beta*arg) ) ;
        end
    end
end

return

%---- traveltime method
%% function [t] = vzmodel2d_calctime_vx(xE,xS,z,v0,av)
function TT=lsmig_born_lop_tt(v0,av)

global myBorn_lop

    TT = zeros(myBorn_lop.nz,myBorn_lop.nx);

    sml=1.e-6;
    lrg=1.e+6;

    for iz=(1:myBorn_lop.nz)
        
        z = (iz-1)*myBorn_lop.dz;
        v=v0+av*z;
    
        for ix=(1:myBorn_lop.nx)
        x = (ix-1)*myBorn_lop.dx;
        b=(x.*x+z.*z)./(2*v0*v);
        avb=av*b;

        %    check if velocity become negative, if it's the case traveltime becomes meaningless
        if (v>sml) 
            if(abs(av)>sml) 
                TT(iz,ix) = 1.0/av*log((1+av*avb)+av*sqrt(2*b+avb.*avb));
            else
                TT(iz,ix) = avb + sqrt(2*b+avb.*avb);
            end
        else
           TT(iz,ix)=lrg;
        end
        
        end
        
    end
    
return

%---- slowness method (in v(z) model slowness preserves at each depth)
function rayp = lsmig_born_lop_rayp(v0,av,TT)

global myBorn_lop

rayp = zeros(myBorn_lop.nz,myBorn_lop.nx);

sml=1.e-6;

for iz=(1:myBorn_lop.nz)
       
    for ix=(1:myBorn_lop.nx)
        
        x = (ix-1)*myBorn_lop.dx;
        t = TT(iz,ix);
        
        if(abs(av)>sml)
            if(x+1.0==1.0)
                rayp(iz,ix)=0.0;
            else
                a=exp(av*t);
                c=a*a-1.0;
                d=a*av*x;
                tmp = max(v0*v0*c*c-4*d*d,0.0);
                if(tmp>=0.0)
                    tau0=2*av*x/(v0*c+sqrt(tmp));
                    ang0=2*atan(tau0);
                    rayp(iz,ix)=sin(ang0)/v0;
                else
                    rayp(iz,ix)=0.0;
                end
            end
        else
             rayp(iz,ix)=x/(v0*t*v0);
        end
    end
end

return

%---- amplitude calculation
function A = lsmig_born_lop_A(v0,av,rayp)

global myBorn_lop

A = zeros(myBorn_lop.nz,myBorn_lop.nx);    
    
dim = 2;

for iz=(1:myBorn_lop.nz)
        z = (iz-1)*myBorn_lop.dz;
        v=v0+av*z;
    for ix=(1:myBorn_lop.nx)
        
        x = (ix-1)*myBorn_lop.dx;
        p = rayp(iz,ix);
        % p-preserves along propagation
        
        sinang=min(abs(p*v),1.0); %angle at the image point
        sinang0=min(abs(p*v0),1.0); %angle at the surface point
        
        if(dim==1)
            cosang0=1.0;
            cosang=1.0;
            psi=1.0;
            sigma=1.0;
            sprd=1.0;
        else
            if(p+1.0~=1.0 && x+1.0~=1.0)
                if(sinang0 <= 1.0 && sinang <= 1.0)
                    cosang=sqrt(max(1.0-sinang*sinang,1.e-7));
                    cosang0=sqrt(max(1.0-sinang0*sinang0,1.e-7));
                    psi=x/(p*cosang*cosang0);
                    if(dim==2)
                        sigma=1.0;
                        sprd=sqrt(p/x)*sqrt(v*v0);
                    else
                        sigma=x/p;
                        sprd=p/x*sqrt(v0*v);
                    end
                else
                    cosang=0.0;
                    cosang0=0.0;
                    psi=0.0;
                    sigma=0.0;
                    sprd=-1.0;
                end
            else %----- p==0 || x==0 %vertical ray             
                cosang=1.0;
                cosang0=1.0;
                psi=z/2.0*(v+v0);
                if(dim==2)
                    sigma=1.0;
                    sprd=sqrt(2.0/((v+v0)*z))*sqrt(v*v0);
                else
                    sigma=z/2.0*(v+v0);
                    sprd=2.0/((v+v0)*z)*sqrt(v0*v);
                end

            end
                
                
        end
        %A(iz,ix) = 1/sqrt(sprd);
        %
        A(iz,ix) = sqrt(v*v0)/sqrt(cosang0*psi*sigma);
%         Anum = sqrt(v*v0);
%         Aden = max(sqrt(cosang0*psi*sigma),1.e-2*sqrt(v*v0));
%         A(iz,ix) = Anum/Aden;
    end %loop over ix
end %loop over iz
        A(1,:) = A(2,:);
return




