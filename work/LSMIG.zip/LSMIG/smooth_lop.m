function out=smooth_lop(adj,nout,nin,in)


global smooth

dim1=0;
out = zeros(nout,1);

for i=1:smooth.dim
    if(smooth.rect(i) > 1)
        dim1=i;
    end
    
end
dim1;

n1=1;
n2=1;

for i=1:smooth.dim
    if  (i<=dim1)
        s(i)=n1;
        n1=n1*smooth.n(i);
    else
        n2=n2*smooth.n(i);
    end
end

s;
n1;
n2;

%     for (i2=0; i2 < n2; i2++) {
for i2=1:n2
    % 	sf_floatread(data,n1,in);
    datain=in( (i2-1)*n1+1 : i2*n1 );
    dataout = zeros(size(datain));
    % 	for (i=0; i <= dim1; i++) {
    for i=1:dim1
        % 	    if (rect[i] <= 1) continue;
        if (smooth.rect(i) <= 1)
            continue;
        end
        % tr = sf_triangle_init (rect[i],n[i]);
        tr = triangle_init(smooth.rect(i),smooth.n(i)) ;
       
        % for (j=0; j < n1/n[i]; j++) {
        for j=0:floor(n1/smooth.n(i))-1
            
            %i0 = sf_first_index (i,j,dim1+1,n,s);
            i0 = sf_first_index (i-1,j,dim1+1,[smooth.n,1],[s,1]);
                  
            for irep=1:smooth.nrep
                if (adj)
                          %sf_smooth(tr , o,   d,    der,    box, x)                        
                   dataout=sf_smooth(adj,tr ,i0,s(i),smooth.diff(i),smooth.box(i),  datain);
                   datain = dataout;
                else
                   dataout=sf_smooth(adj,tr ,i0,s(i),smooth.diff(i),smooth.box(i),  datain);
                   datain = dataout;
                end

            end
        end
    end
    % 	sf_floatwrite(data,n1,out);
    %     }
    out((i2-1)*n1+1 : i2*n1) = dataout;
end



function i0 = sf_first_index(i,j,dim,n,s)
    % i  /* dimension [0...dim-1] */, 
    % j  /* line coordinate */, 
    % dim  /* number of dimensions */, 
    % n[] /* box size [dim] */,
    % s[] /* step [dim] */)

    n123 = 1;
    i0 = 0;
    %for (k=0; k < dim; k++) {
    for k=0:dim-1
        if (k == i)
            continue;
        end
        %ii = (j/n123)%n[k]; /* to cartesian */
        ii = mod(floor(j/n123),n(k+1));
        %n123 *= n[k];
        n123 = n123 * n(k+1);
        %i0 += ii*s[k];      /* back to line */
        i0 = i0 + ii * s(k+1);
    end
return
    



