function y=myBorn_mask_lop(adj,ny,nx,x)

global myBorn_lop

if ( ny ~= nx )
    fprintf('__ERROR__lsmig_born_lop: data size problem: %d != %d',ny, nx );
    return
end

y=zeros(ny,1);

for iy=1:ny
    
    if myBorn_lop.mask(iy)
        y(iy)= y(iy)+x(iy);
    end
end

