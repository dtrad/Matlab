function [out]=myBorn_lop_precondOp_smooth_lop(adj,nd,nm,in)

% This function constructs an array of two linear operators, computing
% [oper1(mod) ; oper2(mod)] or its adjoint

% N.B. out   = matlab_lop(adj,ndata,nmodel,in);

ntmp = nm;

if (adj)
    out=zeros(ntmp,1);
else
    out=zeros(nd,1);
end


    
if (adj) % (P^T)(W^T)(L^T)
    tmp=feval('smooth_lop',1,nd,ntmp,in); % 
    out=feval('myBorn_lop_precondOp_lop',1,ntmp,nm,tmp);
else     % (L)(P)(W) 
    tmp=feval('myBorn_lop_precondOp_lop',0,ntmp,nm,in);
    out=feval('smooth_lop',0,nd,ntmp,tmp) ; 
end
    