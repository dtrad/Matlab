function out=matmult_lop(adj,nd,nm,in)

global matmult_lop

% if adj
%     out=zeros(nm,1);
% else
%     out=zeros(nd,1);
% end


if adj
    out=matmult_lop.L'*in;
else
    out=matmult_lop.L*in;
end