function out = lsmig_born_lop(adj,ndata,nxz,in)
% born modelling operator
% modelling (adj==0) d = L  * m
% adjoint   (adj==1) m = L' * m
% --> yes aperture taper
% --> yes amplitude weights As=Ar=1
% --> yes phase rotation
% --> yes source wavelet


%nmodel = nxz = nx x nz
%ndata  = nt x (nin x ns)

global  myBorn_lop

if(adj)
    if ( numel(in) ~= myBorn_lop.nt * myBorn_lop.nin * myBorn_lop.ns ||  numel(in)~=ndata )
        fprintf('__ERROR__lsmig_born_lop: data size problem: %d != %d',ndata, myBorn_lop.nt * myBorn_lop.nin * myBorn_lop.ns );
        return
    end
    out = zeros(nxz,1);
else
    
    if ( numel(in) ~= myBorn_lop.nz * myBorn_lop.nx ||  numel(in)~= nxz)
        fprintf('__ERROR__lsmig_born_lop: model size problem: %d != %d',nxz, myBorn_lop.nz * myBorn_lop.nx );
        return
    end
    out = zeros(ndata,1);
    
end

%dd = 10;
for id = 1:myBorn_lop.nin * myBorn_lop.ns
    %for id = 1 : myBorn_lop.nin * myBorn_lop.ns
    
    %loop over the traces in the input CSGs (data)
    if (myBorn_lop.verb)
        if (adj)
            disp(['adjoint...: trace =',num2str(id),'/',num2str(myBorn_lop.nin * myBorn_lop.ns)])
        else
            disp(['forward...: trace =',num2str(id),'/',num2str(myBorn_lop.nin * myBorn_lop.ns)])
        end
    end
    s = myBorn_lop.shtxs(id);
    r = myBorn_lop.recxs(id);
    
    if  (adj)
        %trace = in( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt);
        trace = sf_bp_apply( in( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt) );
        if (myBorn_lop.hd)
            trace_hd = sf_halfint_lop(adj,trace);
            
            if (myBorn_lop.hd==2)
                trace_hd = sf_halfint_lop(adj,trace_hd);
            end
            
        end
    else
        tmp = zeros(myBorn_lop.nt,1);
    end
    
    
    for ixz = 1 : nxz
        %---- loop over the image
        ix = floor( (ixz-1) / myBorn_lop.nz) + 1;
        iz =   mod(  ixz-1 , myBorn_lop.nz)  + 1;
        
        %fprintf('ixz=%d,iz=%d,ix=%d\n',ixz,iz,ix)
        m = (ix-1) * myBorn_lop.dx + myBorn_lop.fXL * myBorn_lop.dx;
        z = (iz-1) * myBorn_lop.dz;
        h = (r - s);
        %---- compute aperture angles
        
        if ( r >= s) % positive offsets
            aperxs = s-m;
            aperxr = m-r;
        else % negative offsets(s<=r)
            aperxs = m-s;
            aperxr = r-m;
        end
        
        %---- aperture limitation (midpoints)
        
        if (  aperxs > (myBorn_lop.aperx ) ) continue; end
        if (  aperxr > (myBorn_lop.aperx ) ) continue; end
        
        %---- conpute aperture taper (midpoints)
        w_aperxs=1.0;w_aperxr=1.0;
        if ( aperxs <= myBorn_lop.aperx-myBorn_lop.aperxtp )
            w_aperxs = 1.0;
        else
            xs = (aperxs-(myBorn_lop.aperx-myBorn_lop.aperxtp)) / myBorn_lop.aperxtp;
            w_aperxs=myBorn_lop.rc_taper(round(xs/myBorn_lop.rc_step)+1);
        end
        
        if (aperxr <= myBorn_lop.aperx-myBorn_lop.aperxtp )
            w_aperxr = 1.0;
        else
            xr = (aperxr-(myBorn_lop.aperx-myBorn_lop.aperxtp)) / myBorn_lop.aperxtp;
            w_aperxr =myBorn_lop.rc_taper(round(xr/myBorn_lop.rc_step)+1);
        end
        
        w_aperxsr = w_aperxs*w_aperxr;
        %---- compute analytical traveltimes        
        %ts = sqrt( (s-m)^2 + z^2 ) / myBorn_lop.vs;
        %tr = sqrt( (r-m)^2 + z^2 ) / myBorn_lop.vr;
        
        %---- use precomputed traveltimes
        ts = myBorn_lop.TTs(iz, round( abs(m-s)/myBorn_lop.dx ) + 1 ); 
        tr = myBorn_lop.TTr(iz, round( abs(r-m)/myBorn_lop.dx ) + 1 );         
        tsr = ts+tr;
        
        if ( tsr > myBorn_lop.tmax || tsr < 0)
            continue
        end
        
        it0 = floor(tsr / myBorn_lop.srate ) + 1;
        it1 = it0 + 1;
        
        if (it0<1 || it0>myBorn_lop.nt)
            continue
        end
        
        %---- use precomputed amplitudes
        
        if myBorn_lop.useAmp
            As = myBorn_lop.As(iz, round( abs(m-s)/myBorn_lop.dx ) + 1 );
            Ar = myBorn_lop.Ar(iz, round( abs(m-s)/myBorn_lop.dx ) + 1 );
        else
            As=1;
            Ar=1;
        end
        
        Asr = As*Ar;
        
        
        if (adj)
            if (myBorn_lop.hd)
                tmp = trace_hd;
            else
                tmp = trace;
            end
            out(ixz) = out(ixz) + ...
                tmp(it0) ...
                * ( (it1-1)*myBorn_lop.srate-tsr) ...
                * w_aperxsr ...
                * Asr;
            if (it1<=myBorn_lop.nt)
                out(ixz) = out(ixz) + ...
                    tmp(it1) ...
                    *(tsr - (it0-1)*myBorn_lop.srate) ...
                    * w_aperxsr ...
                    * Asr;
            end
        else
            tmp(it0) = tmp(it0) + ...
                in(ixz) ...
                * ( (it1-1)*myBorn_lop.srate-tsr) ...
                * w_aperxsr ...
                * Asr;
            if (it1<=myBorn_lop.nt)
                tmp(it1) =  tmp(it1) + ...
                    in(ixz) ...
                    *(tsr-(it0-1)*myBorn_lop.srate) ...
                    * w_aperxsr ...
                    * Asr;
            end
    
        end
        
    end
    
    if (~adj)
        if (myBorn_lop.hd)
            trace_hd =  sf_halfint_lop(adj,tmp);
            if (myBorn_lop.hd==2)
                trace_hd =  sf_halfint_lop(adj,trace_hd);
            end
            %out( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt ) = trace_hd;
            out( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt ) = sf_bp_apply( trace_hd );
        else
            trace = tmp;
            %out( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt ) = trace ;
            out( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt ) = sf_bp_apply( trace );
        end
    end
    
end





