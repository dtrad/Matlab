%
clc; close all; clear all;
f1=1;
f2=2;
f3=20;
f4=25;

w1 = pi * f1 / pi;
w2 = pi * f2 / pi;
w3 = pi * f3 / pi;
w4 = pi * f4 / pi;

A = w4^2/(w4-w3);
B = w3^2/(w4-w3);
C = w2^2/(w2-w1);
D = w1^2/(w2-w1);

ABCD = A - B - C + D;

nt=1001;
dt=0.004;
flt = zeros(nt,1);
t0=1;%(nt+1)/2*dt;

wlt=0.0;
for it=1:nt
    
    t=it*dt;
    t1=t-t0;
    
    %broadband ormbsy wavelet
    wlt =( + A * ( sinc(w4*t1))^2 ...
        - B * ( sinc(w3*t1))^2 ...
        - C * ( sinc(w2*t1))^2 ...
        + D * ( sinc(w1*t1))^2 ...
        ) /ABCD;
    flt(it) = flt(it)+wlt;
    
    
end % loop over trace samples



nfft=2^nextpow2(nt)
nw = nfft/2+1;
dw = 1/nfft/dt;



flt_fft=fft(flt,nfft);
flt_fft=flt_fft(1:nw,:);
MASK=[1;2*ones(nw-2,1);1];
flt_fft=flt_fft.*MASK;

figure;plot([0:nw-1]*dw,abs(flt_fft))

%figure;plot([0:nfft-1]/nfft/dt,abs(flt_fft))

flt_ifft = real(ifft(flt_fft,nfft));
flt_ifft = flt_ifft(1:nt);
figure;
plot([0:nt-1]*dt,flt,'r:');hold on
plot([0:nt-1]*dt,flt_ifft,'b--');
figure
plot([0:nt-1]*dt,flt-flt_ifft)

h = spectrum.welch;
Hpsd_flt = psd(h,flt,'Fs',1/dt);  
figure;plot(Hpsd_flt)
