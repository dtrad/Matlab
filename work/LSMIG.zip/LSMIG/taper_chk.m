clc; close all; clear all;

fvec=[0:.01:1];

T = 1;
beta = .75;

for i=1:numel(fvec)

    f=fvec(i);
    
if (beta~=0)
    if ( abs(f) <= (1-beta)/2/T )
        out(i)=T;
    elseif ( abs(f) > (1+beta)/2/T )
        out(i)= 0;
    elseif ( abs(f) > (1-beta)/2/T ) &&  ( abs(f) <= (1+beta)/2/T) 
        arg = abs(f) - (1-beta)/2/T;
        out(i)= T/2 * ( 1 + cos(pi*T/beta*arg) ) ;
    end
end
end


figure
plot(fvec,out)