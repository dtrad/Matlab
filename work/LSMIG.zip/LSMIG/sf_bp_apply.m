function out=sf_bp_apply(in)

global bp;

in_ftt=fft(in,bp.nfft);
in_ftt=in_ftt(1:bp.nw,:);
MASK=[1;2*ones(bp.nw-2,1);1];
in_ftt=in_ftt.*MASK;


if bp.src_wlt
    out_fft = in_ftt.*(bp.flt).*(bp.wlt);
else
   out_fft = in_ftt.*(bp.flt); 
end
out = real(ifft(out_fft,bp.nfft));

out = out(1:bp.nt);


return
