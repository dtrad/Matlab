%% triangular smoothing


function x = sf_smooth(adj,tr , o,  d, der, box, x)

    if (adj)
        tr.tmp = triple2 ( o,  d,  tr.nx,  tr.nb,  x,  tr.tmp,  box);
        tr.tmp = doubint2 (tr.np,tr.tmp, (box || der) );
        x= fold2(o,d,tr.nx,tr.nb,tr.np,x,tr.tmp);
    else
        tr.tmp = fold(o,d,tr.nx,tr.nb,tr.np,x,tr.tmp);
        tr.tmp = doubint (tr.np,tr.tmp, (box || der) );
        x = triple ( o,  d,  tr.nx,  tr.nb,  x,  tr.tmp,  box);
    end
end
%% fold
function tmp = fold (o,d,nx,nb,np,x,tmp)
% copy middle */
for (i=0:nx-1)
    tmp(i+nb +1) = x(o+i*d +1);
end

%reflections from the right side */
%for (j=nb+nx; j < np; j += nx) {
for (j=nb+nx: nx : np-1)
    %for (i=0; i < nx && i < np-j; i++)
    for (i=0:min(nx,np-j)-1 )
        tmp(j+i +1) = x(o+(nx-1-i)*d +1);
    end
    j = j + nx;
    %for (i=0; i < nx && i < np-j; i++)
    for (i=0:min(nx,np-j)-1 )
        tmp(j+i +1) = x(o+i*d +1);
    end
end



% reflections from the left side */
%for (j=nb; j >= 0; j -= nx) {
for (j=nb:-nx:0)
    %for (i=0; i < nx && i < j; i++)
    for (i=0:min(nx,j)-1)
        tmp(j-1-i +1) = x(o+i*d +1);
    end
    j = j - nx;
    
    
    %for (i=0; i < nx && i < j; i++)
    for (i=0:min(nx,j)-1)
        tmp(j-1-i +1) = x(o+(nx-1-i)*d +1);
    end
end
end


function x = fold2(o,d,nx,nb,np,x,tmp)

%/* copy middle */
%for (i=0; i < nx; i++)
%x[o+i*d] = tmp[i+nb];
for i=0:nx-1
    %tmp(i+nb +1) = x(o+i*d +1);
    x(o+i*d+1) = tmp(i+nb+1);
end

%/* reflections from the right side */
%for (j=nb+nx; j < np; j += nx) {
for j=nb+nx: nx : np-1
    %for (i=0; i < nx && i < np-j; i++)
    for i=0:min(nx,np-j)-1
        %x[o+(nx-1-i)*d] += tmp[j+i];
        x(o+(nx-1-i)*d +1 ) = ...
            x(o+(nx-1-i)*d +1 ) + tmp(j+i +1);
    end
    %j += nx;
    j = j + nx;
    
    %for (i=0; i < nx && i < np-j; i++)
    for i=0:min(nx,np-j)-1
        %x[o+i*d] += tmp[j+i];
        x(o+i*d +1) = ...
            x(o+i*d +1) + tmp(j+i+1);
    end
end

%/* reflections from the left side */
%for (j=nb; j >= 0; j -= nx) {
for j=nb:-nx:0
    
    %for (i=0; i < nx && i < j; i++)
    for i=0:min(nx,j)-1
        %    x[o+i*d] += tmp[j-1-i];
        x(o+i*d+1) = ...
            x(o+i*d+1) + tmp(j-1-i+1);
    end
    %j -= nx;
    j = j - nx;
    %for (i=0; i < nx && i < j; i++)
    for i=0:min(nx,j)-1
        %    x[o+(nx-1-i)*d] += tmp[j-1-i];
        x(o+(nx-1-i)*d+1) = ...
            x(o+(nx-1-i)*d+1) + tmp(j-1-i+1);
    end
end

end

%% causal anticausal integration
function xx = doubint( nx, xx, der)
% integrate backward
t=0;

%for (i=nx-1; i >= 0; i--)
for i=nx-1:-1:0
    t = t + xx(i +1);
    xx(i +1) = t;
end

if (der)
    return;
end

% integrate forward
t=0;
for i=0:nx-1
    t = t + xx(i +1);
    xx(i +1) = t;
end


end


function xx = doubint2( nx, xx, der)

% integrate forward
t=0;
for i=0:nx-1
    t = t + xx(i+1);
    xx(i+1) = t;
end

if (der)
    return;
end

% integrate backward
t=0;

%for (i=nx-1; i >= 0; i--)
for i=nx-1:-1:0
    t = t + xx(i +1);
    xx(i +1) = t;
end


end


function x = triple ( o,  d,  nx,  nb,  x,  tmp,  box)


if (box)
    %tmp2 = tmp + 2*nb;
    wt = 1.0/(nb);
    
    for i=0:nx-1
        %x[o+i*d] = (tmp[i+1] - tmp2[i])*wt;
        x(o+i*d+1) = (tmp(i+1+1) - tmp(2*nb+i+1) )*wt;
    end
else
    
    %tmp1 = tmp + nb;
    %tmp2 = tmp + 2*nb;

    wt = 1.0/(nb*nb);
    for (i=0:nx-1)
        % x[o+i*d] = (2.*tmp1[i] - tmp[i] - tmp2[i])*wt;
        x(o+i*d+1) = (2.*tmp(nb+i+1) - tmp(i+1) - tmp(2*nb+i+1))*wt;
    end
end

end

function tmp = triple2 ( o,  d,  nx,  nb,  x,  tmp,  box)

%for (i=0; i < nx + 2*nb; i++)
for i=0:nx+2*nb-1
    tmp(i+1) = 0;
end

if (box)
    wt = 1.0/(2*nb-1);
    for i=0:nx-1
        %cblas_saxpy(nx,  +wt,x+o,d,tmp+1   ,1);
        tmp(i+1+1)    = tmp(i+1+1) +wt * x(o+i*d+1);
        %cblas_saxpy(nx,  -wt,x+o,d,tmp+2*nb,1);
        tmp(2*nb+i+1) = tmp(2*nb+i+1) -wt * x(o+i*d+1);
    end
else
    wt = 1.0/(nb*nb);
    for i=0:nx-1
        %cblas_saxpy(nx,  -wt,x+o,d,tmp     ,1);
        tmp(i+1)      = tmp(i+1)    -wt*x(o+i*d+1);
        %cblas_saxpy(nx,2.*wt,x+o,d,tmp+nb  ,1);
        tmp(nb+i+1)   = tmp(nb+i+1) +2*wt*x(o+i*d+1);
        %cblas_saxpy(nx,  -wt,x+o,d,tmp+2*nb,1);
        tmp(2*nb+i+1) = tmp(2*nb+i+1)-wt*x(o+i*d+1);
    end
end

end

