function [out]=lsmig_mask_born_lop(adj,ndata,nmodel,in)

% This function constructs an array of two linear operators, computing
% [oper1(mod) ; oper2(mod)] or its adjoint

% N.B. out   = matlab_lop(adj,ndata,nmodel,in);



if (adj)
    out=zeros(nmodel,1);
else
    out=zeros(ndata,1);
end

%Lm  = myBorn_mask_lop(0, ndata, ndata, lsmig_born_lop( 0 , ndata, nmodel, m));
%LTd = lsmig_born_lop( 1 , ndata, nmodel,   myBorn_mask_lop(1, ndata, ndata, d));
    
if (adj) 
    tmp=feval('myBorn_mask_lop',1,ndata,ndata,in); % 
    out=feval('lsmig_born_lop',1,ndata,nmodel,tmp);
else    
    tmp=feval('lsmig_born_lop',0,ndata,nmodel,in);
    out=feval('myBorn_mask_lop',0,ndata,ndata,tmp) ; 
end
    