clc,clear all, close all
addpath('..\lop')
addpath('..\src\SEGY')

%% creating input event
o1=0;
d1=0.004;
n1=1001;
t0 = 2;

n2=1;

% impulse responses
%in=zeros(n1,1);
%in(501) = 1;


%  wavelet test

f0=8;
[w,tw] = ricker(f0,d1);
w=w(:);
nw=numel(w);

icai_init(nw,w(:),1);
in=icai_lop(0,n1,n1,sinc([0:n1-1]' - (t0+tw(1))/d1));

t=o1+[0:n1-1]'*d1;

%% impulse responses
figure('name','half derivative')

rho = 1-1/n1;
rho=.95;
%--- half derivative
inv=1; adj=0; 
sf_halfint_init(inv,n1,rho)
in_hd=sf_halfint_lop(adj,in);
in_hd2=sf_halfint_lop(adj,in_hd);
stem([1:n1],in_hd); hold on
stem([1:n1],in_hd2,'r'); hold on
legend('hd','hd(hd')

%--- half integration
figure('name','half integration')

inv=0; adj=0; 
sf_halfint_init(inv,n1,rho);
in_hi=sf_halfint_lop(adj,in);
in_hi2=sf_halfint_lop(adj,in_hi);
stem([1:n1],in_hi); hold on
stem([1:n1],in_hi2,'r'); 
legend('hi','hi(hi)')

%--- half derivation + half integration
inv=0;
sf_halfint_init(inv,n1,rho);
adj=0;
in_hd_hi = sf_halfint_lop(adj,in_hd);
adj=1;
in_hd_adjhi = sf_halfint_lop(adj,in_hd);

figure('name','hd + hi')
plot([1:n1],in','r','Linewidth',2.0);hold on
stem([1:n1],in_hd); 
stem([1:n1],in_hd_hi,'r'); 
stem([1:n1],in_hd_adjhi,'k'); 
legend('in','hd','hi(hd)','hi*(hd)')
set(gca,'Xlim',[400 600])
%%





