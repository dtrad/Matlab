function out = lsmig_born_lop_v3(adj,ndata,nxz,in)
% born modelling operator
% modelling (adj==0) d = L  * m
% adjoint   (adj==1) m = L' * m
% --> yes aperture taper in midpoint direction
% --> no amplitude weights As=Ar=1
% --> no phase rotation
% --> no source wavelet


%nmodel = nxz = nx x nz
%ndata  = nt x (nin x ns)

global  myBorn_lop

if(adj)
    if ( numel(in) ~= myBorn_lop.nt * myBorn_lop.nin * myBorn_lop.ns ||  numel(in)~=ndata )
        fprintf('__ERROR__lsmig_born_lop: data size problem: %d != %d',ndata, myBorn_lop.nt * myBorn_lop.nin * myBorn_lop.ns );
        return
    end
    out = zeros(nxz,1);
else
    
    if ( numel(in) ~= myBorn_lop.nz * myBorn_lop.nx ||  numel(in)~= nxz)
        fprintf('__ERROR__lsmig_born_lop: model size problem: %d != %d',nxz, myBorn_lop.nz * myBorn_lop.nx );
        return
    end
    out = zeros(ndata,1);
    
end

%dd = 10;
for id = 1:myBorn_lop.nin * myBorn_lop.ns
    %for id = 1 : myBorn_lop.nin * myBorn_lop.ns
    
    %loop over the traces in the input CSGs (data)
    if (myBorn_lop.verb)
        if (adj)
            disp(['adjoint...: trace =',num2str(id),'/',num2str(myBorn_lop.nin * myBorn_lop.ns)])
        else
            disp(['forward...: trace =',num2str(id),'/',num2str(myBorn_lop.nin * myBorn_lop.ns)])
        end
    end
    s = myBorn_lop.shtxs(id);
    r = myBorn_lop.recxs(id);
    
    if  (adj)
        trace = in( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt);
    else
        trace = zeros(myBorn_lop.nt,1);
    end
    
    
    for ixz = 1 : nxz
        %---- loop over the image
        ix = floor( (ixz-1) / myBorn_lop.nz) + 1;
        iz =   mod(  ixz-1 , myBorn_lop.nz)  + 1;
        
        %fprintf('ixz=%d,iz=%d,ix=%d\n',ixz,iz,ix)
        m = (ix-1) * myBorn_lop.dx + myBorn_lop.fXL * myBorn_lop.dx;
        z = (iz-1) * myBorn_lop.dz;
        h = (r - s);
        %---- compute aperture angles
        
        if ( r >= s) % positive offsets
            aperxs = s-m;
            aperxr = m-r;
        else % negative offsets(s<=r)
            aperxs = m-s;
            aperxr = r-m;
        end
        
        %---- aperture limitation (midpoints)
        
        if (  aperxs > (myBorn_lop.aperx ) ) continue; end
        if (  aperxr > (myBorn_lop.aperx ) ) continue; end
        
        %---- conpute aperture taper (midpoints)
        w_aperxs=1.0;w_aperxr=1.0;
         if ( aperxs <= myBorn_lop.aperx-myBorn_lop.aperxtp )
             w_aperxs = 1.0;
         else             
            xs = (aperxs-(myBorn_lop.aperx-myBorn_lop.aperxtp)) / myBorn_lop.aperxtp;
            w_aperxs=myBorn_lop.rc_taper(round(xs/myBorn_lop.rc_step)+1);
         end
         
         if (aperxr <= myBorn_lop.aperx-myBorn_lop.aperxtp )
             w_aperxr = 1.0;
         else
             xr = (aperxr-(myBorn_lop.aperx-myBorn_lop.aperxtp)) / myBorn_lop.aperxtp; 
             w_aperxr =myBorn_lop.rc_taper(round(xr/myBorn_lop.rc_step)+1);
         end        
        
        w_aperxsr = w_aperxs*w_aperxr;
        %---- compute analytical traveltimes
        
        ts = sqrt( (s-m)^2 + z^2 ) / myBorn_lop.vs;
        tr = sqrt( (r-m)^2 + z^2 ) / myBorn_lop.vr;
        tsr = ts+tr;
        if ( tsr > myBorn_lop.tmax || tsr < 0)
            continue
        end
        
        it0 = floor(tsr / myBorn_lop.srate ) + 1;
        it1 = it0 + 1;
        
        if (it0<1 || it0>myBorn_lop.nt)
            continue
        end
        %---- compute analytical amplitudes
        As = 1;
        Ar = 1;
        Asr = As*Ar;
        
        
        if (adj)
            out(ixz) = out(ixz) + ...
                trace(it0) ...
                * ( (it1-1)*myBorn_lop.srate-tsr) ...
                * w_aperxsr;
            if (it1<=myBorn_lop.nt)
                out(ixz) = out(ixz) + ...
                    trace(it1) ...
                    *(tsr - (it0-1)*myBorn_lop.srate) ...
                    * w_aperxsr;
            end
        else
            trace(it0) = trace(it0) + ...
                in(ixz) ...
                * ( (it1-1)*myBorn_lop.srate-tsr) ...
                * w_aperxsr ;
            if (it1<=myBorn_lop.nt)
                trace(it1) =  trace(it1) + ...
                    in(ixz) ...
                    *(tsr-(it0-1)*myBorn_lop.srate) ...
                    * w_aperxsr ;
            end
            
            out( (id-1)*myBorn_lop.nt + 1 : id*myBorn_lop.nt ) = trace;
            
        end
        
    end
    
end





