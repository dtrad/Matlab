%check gaussND_lop
clc; close all; clear all;
addpath('C:\Users\lcasasan\Documents\MATLAB\lop')

nz=21;
nx=11;
sigmaz=1;
sigmax=5;


test_in = speye(nz*nx);
outop=zeros(nz*nx);
outop_adj=outop;


%gauss1d_init(nz,nx,sigmaz); precond=@gauss1D_lop
gauss2d_init(nz,nx,sigmaz,sigmax); precond=@gauss2D_lop
%% ---- compute impulse response
for i=1:size(test_in,1)
    
    outop(:,i)=feval(precond,0,nx*nz,nx*nz,test_in(:,i));
    outop_adj(:,i)=feval(precond,1,nx*nz,nx*nz,test_in(:,i));
end
figure,subplot(221),spy(outop)
subplot(222),spy(outop'-outop_adj)

subplot(223),imagesc(outop),axis image
subplot(224),imagesc(outop'-outop_adj),axis image

%% ---- adjoint test
d = randn(nz*nx,1);
m = randn(nz*nx,1);

Lm  = feval( precond, 0 , nz*nx, nz*nx, m) ;
LTd = feval( precond, 1 , nz*nx, nz*nx, d) ;

dTLm =  d' * Lm;
LTdm = LTd' * m;
fprintf('Adjoint test lsmig_born_lop d^T(Lm) = %g (L^Td)m= %g\n',dTLm,LTdm);