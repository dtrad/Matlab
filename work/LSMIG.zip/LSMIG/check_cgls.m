%cgsl test
clc; close all; clear all;
global matmult_lop;
m = 100;
n = 125;
L = round(rand(n,m)*1000)/100;
x = ones(m,1);
dn =  randn(n,1); 
d = L * x + dn;

xpinv = pinv(L)*d;


figure;plot(xpinv,'b:'); hold on



matmult_lop.L = L;
epsi = 1e-3;
niter = 100;

m0 = zeros(m,1);
%m0 = .99*ones(m,1);


[xcg_old,resNEcg_old,kcg_old,info] = cgls('matmult_lop',epsi,d,n,m,niter,1e-16,1);
plot(xcg_old,'bx')

[xcg,resNEcg,kcg,info] = cgls_v1('matmult_lop',m0,epsi,d,n,m,niter,1e-16,1);
plot(xcg,'ro')

figure
semilogy([0:kcg],resNEcg(1:kcg+1),'ro'); hold on;
semilogy([0:kcg_old],resNEcg_old(1:kcg_old+1),'bx')