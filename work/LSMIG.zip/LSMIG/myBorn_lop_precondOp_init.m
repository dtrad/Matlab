function myBorn_lop_precondOp_init(Asx,Arx)

global myBorn_lop

%---- shot side preconditioning ~ 1/As

nxz = myBorn_lop.nz * myBorn_lop.nx;

myBorn_lop.precondOp=zeros(nxz,1);

is = 1;
for id = 1:myBorn_lop.nin * myBorn_lop.ns
    
    s = myBorn_lop.shtxs(id);
    r = myBorn_lop.recxs(id);
    
    if (floor(id/myBorn_lop.nin)+1 ==is)
        
        for ixz = 1 : nxz
            %---- loop over the image
            ix = floor( (ixz-1) / myBorn_lop.nz) + 1;
            iz =   mod(  ixz-1 , myBorn_lop.nz)  + 1;
            
            %fprintf('ixz=%d,iz=%d,ix=%d\n',ixz,iz,ix)
            m = (ix-1) * myBorn_lop.dx + myBorn_lop.fXL * myBorn_lop.dx;
            
            
            As = Asx(iz, round( abs(m-s)/myBorn_lop.dx ) + 1 );
            myBorn_lop.precondOp(ixz) = myBorn_lop.precondOp(ixz) + As ;
            
        end
        is = is + 1 ;
    end
    
     
end

myBorn_lop.precondOp=1./myBorn_lop.precondOp;



