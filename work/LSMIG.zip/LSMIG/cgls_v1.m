function [x,resNE,k,info] = cgls_v1(Lname,x0,shift,d,m,n,kmax,tol,prnt)
%
%        [x,resNE,k,info] = cgls('Lname',shift,b,m,n,kmax,tol,prnt);
%
% solves a symmetric system
%
%        (L'L + shift I'I)x = L'd      or      N x = L'd,
%
% where L is a general m by n matrix and shift may be positive or negative.
% The method should be stable if N = (L'L + shift I'I) is positive definite.
% It MAY be unstable otherwise.
%
%
% Input:
% Lname = abstract linear operator name (m by n)
% m0    = model starting guess (m by 1)
% shift = Tickhonov regularization paramter
% d     = data vector (n by 1)
% kmax  = maximum number of iterations.
% tol   = desired relative residual size, norm(rNE)/norm(L'd),
%         where rNE = L'd - N m.
% prnt  = 1 gives an iteration log, 0 suppresses it.
%
% Output:
% resNE = relative residual for normal equations: norm(A'b - Nx)/norm(A'b).
% k     = final number of iterations performed.
% info  = 1 if required accuracy was achieved,
%       = 2 if the limit kmax was reached,
%       = 3 if N seems to be singular or indefinite.
%       = 4 if instability seems likely.  (N indefinite and normx decreased.)

% When shift = 0, cgls is Hestenes and Stiefel's specialized form of the
% conjugate-gradient method for least-squares problems.  The general shift
% is a simple modification.
%
% 01 Sep 1999: First version.
%              Per Christian Hansen (DTU) and Michael Saunders (visiting DTU).
%-----------------------------------------------------------------------------

%% Initialize
   resNE= NaN*ones(kmax,1); 
   x = x0;
   if (sum(x(:))==0)
       s = d;
       r = feval(Lname,1,m,n,s);        
   else
       s = d - feval(Lname,0,m,n,x);        % s = d - Lm   
       r = feval(Lname,1,m,n,s) - shift*x;  % r = L's - mu*I*x0;
   end
   
   c = r;
   
   normr0 = norm(r);     gamma = normr0^2;
   xmax = 0;             normx  = 0;
   k    = 0;             info   = 0;

   if prnt
      head = '    k       x(1)             x(n)           normx        resNE';
      form = '%5.0f %16.10g %16.10g %9.2g %12.5g';
      disp('  ');   disp(head);
      disp( sprintf(form, k,x(1),x(n),normx,1) )
   end

   indefinite = 0;
   unstable   = 0;
    
   resNE(k+1)=1;
%---------------------------------------------------------------------------
%% Main loop
%---------------------------------------------------------------------------
   while (k < kmax) & (info == 0) 

      k     = k+1;
      q     = feval(Lname,0,m,n,c);                % q = Lc

      delta = norm(q)^2  +  shift*norm(c)^2;       % q'q + mu c'c
      if delta <= 0, indefinite = 1;   end
      if delta == 0, delta      = eps; end
      alpha = gamma / delta;                       % alpha = r'r / (q'q + mu c'c)

      x     = x + alpha*c;
      s     = s - alpha*q;
      r     = feval(Lname,1,m,n,s)  -  shift*x;    % r = A's - shift I x

      normr = norm(r);
      gamma1= gamma;
      gamma = normr^2;
      beta  = gamma / gamma1;                      % beta = r'r/(r_old'r_old)
      c     = r + beta*c;                          % c = r + beta * c

   %% Convergence
      normx = norm(x);
      xmax  = max( xmax, normx );
      info  = (normr <= normr0 * tol) | (normx * tol >= 1);

   %% Output
      resNE(k+1) = normr / normr0;
      if prnt, disp( sprintf(form, k,x(1),x(n),normx,resNE(k+1)) ); end
   end %while

shrink = normx/xmax;
if     k == kmax,       info = 2; end
if    indefinite,       info = 3; end
if shrink <= sqrt(tol), info = 4; end
return;
