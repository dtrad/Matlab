function  match_filter_init(nt1,nw1,M1,o1)

    global nt nw M o
    
nt=nt1;
nw=nw1;
M=M1;