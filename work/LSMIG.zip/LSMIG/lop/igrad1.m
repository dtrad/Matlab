function out=igrad1(adj,ndata,nmodel,in)

if adj
    out=zeros(nmodel,1); 
else    
    out=zeros(ndata,1);
end


if adj
    
    for i=1:ndata
        if i==ndata
        out(i) = out(i)+in(i);
        else
        %out(i+1) = out(i+1)+in(i);
        out(i)   = out(i)+in(i)-in(i+1);
        end
    end
else
    for i=1:nmodel
        if i==1
        out(i) = out(i)+in(i);
        else
        out(i) = out(i)+in(i)-in(i-1);
        end
    end
end
    
