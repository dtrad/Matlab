%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=tcaf_lop(adj,ny,nb,in)

global lag_1 xx_1 nx_1

if adj
    out=zeros(nb,1);
else
    out=zeros(ny,1);
end 

if(not(nx_1==ny)) 
    fprintf('__ERROR__icaf_1_lop: size problem: %d != %d',ny,nx_1);
    return
end


for b=0:nb-1
    for y=nb:ny

        x = y - b - 1;
        if( adj)
            out(b+1) = out(b+1) ...
                    + ( in(y-lag_1+1) * conj(xx_1(x+1)) );

        else

            out(y-lag_1+1) = out(y-lag_1+1)...
                    +( in(b+1) * xx_1(x+1) );
        end
    end
end