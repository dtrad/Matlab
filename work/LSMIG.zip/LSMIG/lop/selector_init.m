function selector_init(numeroCol,nx)

global mask nj
mask=zeros(nx,1);
mask(numeroCol)=1;
nj=nx;