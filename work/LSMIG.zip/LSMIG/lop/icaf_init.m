function icaf_init(ny,yy,lag1)

global nx
global xx
global lag

lag=lag1;
xx=yy;
nx=ny;