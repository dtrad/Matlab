function gauss2D_init(varargin)

global filter1 M1 filter2 M2 n1 n2 

n1=varargin{1};
n2=varargin{2};
sigma1 = varargin{3};
[filter1, M1] = gauss_init(sigma1);
if nargin == 1
    M2 = M1;
    filter2 = filter1;
else
    sigma2 = varargin{4};
    [filter2, M2] = gauss_init(sigma2);
end