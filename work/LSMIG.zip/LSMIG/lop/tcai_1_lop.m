%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=tcai_1_lop(adj,ny,nx,in)

global nb bb

if adj
    out=zeros(nx,1);
else
    out=zeros(ny,1);
end 


for b=0:nb-1
	for x=0:nx-1
            y = x + b;
	    if( adj) out(x+1) = out(x+1) + in (y+1) * conj( bb(b+1));
	    else     out(y+1) = out(y+1) + in (x+1) * conj( bb(b+1));
        end
    end
   end
    
end