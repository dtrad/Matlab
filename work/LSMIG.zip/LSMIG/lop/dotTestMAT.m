function dotTestMAT(A,n,m)

x = randn(n, 1);
y = randn(m, 1);

v = A*x;
z = A'*y;

v = y' * v;
z = x' * z;

if abs(v-z)/abs(v)> 1e-4

    disp('dot Test failure')
else

    disp('dot Test success')
end