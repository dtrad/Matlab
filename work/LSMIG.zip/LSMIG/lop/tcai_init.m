function tcai_init(nb_1,b_1)

global nb bb

nb=nb_1;
bb=b_1;