function y = gauss2D_lop(adj,nd,nm,x)

global M1 filter1 M2 filter2 n1 n2

 

temp = zeros(nd,1);
y = temp;


for i = 1:n2
    indici = (i-1)*n1+1:i*n1;
    in = x(indici);
    temp(indici) = gauss_lop(filter1, M1, n1, in);
end

for i = 1:n1
    indici = (0:n1:(n2-1)*n1)+i;
    in = temp(indici);
    y(indici) = gauss_lop(filter2, M2, n2, in);
end

y=y(:);