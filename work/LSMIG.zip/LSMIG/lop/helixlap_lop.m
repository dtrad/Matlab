function y = helixlap_lop(adj,nd,nm,x)

global flt lag_flt

if adj
    tmp=helidecon(1,flt,numel(flt),lag_flt,x(:),nd);
    y = helidecon(0,flt,numel(flt),lag_flt,tmp(:),nm);
else
    tmp=helidecon(0,flt,numel(flt),lag_flt,x(:),nm);
    y = helidecon(1,flt,numel(flt),lag_flt,tmp(:),nd);
end