function [a, b] = check2(m, n, x)

[a, b] = size(x);
if a*b~=m*n && m~=1 &&n~=1
    error('Error: input parameters not matching size of matrix x')
end
    