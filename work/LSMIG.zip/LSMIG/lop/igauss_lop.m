function y = igauss_lop(ifilter, N, n, x)


x = check1(n, 1, x);

sum = ifilter(3+1);

u = zeros(n, 1);
y = u;

iplus = 0;
b3=-ifilter(0+1) ;
b2=-ifilter(1+1) ;
b1=-ifilter(2+1) ;

uplus = iplus/(1.0-b1-b2-b3);
b1 = ifilter(4+1); b2 = ifilter(5+1); b3 = ifilter(6+1);
vplus = uplus/(1.0-b1-b2-b3);

unp = x(end)+uplus;
unp1 = x(end-1)+uplus;
unp2 = x(end-2)+uplus;

%		/* anti-causal ifilter */
p1 = N(0+1)*unp+N(1+1)*unp1+N(2+1)*unp2 + vplus;
p2  = N(3+1)*unp+N(4+1)*unp1+N(5+1)*unp2 + vplus;
p3  = N(6+1)*unp+N(7+1)*unp1+N(8+1)*unp2 + vplus;
p1 = p1/sum; p2 = p2/sum; p3 = p3/sum;

for j = n:-1:1
    pix = x(j)/sum;
    u(j) = pix - b1*p1 - b2*p2 - b3*p3;
    p3 = p2; p2 = p1; p1 = pix;
end

%		/* anti-causal ifilter */

%        /* apply Triggs border condition */
b1 = ifilter(2+1); b2 = ifilter(1+1); b3 = ifilter(0+1);


p3 = 0; p2 = 0; p1 = 0;

for j = 1:n
    pix = u(j);
    v(j) = pix - b1*p1 - b2*p2 - b3*p3;
    p3 = p2; p2 = p1; p1 = pix;
end

y = v;










