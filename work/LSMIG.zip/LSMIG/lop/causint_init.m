function causint_init(step1)


global step

step=step1;