%% Comparison between Inverse Laplacian an Gaussian 
close all, clear all,clc
addpath('/geodata10/casasanta/MATLAB/LocalDipFiltering/')
addpath('/geodata10/casasanta/MATLAB/LocalDipFiltering/predict_CLAPP/')

global MAT  MAT1
nz=51;
nx=101;

in = zeros(nz,nx);
in((nz+1)/2,(nx+1)/2) = 1;



sigmaz=2;
sigmax=10;
gauss2D_init(nz,nx,sigmaz,sigmax);
out_gauss = gauss2D_lop(0,nz*nx,nz*nx,in(:));
figure('name','gaussian impulse respons')
imagesc(reshape(out_gauss,nz,nx)/max(out_gauss)); colormap(1-gray),axis image
caxis([0,1])

%% test

lap2D_init(nz,nx);


tmp = zeros(nz*nx,1);
LAP2D = zeros(nz*nx);
for i=1:nz*nx
    tmp(i) = 1;
    LAP2D(:,i) = lap2D_lop(0,nz*nx,nz*nx,tmp(:));
    tmp(i) = 0;
end

Plap = inv(LAP2D);
%%
figure('name','deconvolved laplacian impulse response')
imagesc(-reshape(Plap*in(:),nz,nx)); colormap(1-gray),axis image
%hold on
%contour(-reshape(P*in(:),nz,nx),linspace(0.5,1,11),'k')
caxis([0,1])





%% Helix laplacian
H = zeros(2,7);
h1 = [1.791; - .651; -.044; -0.024]; % helix derivative
h2 = [-.044; -.087;-.200;-.558];
H(1,4:7) = h1;
H(2,1:4) = h2;
Hn=H/1.791;

figure('name','helix derivative impulse response')
[bb,i,lag,pp,SizeIn]=helixSetUp(Hn',in);
out_lap_helix=helidecon(0,bb,numel(bb),lag,in(:),nz*nx);
out_lap_helix=helidecon(1,bb,numel(bb),lag,out_lap_helix(:),nz*nx);
figure, imagesc(reshape(out_lap_helix,nz,nx)/max(out_lap_helix(:)));colormap(1-gray),axis image
caxis([0;1])

%% Helix Steer filter theta=0
w=2; theta=0.0; scale=1;
[bb_dip,i_dip,lag_dip,pp_dip,SizeIn_dip]=helixSetUp(SteerFilter(w,theta,scale),in);
figure('name','helix inverse x-derivative response')
out_derx_helix=helidecon(0,bb_dip,numel(bb_dip),lag_dip,in(:),nz*nx);
out_derx_helix=helidecon(1,bb_dip,numel(bb_dip),lag_dip,out_derx_helix(:),nz*nx);
figure, imagesc(reshape(out_derx_helix,nz,nx)/max(out_derx_helix(:)));colormap(1-gray),axis image
caxis([0;1])
%% test on a simple smoothing procedure using preconditioning
% 
% 0 ~=  d - I * P * p
% 
% 0 ~= mu * I * p
%

mu=1e4;Niter=10;tol=1e-6;
MAT = eye(nx*nz);
MAT1=-Plap;
d = in(:);
[out_lap] = cglsPRECOND( 'aprod' ,mu,d,nz*nx,nz*nx,Niter,tol,1,'aprod1');
% precond laplacian
figure('name','laplacian precond cgls')
out_lap = -Plap*out_lap;
imagesc(reshape(out_lap,nz,nx)/max(out_lap(:))); colormap(1-gray),axis image,  box on,set(gca,'Fontsize',14.0)
caxis([0,1]);
% precond gaussian
[out_gauss] = cglsPRECOND( 'aprod' ,mu,d,nz*nx,nz*nx,Niter,tol,1,'gauss2D_lop');
figure('name','gaussian precond cgls')
out_gauss=gauss2D_lop(0,nz*nx,nz*nx,out_gauss);
imagesc(reshape(out_gauss,nz,nx)/max(out_gauss(:))); colormap(1-gray),axis image,  box on, set(gca,'Fontsize',14.0)
caxis([0,1])
% helix laplacian precond
helixlop_init(bb,lag)
[out_helix] = cglsPRECOND( 'aprod' ,mu,d,nz*nx,nz*nx,Niter,tol,1,'helixlap_lop');
figure('name','helix derivative precond cgls')
out_helix=helixlap_lop(0,nz*nx,nz*nx,out_helix);
imagesc(reshape(out_helix,nz,nx)/max(out_helix(:))); colormap(1-gray),axis image, box on, set(gca,'Fontsize',14.0)
caxis([0,1])

% helix x-derivative precond
helixlop_init(bb_dip,lag_dip)
[out_derx_helix] = cglsPRECOND( 'aprod' ,mu,d,nz*nx,nz*nx,Niter,tol,1,'helixsteer_lop');
figure('name','helix derivative precond cgls')
out_derx_helix=helixsteer_lop(0,nz*nx,nz*nx,out_derx_helix);
imagesc(reshape(out_derx_helix,nz,nx)/max(out_derx_helix(:))); colormap(1-gray),axis image, box on, set(gca,'Fontsize',14.0)
caxis([0,1])



