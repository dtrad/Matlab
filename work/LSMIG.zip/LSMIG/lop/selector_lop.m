function out=selector_lop(adj,nd,nm,in)

global mask nj

if adj
    out = zeros(nm,1);
else
    out = zeros(nd,1);
end
t = 0;
 
    for i = 1:nj
        t = mask(i)*in(i);
        out(i) = out(i) + t;
    end
    
