function y = calcolaDamp( nd,nm,Aname, preconOp)

global MAT

if length(nm) > 1
    N = prod(nm);
else
    N = nm;
end

temp1 = spalloc(nd,N,nnz(MAT)*3);
temp = temp1;
% x = zeros(1,N);
% x(1) = 1;
% temp1(:,1) = feval(Aname,0,nd,0,x);
% for i = 2:nm
%     x(i) = 1;
%     x(i-1) = 0;
%     temp1(:,i) = feval(Aname,0,nd,0,x);
% end

temp1 = MAT;

h = waitbar(0,'Calcola dumping...')
for i = 1:nd
    i
    temp (i,:) = feval(preconOp,0,nm,nm,temp1(i,:));
    waitbar(i/nd,h)
end

y = sqrt(sum(sum(temp.*temp))/N);