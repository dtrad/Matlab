function icaf_1_init(ny,yy,lag1)

global nx_1
global xx_1
global lag_1

lag_1=lag1;
xx_1=yy;
nx_1=ny;