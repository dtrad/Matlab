function [out]=array_2(oper1,oper2,adj,nd1,nd2,nm,in)

% This function constructs an array of two linear operators, computing
% [oper1(mod) ; oper2(mod)] or its adjoint

% N.B. out   = matlab_lop(adj,ndata,nmodel,in);

if (adj)
    out=zeros(nm,1);
else
    out=zeros(nd1+nd2,1);
end



if (adj)
    out=[feval(oper1,1,nd1,nm,in(1:nd1))+...
        feval(oper2,1,nd2,nm,in(nd2+1:nd1+nd2))];
else
    out=[feval(oper1,0,nd1,nm,in);
         feval(oper2,0,nd2,nm,in) ] ;
end
    