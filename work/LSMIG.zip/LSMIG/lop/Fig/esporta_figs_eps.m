% Salva tutte le figure aperte in file emf e eps

% risoluzione indicata dal parametro -rDPI
clear risoluzione
clear formato

risoluzione='-r150';
formato{1}='-depsc2';
% formato{2}='-dmeta';

% Microsoft Windows system device driver options:
%         -dwin      % Send figure to current printer in monochrome
%         -dwinc     % Send figure to current printer in color
%         -dmeta     % Send figure to clipboard (or file) in Metafile format
%         -dbitmap   % Send figure to clipboard (or file) in bitmap format
%         -dsetup    % Bring up Print Setup dialog box, but do not print
%         -v         % Verbose mode, bring up the Print dialog box
%                      which is normally suppressed.
%  
%       Built-in MATLAB Drivers:
%         -dps       % PostScript for black and white printers
%         -dpsc      % PostScript for color printers
%         -dps2      % Level 2 PostScript for black and white printers
%         -dpsc2     % Level 2 PostScript for color printers
%  
%         -deps      % Encapsulated PostScript
%         -depsc     % Encapsulated Color PostScript
%         -deps2     % Encapsulated Level 2 PostScript
%         -depsc2    % Encapsulated Level 2 Color PostScript
%  
%         -dhpgl     % HPGL compatible with Hewlett-Packard 7475A plotter
%         -dill      % Adobe Illustrator 88 compatible illustration file
%         -djpeg<nn> % JPEG image, quality level of nn (figures only)
%                      E.g., -djpeg90 gives a quality level of 90.
%                      Quality level defaults to 75 if nn is omitted.
%         -dtiff     % TIFF with packbits (lossless run-length encoding)
%                      compression (figures only)
%         -dtiffnocompression % TIFF without compression (figures only)
%         -dpng      % Portable Network Graphic 24-bit truecolor image
%                      (figures only)

% fine variabili
figure_aperte=get(0,'Children');


for j=1:length(figure_aperte)
    nome_finestra=get(figure_aperte(j),'Name');
    nome_finestra=strrep(nome_finestra,'.','_');
    
    % Se la finestra non ha campo Name
    if strcmp(nome_finestra,'') 
        nome_finestra=['nonamefig_',num2str(j)];
    end
    
    titolo_file=nome_finestra;
    % titolo_file=nome_finestra;
    saveas(figure_aperte(j),titolo_file, 'fig');
    for k=1:length(formato)
        print(figure_aperte(j),formato{k},risoluzione,titolo_file);
    end
end

clear risoluzione
clear formato
clear figure_aperte
clear nome_finestra
clear titolo_file

