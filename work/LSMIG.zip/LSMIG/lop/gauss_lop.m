function y = gauss_lop(filter, M, n, x)


x = check1(n, 1, x);

sum = filter(3+1);

u = zeros(n, 1);
y = u;

%		/* causal filter */
b1 = filter(2+1); b2 = filter(1+1); b3 = filter(0+1);
p1 = x(1)/(1.0-b1-b2-b3); p2 = p1; p3 = p1;

iplus = x(n);
for j = 1:n
    pix = x(j) + b1*p1 + b2*p2 + b3*p3;
    u(j) = pix;
    p3 = p2; p2 = p1; p1 = pix;
end

%		/* anti-causal filter */

%        /* apply Triggs border condition */
uplus = iplus/(1.0-b1-b2-b3);
b1 = filter(4+1); b2 = filter(5+1); b3 = filter(6+1);
vplus = uplus/(1.0-b1-b2-b3);

unp = p1-uplus;
unp1 = p2-uplus;
unp2 = p3-uplus;

pix = M(0+1)*unp+M(1+1)*unp1+M(2+1)*unp2 + vplus;
p1  = M(3+1)*unp+M(4+1)*unp1+M(5+1)*unp2 + vplus;
p2  = M(6+1)*unp+M(7+1)*unp1+M(8+1)*unp2 + vplus;
pix = pix*(sum); p1 = p1*sum; p2 = p2*sum;

y(n) = pix;
p3 = p2; p2 = p1; p1 = pix;

for j = n-1:-1:1
    pix = sum * u(j) + b1*p1 + b2*p2 + b3*p3;
    y(j) = pix;
    p3 = p2; p2 = p1; p1 = pix;
end