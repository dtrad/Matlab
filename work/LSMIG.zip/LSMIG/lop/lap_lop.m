function y = lap_lop(nx, x)

y = zeros(nx,1);

for i=1:nx
   if i==1
       y(i) = -1*x(i) + 1*x(i+1);
   elseif i==nx
            y(i) = -1*x(i) + 1*x(i-1);
   else
       y(i) = x(i-1) - 2 *x(i) + x(i+1);
   end
end