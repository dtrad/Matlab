function out=causint1(adj,ndata,nmodel,in)

global step

if adj
    out=zeros(nmodel,1); 
else    
    out=zeros(ndata,1);
end

t=0;
if adj
    
    for i=nmodel:-1:1
        t = t+step*in(i);
        out(i)=out(i)+t;
    end
    
else
    for i=1:nmodel
        t = t+step*in(i);
        out(i) = out(i)+t;
    end
    
end

