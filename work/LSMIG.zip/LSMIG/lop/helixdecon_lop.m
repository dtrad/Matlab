function y = helixdecon_lop(adj,nd,nm,x)

global flt lag_flt

if adj
    y=helidecon(1,flt,numel(flt),lag_flt,x(:),nd);
else
    y=helidecon(0,flt,numel(flt),lag_flt,x(:),nm);
end