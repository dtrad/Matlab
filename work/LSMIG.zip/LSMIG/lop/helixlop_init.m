function helixdecon_init(bb,lag)

global flt lag_flt

flt=bb;
lag_flt=lag;