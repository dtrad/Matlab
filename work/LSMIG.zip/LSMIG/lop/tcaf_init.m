function tcaf_init(ny,yy)

global nx
global xx

xx=yy;
nx=ny;