function igauss3D_init(varargin)

global ifilter1 N1 ifilter2 N2 ifilter3 N3 n1 n2 n3

n1=varargin{1};
n2=varargin{2};
n3=varargin{3};

sigma1 = varargin{4};
[ifilter1, N1] = igauss_init(sigma1);
if nargin == 1
    N2 = N1;
    ifilter2 = ifilter1;
    N3 = N1;
    ifilter3 = ifilter1;
elseif nargin==2
    sigma2 = varargin{5};
    [ifilter2, N2] = igauss_init(sigma2);
    N3 = N2;
    ifilter3 = ifilter2;
else
    sigma2 = varargin{5};
    [ifilter2, N2] = igauss_init(sigma2);
    sigma3 = varargin{6};
    [ifilter3, N3] = igauss_init(sigma3);

end