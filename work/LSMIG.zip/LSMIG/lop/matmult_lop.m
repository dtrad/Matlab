function out=matmult_lop(adj,nd,nm,in)

global A

if adj
    out=zeros(nm,1);
else
    out=zeros(md,1);
end


if adj
    out=A'*in;
else
    out=A*in;
end