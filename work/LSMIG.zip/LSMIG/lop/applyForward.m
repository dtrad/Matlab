function [y,u] = applyForward(in, sigma)

sx = size(in, 2);
sy = size(in, 1);

y = zeros(size(in));


%	/* initial values */
m0 = 1.16680; m1 = 1.10783; m2 = 1.40586;
m1sq = m1*m1; m2sq = m2*m2;


%    /* calculate q */
if(sigma < 3.556)
    q = -0.2568 + 0.5784 * sigma + 0.0561 * sigma * sigma;
else
    q = 2.5091 + 0.9804 * (sigma - 3.556);
end
qsq = q*q;

%	/* calculate scale, and b(0,1,2,3+1) */
scale = (m0 + q) * (m1sq + m2sq + 2*m1*q + qsq);
b1 = -q * (2*m0*m1 + m1sq + m2sq + (2*m0 + 4*m1) * q + 3*qsq) / scale;
b2 = qsq * (m0 + 2*m1 + 3*q) / scale;
b3 = - qsq * q / scale;

%	/* calculate B */
B = (m0 * (m1sq + m2sq))/scale;

%	/* fill in filter */
filter(0+1) = -b3;
filter(1+1) = -b2;
filter(2+1) = -b1;
filter(3+1) = B;
filter(4+1) = -b1;
filter(5+1) = -b2;
filter(6+1) = -b3;

a3 = filter(0+1);
a2 = filter(1+1);
a1 = filter(2+1);

scale = 1.0/((1.0+a1-a2+a3)*(1.0-a1-a2-a3)*(1.0+a2+(a1-a3)*a3));
M(0+1) = scale*(-a3*a1+1.0-a3*a3-a2);
M(1+1) = scale*(a3+a1)*(a2+a3*a1);
M(2+1) = scale*a3*(a1+a3*a2);
M(3+1) = scale*(a1+a3*a2);
M(4+1) = -scale*(a2-1.0)*(a2+a3*a1);
M(5+1) = -scale*a3*(a3*a1+a3*a3+a2-1.0);
M(6+1) = scale*(a3*a1+a2+a1*a1-a2*a2);
M(7+1) = scale*(a1*a2+a3*a2*a2-a1*a3*a3-a3*a3*a3-a3*a2+a3);
M(8+1) = scale*a3*(a1+a3*a2);

sumsq = filter(3+1);
sum = sumsq*sumsq;

for i = 1:sy
    x = in(i,:);
u = zeros(1, sx);
v = u;



%		/* causal filter */
b1 = filter(2+1); b2 = filter(1+1); b3 = filter(0+1);
p1 = 0; p2 = p1; p3 = p1;

iplus = 0;
for j = 1:sx
    pix = x(j) + b1*p1 + b2*p2 + b3*p3;
    u(j) = pix;
    p3 = p2; p2 = p1; p1 = pix;
end

%		/* anti-causal filter */

%        /* apply Triggs border condition */
uplus = iplus/(1.0-b1-b2-b3);
b1 = filter(4+1); b2 = filter(5+1); b3 = filter(6+1);
vplus = uplus/(1.0-b1-b2-b3);

unp = p1-uplus;
unp1 = p2-uplus;
unp2 = p3-uplus;

pix = M(0+1)*unp+M(1+1)*unp1+M(2+1)*unp2 + vplus;
p1  = M(3+1)*unp+M(4+1)*unp1+M(5+1)*unp2 + vplus;
p2  = M(6+1)*unp+M(7+1)*unp1+M(8+1)*unp2 + vplus;
pix = pix*sum; p1 = p1*sum; p2 = p2*sum;

v(sx) = pix;
p3 = p2; p2 = p1; p1 = pix;

for j = sx-1:-1:1
    pix = sum * u(j) + b1*p1 + b2*p2 + b3*p3;
    v(j) = pix;
    p3 = p2; p2 = p1; p1 = pix;
end

y(i,:) = v;
end
