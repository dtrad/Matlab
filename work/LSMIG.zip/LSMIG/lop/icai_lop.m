%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=icai_lop(adj,ny,nx,in)

global nb bb lag

if adj
    out=zeros(nx,1);
else
    out=zeros(ny,1);
end 

 
for b=0:nb-1
	for y=nb:ny
           x = y-b-1;
	    if( adj) 
            out(x+1) = out(x+1) + in (y-lag+1) * conj( bb(b+1));
        else
            out(y-lag+1) = out(y-lag+1) + in (x+1) *( bb(b+1));

        end
    end
   end
    
end