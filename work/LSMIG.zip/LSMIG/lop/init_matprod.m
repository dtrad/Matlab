function init_matprod(A1)

global matrix

matrix=A;

