function causint1_init(step1)


global step

step=step1;