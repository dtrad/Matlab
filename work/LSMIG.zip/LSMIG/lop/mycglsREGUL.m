function [x,resVec,numeroIter]=mycglsREGUL(Aname,mu,d,dreg,n,m,tol,maxiter,prnt,Rname)
%
%   [x,r,G]=mycgls(A,d,tol,maxiter)
%
%   INPUT:
%       A: system matrix
%       d: data
%       tol: tollerance
%       maxiter: maximum number of iterations
%   OUTPUT:
%       x: solution
%       resVec: residual norm vector
%       G: orthogonal basis for model resolution matrix estimation
%

% Check matrix and vector dimensions


%check for vector dimensions
dataLength=length(d);
if ne(dataLength,n)
    disp('Vector and matrix dimensions must agree');
    return
end



x=zeros(m,1);
s = d; %  if x!= 0 s = d - A*x;
sreg=dreg;
% Data norm (it will be used in stopping criterion)
ATd=feval(Aname,1,n,m,d)+sqrt(mu)*feval(Rname,1,m,m,dreg); %ATd = A'd;
normd=norm(ATd)^2;

r = feval(Aname,1,n,m,s)+sqrt(mu)*feval(Rname,1,m,m,sreg);     % r = A'*s
p=r;
q   =feval(Aname,0,n,m,p);    %q = A*p;
qreg=sqrt(mu)*feval(Rname,0,m,m,p);
resVec=zeros(1,maxiter);
resVec(1)=norm(r);
norms0 = norm(s);
%G=[];
%Rm=zeros(length(x),3);

if prnt
      head = '    k       x(1)             x(n)           normx        resNE';
      form = '%5.0f %16.10g %16.10g %9.2g %12.5g';
      disp('  ');   disp(head);
      disp( sprintf(form,0,x(1),x(m),norm(x),1) )
end

for i=1:maxiter
    
    %G=[G p];
    %Rm(:,1)=Rm(:,1)+(r.*r)/(r'*r);
    %Rm(1:end-1,2)=Rm(1:end-1,2)+(r(1:end-1).*r(2:end))/(r'*r);
    %Rm(1:end-2,3)=Rm(1:end-2,3)+(r(1:end-2).*r(3:end))/(r'*r);

    alfa=(r'*r)/([q;qreg]'*[q;qreg]);
    x = x + alfa*p;
    s    = s    - alfa*q;
    sreg = sreg - alfa*qreg;
    
    k=r'*r;
    %r=A'*s;
    r = feval(Aname,1,n,m,s)+sqrt(mu)*feval(Rname,1,m,m,sreg);     % r = A'*s
    % Residual norm
    normr=norm(r-ATd)^2;
    
    b=(r'*r)/k;
    p=r+b*p;
    %q=A*p;
    q   =feval(Aname,0,n,m,p);    %q = A*p;
    qreg=sqrt(mu)*feval(Rname,0,m,m,p);
    % Stopping criterion test
    if normd>1e-20
        normRes = normr/normd;
    else
        normRes = normr;
    end
    
   if  normRes<tol || norm(r)<1e-20
       disp('Norm of the residual is smaller than tollerance');
       break;
   end
    if prnt, disp( sprintf(form, i,x(1),x(m),norm(x),norm(s)/norms0) ); end
    %if (i>1 && normRes>oldNormRes)
    %    disp('Norm of the residual is increasing');
    %end
    
    
    resVec(i)=norm(r);
  
end

numeroIter=i;
%nomeMatFile=strcat('Rm',num2str(maxiter));
%save(nomeMatFile,'Rm');
