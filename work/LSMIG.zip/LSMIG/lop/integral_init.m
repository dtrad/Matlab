function integral_init(m)
global MAT1
a = zeros(m,1);a(end) = 1;a(1)=-1;
b = ones(m-1,1);

grad =  diag(a,0)-diag(b,-1)+diag(b,1);
grad(1,:) = grad(1,:);
grad(end,:) = grad(end,:);
grad(2:end-1,:) = grad(2:end-1,:)/2;

MAT1=pinv(grad);