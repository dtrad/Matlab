function gauss3D_init(varargin)

global filter1 M1 filter2 M2 filter3 M3 n1 n2 n3

n1=varargin{1};
n2=varargin{2};
n3=varargin{3};

sigma1 = varargin{4};
[filter1, M1] = gauss_init(sigma1);
if nargin == 1
    M2 = M1;
    filter2 = filter1;
    M3 = M1;
    filter3 = filter1;
elseif nargin==2
    sigma2 = varargin{5};
    [filter2, M2] = gauss_init(sigma2);
    M3 = M2;
    filter3 = filter2;
else
    sigma2 = varargin{5};
    [filter2, M2] = gauss_init(sigma2);
    sigma3 = varargin{6};
    [filter3, M3] = gauss_init(sigma3);

end