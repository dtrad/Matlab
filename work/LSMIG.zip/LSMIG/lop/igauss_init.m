function [ifilter, N] = igauss_init(sigma)

%   /* memory allocation */
ifilter = zeros(1,7);
N = zeros(1,9);

%	/* initial values */
m0 = 1.16680; m1 = 1.10783; m2 = 1.40586;
m1sq = m1*m1; m2sq = m2*m2;


%    /* calculate q */
if(sigma < 3.556)
    q = -0.2568 + 0.5784 * sigma + 0.0561 * sigma * sigma;
else
    q = 2.5091 + 0.9804 * (sigma - 3.556);
end
qsq = q*q;

%	/* calculate scale, and b(0,1,2,3+1) */
scale = (m0 + q) * (m1sq + m2sq + 2*m1*q + qsq);
b1 = -q * (2*m0*m1 + m1sq + m2sq + (2*m0 + 4*m1) * q + 3*qsq) / scale;
b2 = qsq * (m0 + 2*m1 + 3*q) / scale;
b3 = - qsq * q / scale;

%	/* calculate B */
B = ((m0 * (m1sq + m2sq))/scale)^2;

%	/* fill in filter */
ifilter(0+1) = -b3;
ifilter(1+1) = -b2;
ifilter(2+1) = -b1;
ifilter(3+1) = B;
ifilter(4+1) = -b1;
ifilter(5+1) = -b2;
ifilter(6+1) = -b3;

a3 = ifilter(0+1);
a2 = ifilter(1+1);
a1 = ifilter(2+1);



N(1) = a1;
N(2) = a2;
N(3) = a3;
N(4) = a2+a1^2;
N(5) =  a1*a2+a3;
N(6) = a3*a1;
N(7) = a3+2*a1*a2+a1^3;
N(8) = a2^2+a1^2*a2+a3*a1;
N(9) = a3*(a2+a1^2);