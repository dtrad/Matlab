%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=icai_1_lop(adj,ny,nx,in)

global nb1 bb1 lag1 

if adj
    out=zeros(nx,1);
else
    out=zeros(ny,1);
end 


 
for b=0:nb1-1
	for y=nb1:ny
            x = y-b-1;
	    if( adj) 
            out(x+1) = out(x+1) + in (y-lag1+1) * conj( bb1(b+1));
        else
        
            out(y-lag1+1) = out(y-lag1+1) + in (x+1) * ( bb1(b+1));

        end
    end
   end
    
end