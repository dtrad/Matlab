function y = lap2D_lop(adj,nd,nm,x)

global n1 n2

 

y = zeros(nd,1);

for i = 1:n1*n2
   if i==1 % i, i+1 i+n1 
        y(i) = -4*x(i) +1 *x(i+1) + 1* x(i+n1);
   elseif i==n1*n2 % i, i-1 i-n1 
       y(i)  = -4*x(i) +1* x(i-1) + 1* x(i-n1);
   elseif i==n1 % i, i-1 , i+n1
        y(i) = -4*x(i) +1 *x(i-1) + 1* x(i+n1);
   elseif i==(n1-1)*n2 % i, i+1, i-n1
        y(i) = -4*x(i) +1 *x(i+1) + 1* x(i-n1);
%    elseif i>1 && i<n1  
%          y(i) = 0*x(i-1) +1 * x(i) + 0*x(i+1) + 1* x(i+n1); 
%    elseif i>(n1-1)*n2 && i<n1*n2
%          y(i) = 0*x(i-1) +1 * x(i) + 0*x(i+1) + 1* x(i-n1);     
%    elseif i~=1  && i~=(n1-1)*n2 && ~mod(i,n1+1)
%            y(i) = 0*x(i-n1) +1 * x(i) + 1*x(i+1) + 1* x(i+n1);  
%    elseif i~=n1  && i~=n1*n2 && ~mod(i,n1)
%            y(i) = 0*x(i-n1) +1 * x(i) + 1*x(i-1) + 1* x(i+n1);  
        
   else
       y(i) = 1 *x(i-1) - 4 *x(i) + x(i+1) ;
       if (i+n1)<=n1*n2
           y(i) = y(i) + x(i+n1);
       end
       
       if (i-n1)>=1
           y(i) = y(i) + x(i-n1);
       end
       
   end

end

y=y(:);