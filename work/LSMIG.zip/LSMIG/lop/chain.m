function [out]=chain(oper1,oper2,adj,nd,nm,ntmp,in)

% This function constructs an array of two linear operators, computing
% [oper1(mod) ; oper2(mod)] or its adjoint

% N.B. out   = matlab_lop(adj,ndata,nmodel,in);

if (adj)
    out=zeros(ntmp,1);
else
    out=zeros(nd,1);
end



if (adj)
    tmp=feval(oper1,1,nd,ntmp,in); % adj means data as input 
    out=feval(oper2,1,ntmp,nm,tmp);
else
    tmp=feval(oper2,0,ntmp,nm,in);
    out=feval(oper1,0,nd,ntmp,tmp) ; 
end
    