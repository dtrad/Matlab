function icai_init(nb_1,b_1,lag_1)

global nb bb lag

nb=nb_1;
bb=b_1;
lag=lag_1;