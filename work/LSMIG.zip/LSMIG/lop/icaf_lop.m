%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=icaf_lop(adj,ny,nb,in)

global lag xx nx

if adj
    out=zeros(nb,1);
else
    out=zeros(ny,1);
end 

if(not(nx==ny)) 
    fprintf('__ERROR__: size problem: %d != %d',ny,nx);
    return
end


for b=0:nb-1
    for y=nb:ny

        x = y - b - 1;
        if( adj)
            out(b+1) = out(b+1) ...
                    + ( in(y-lag+1) * conj(xx(x+1)) );

        else

            out(y-lag+1) = out(y-lag+1)...
                    +( in(b+1) * xx(x+1) );
        end
    end
end