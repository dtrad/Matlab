function dotTest1(opName, m, n)

x = randn(n, 1);
y = randn(m, 1);

v = feval( opName, 0, m, n, x);
z = feval( opName, 1, m, n, y);

v = y' * v;
z = x' * z;

if abs(v-z)/abs(v)> 1e-4
    abs(v-z)/abs(v)
    disp('dot Test failure')
else
    disp('dot Test success')
end