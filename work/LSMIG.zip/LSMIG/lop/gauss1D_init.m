function gauss1D_init(varargin)

global filter1 M1 n1 n2

n1=varargin{1};
n2=varargin{2};
sigma=varargin{3};

[filter1, M1] = gauss_init(sigma);