function icai_1_init(nb_1,b_1,lag_1)

global nb1 bb1 lag1

nb1=nb_1;
bb1=b_1;
lag1=lag_1;