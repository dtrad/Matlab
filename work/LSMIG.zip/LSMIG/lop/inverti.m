path = '/geoscratch/giboli/arpoc_turning';
addpath('/geoscratch/giboli/lsqr/test1D');
cd(path);
figPath = sprintf('%s/FIG/esperimento4/',path);

prnt = 0;
tol = 1e-100;
shift = 0.001;

atol   = 1.0e-10;
btol   = 1.0e-10;
conlim = 1.0e+10;
show   = .1;
damp = 2;
Aname = 'Aprod';
preconOp = 'gauss2D_lop';

gauss2D_init(2,5);
damp = damp*calcolaDamp(20000,[N(1) N(3)],Aname,preconOp);
shift = damp^2;

%%

[ z, istop, itn, r1norm, r2norm, anorm, acond, arnorm, xnorm, var ] =  ...
    lsqr( 20000, [N(1) N(3)], Aname, dati, damp, atol, btol, conlim, 50, show, preconOp );

x_prec=feval(preconOp,[N(1) N(3)],z);

x_prec = reshape(x_prec,N(1),N(3));
%visualizza risultato finale


cax = [1500 6675];

figure;
set(gcf,'Name','Preconditioning: final model');
data = interp2(1./(squeeze(1./Vp0_(:,1,:))+x_prec));
asseZ=linspace(o(1),o(1)+(n(1)-1)*d(1),size(data,1));
asseX=linspace(o(3),o(3)+(n(3)-1)*d(3),size(data,2));
imagesc(asseX,asseZ,data);
hold on
[asseX,asseZ] = meshgrid(asseX,asseZ);
[C,h] = contour(asseX,asseZ,data,'--k','linewidth',1);
clabel(C,h,'FontSize',15,'Color','k','Rotation',0)
set(gca,'ydir','rev');
caxis(cax);
xlabel('horizontal [m]');
ylabel('depth [m]');
figName = 'PreconModel';
saveas(gcf, sprintf('%s%s',figPath,figName), 'fig')


figure;
set(gcf,'Name','True model');
data = squeeze(Vp(:,1,:));
asseZ=linspace(o(1),o(1)+(n(1)-1)*d(1),size(data,1));
asseX=linspace(o(3),o(3)+(n(3)-1)*d(3),size(data,2));
imagesc(asseX,asseZ,data);
hold on
[asseX,asseZ] = meshgrid(asseX,asseZ);
[C,h] = contour(asseX,asseZ,data,'--k','linewidth',1);
clabel(C,h,'FontSize',15,'Color','k','Rotation',0)
set(gca,'ydir','rev');
caxis(cax);
xlabel('horizontal [m]');
ylabel('depth [m]');
figName = 'TrueModel';
saveas(gcf, sprintf('%s%s',figPath,figName), 'fig')

figure;
set(gcf,'Name','starting Model');
data = squeeze(Vp0(:,1,:));
asseZ=linspace(o(1),o(1)+(n(1)-1)*d(1),size(data,1));
asseX=linspace(o(3),o(3)+(n(3)-1)*d(3),size(data,2));
imagesc(asseX,asseZ,data);
hold on
[asseX,asseZ] = meshgrid(asseX,asseZ);
[C,h] = contour(asseX,asseZ,data,'--k','linewidth',1);
clabel(C,h,'FontSize',15,'Color','k','Rotation',0)
set(gca,'ydir','rev');
caxis(cax);
xlabel('horizontal [m]');
ylabel('depth [m]');
figName = 'StartModel';
saveas(gcf, sprintf('%s%s',figPath,figName), 'fig')
