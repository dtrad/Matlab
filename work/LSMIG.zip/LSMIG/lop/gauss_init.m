function [filter, M] = gauss_init(sigma)

%   /* memory allocation */
filter = zeros(1,7);
M = zeros(1,9);

%	/* initial values */
m0 = 1.16680; m1 = 1.10783; m2 = 1.40586;
m1sq = m1*m1; m2sq = m2*m2;


%    /* calculate q */
if(sigma < 3.556)
    q = -0.2568 + 0.5784 * sigma + 0.0561 * sigma * sigma;
else
    q = 2.5091 + 0.9804 * (sigma - 3.556);
end
qsq = q*q;

%	/* calculate scale, and b(0,1,2,3+1) */
scale = (m0 + q) * (m1sq + m2sq + 2*m1*q + qsq);
b1 = -q * (2*m0*m1 + m1sq + m2sq + (2*m0 + 4*m1) * q + 3*qsq) / scale;
b2 = qsq * (m0 + 2*m1 + 3*q) / scale;
b3 = - qsq * q / scale;

%	/* calculate B */
B = ((m0 * (m1sq + m2sq))/scale)^2;

%	/* fill in filter */
filter(0+1) = -b3;
filter(1+1) = -b2;
filter(2+1) = -b1;
filter(3+1) = B;
filter(4+1) = -b1;
filter(5+1) = -b2;
filter(6+1) = -b3;

a3 = filter(0+1);
a2 = filter(1+1);
a1 = filter(2+1);

scale = 1.0/((1.0+a1-a2+a3)*(1.0-a1-a2-a3)*(1.0+a2+(a1-a3)*a3));
M(0+1) = scale*(-a3*a1+1.0-a3*a3-a2);
M(1+1) = scale*(a3+a1)*(a2+a3*a1);
M(2+1) = scale*a3*(a1+a3*a2);
M(3+1) = scale*(a1+a3*a2);
M(4+1) = -scale*(a2-1.0)*(a2+a3*a1);
M(5+1) = -scale*a3*(a3*a1+a3*a3+a2-1.0);
M(6+1) = scale*(a3*a1+a2+a1*a1-a2*a2);
M(7+1) = scale*(a1*a2+a3*a2*a2-a1*a3*a3-a3*a3*a3-a3*a2+a3);
M(8+1) = scale*a3*(a1+a3*a2);