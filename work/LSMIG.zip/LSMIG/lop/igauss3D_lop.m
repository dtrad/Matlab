function y = igauss3D_lop(adj,nd,nm,x)
%function y = gauss3D_lop(m, x)

global N1 ifilter1 N2 ifilter2 N3 ifilter3 n1 n2 n3

 %[a, b] = size(x);

temp = zeros(nd,1);
y = temp;


% n1 filtraggio gaussiano lungo la dimensione piu veloce
% for i2 = 1:n2 % IL loop
%     for i3=1:n3 % XL lopp
%     indici = n1*(i2-1)+n1*n2*(i3-1)+1:n1*(i2)+n1*n2*(i3-1);
%     in = x(indici);
%     temp(indici) = gauss_lop(filter1, M1, m(1), in);
%     end
% end
for i = 1:n2*n3 % IL+XL loop  
    indici = n1*(i-1)+1:n1*i;
    in = x(indici);
    temp(indici) = igauss_lop(ifilter1, N1, n1, in);
    
end

%n2 
for i1 = 1:n1 % depth loop
    for i3=1:n3 % XL lopp
    
    indici = (i1-1)+n1*n2*(i3-1)+1:n1:(i1-1)+n1*n2*(i3-1)+n1*(n2-1)+1;
    in = temp(indici);
    temp(indici) = igauss_lop(ifilter2, N2, n2, in);

    end
end


%n3

for i1 = 1:n1 % depth loop
    for i2=1:n2 % IL loop
    
    indici = (i1-1)+n1*(i2-1)+1:n1*n2:(i1-1)+n1*(i2-1)+n1*n2*(n3-1)+1;
    in = temp(indici);
    y(indici) = igauss_lop(ifilter3, N3, n3, in);

    end
end