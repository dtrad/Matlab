function y = helixsteer_lop(adj,nd,nm,x)

global flt lag_flt

if adj
    y=helidecon(1,flt,numel(flt),lag_flt,x(:),nd);
%    y = helidecon(0,flt,numel(flt),lag_flt,y(:),nm);
else
    y=helidecon(0,flt,numel(flt),lag_flt,x(:),nm);
%    y = helidecon(1,flt,numel(flt),lag_flt,y(:),nd);
end