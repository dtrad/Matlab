function gauss3D_oriented_init(varargin)

global filter3 M3 n1 n2 n3 sigma1 sigma2

n1=varargin{1};
n2=varargin{2};
n3=varargin{3};

sigma1 = varargin{4};
sigma2 = varargin{5};
sigma3 = varargin{6};
[filter3, M3] = gauss_init(sigma3);
  
