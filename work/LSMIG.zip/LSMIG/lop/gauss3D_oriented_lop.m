function y = gauss3D_oriented_lop(adj,nd,nm,x)
%function y = gauss3D_lop(m, x)

global filter3 n1 n2 n3

 %[a, b] = size(x);

temp = zeros(nd,1);
y = temp;


% n1 filtraggio gaussiano lungo la dimensione piu veloce
% for i2 = 1:n2 % IL loop
%     for i3=1:n3 % XL lopp
%     indici = n1*(i2-1)+n1*n2*(i3-1)+1:n1*(i2)+n1*n2*(i3-1);
%     in = x(indici);
%     temp(indici) = gauss_lop(filter1, M1, m(1), in);
%     end
% end
for i = 1:n2*n3 % IL+XL loop  
    indici = n1*(i-1)+1:n1*i;
    in = x(indici);
    temp(indici) = gauss_lop(filter1, M1, n1, in);
    
end

%n2 
for i1 = 1:n1 % depth loop
    for i3=1:n3 % XL lopp
    
    indici = (i1-1)+n1*n2*(i3-1)+1:n1:(i1-1)+n1*n2*(i3-1)+n1*(n2-1)+1;
    in = temp(indici);
    temp(indici) = gauss_lop(filter2, M2, n2, in);

    end
end


%n3

for i1 = 1:n1 % depth loop
    for i2=1:n2 % IL loop
    
    indici = (i1-1)+n1*(i2-1)+1:n1*n2:(i1-1)+n1*(i2-1)+n1*n2*(n3-1)+1;
    in = temp(indici);
    y(indici) = gauss_lop(filter3, M3, n3, in);

    end
end
y=y(:);