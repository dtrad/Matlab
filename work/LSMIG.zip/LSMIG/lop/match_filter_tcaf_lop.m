%function   out   = matlab_lop(adj,ndata,nmodel,in);
function  out = match_filter_tcaf_lop(adj,nd,nm,in)

global nt nw M 




if adj
   out=zeros(nm,1);
else
   out=zeros(nd,1);
end


if nd< (nt+nm-1)*nw
    fprintf('__ERROR__: size problem: %d != %d',nd,nt*nw);
    return
end




for iw=1:nw

   
   
    tcaf_init(nt, M( (iw-1)*nt+1:iw*nt ) );
    
    if adj
        out=out+tcaf_lop(1,nt+nm-1,nm, in( (iw-1)*(nt+nm-1) +1:iw*(nt+nm-1) ) );
       
    else
        out(   (iw-1)*(nt+nm-1)+1:iw*(nt+nm-1)  ) = tcaf_lop(0,nt+nm-1, nm, in );
    end
    
    
end