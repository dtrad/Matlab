function y = check1(m, n, x)

[a, b] = size(x);
if a ~= 1 && b ~=1
    error('Error: x is not a vector')
end
if a*b~=m*n
    error('Error: input parameters not matching size of vector x')
end
if m == 1
    y = x';
else
    y = x;
end