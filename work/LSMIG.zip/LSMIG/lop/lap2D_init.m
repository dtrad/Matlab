function lap2D_init(varargin)

global n1 n2 

n1=varargin{1};
n2=varargin{2};
