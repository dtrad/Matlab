function out=matprod_lop(adj,nd,nm,in)

global matrix

if adj
    out=zeros(nm,1);
else
    out=zeros(md,1);
end


if adj
    out=matrix'*in;
else
    out=matrix*in;
end