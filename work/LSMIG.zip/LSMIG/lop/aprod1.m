function y = aprod1( mode, m, n, x)
%        y = aprod( mode, m, n, x)
%
%  if mode = 0, aprod computes y = A*x
%  if mode = 1, aprod computes y = A'*x
%  for some matrix  A.
%
%  This is the simplest example for testing  LSQR.
%  A = rw.
global MAT1


if mode == 0,
   y = MAT1*x;
else
   y = MAT1'*x;
end
