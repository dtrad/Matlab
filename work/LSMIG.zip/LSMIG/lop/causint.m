function y = causint(adj, nm, nd, in)

global step

if adj
y = zeros(nm,1);
else
    y = zeros(nd,1);
end
t = 0;
if (adj)
    for i = nm:-1:1

        t = t+step*in(i);
        
        y(i) = y(i) + t;

    end
else
    for i = 1:nd

        t = t +step* in(i);
        
        y(i) = y(i) + t;

    end
end