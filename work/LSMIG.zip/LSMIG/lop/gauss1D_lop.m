function y = gauss1D_lop(adj,nd,nm, x)
% filtraggio gaussiano ricorsivo 1D
% se x � una matrice filtra 1D per colonne
global M1 filter1 n1 n2


temp = zeros(nd,1);



for i = 1:n2
    indici = (i-1)*n1+1:i*n1;
    in = x(indici);
    temp(indici) = gauss_lop(filter1, M1, n1, in);
end

y = temp;