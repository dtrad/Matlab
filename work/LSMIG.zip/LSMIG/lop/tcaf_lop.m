%function   out   = matlab_lop(adj,ndata,nmodel,in);
function out=tcaf_lop(adj,ny,nb,in)

global xx nx

if adj
    out=zeros(nb,1);
else
    out=zeros(ny,1);
end 

if ny < nx+nb-1 
    fprintf('__ERROR__tcaf_lop: size problem: %d != %d',ny,nx+nb-1 );
    return
end

 
for b=0:nb-1
    for x=0:nx-1

       y= x + b;
        if( adj)
            out(b+1) = out(b+1) ...
                    + ( in(y+1) * conj(xx(x+1)) );

        else

            out(y+1) = out(y+1)...
                    +( in(b+1) * xx(x+1) );
        end
    end
end