%function   out   = matlab_lop(adj,ndata,nmodel,in);
function  out = match_filter_lop(adj,nd,nm,in)

global nt nw M




if adj
   out=zeros(nm,1);
else
   out=zeros(nd,1);
end


if(not(nd==nt*nw)) 
    fprintf('__ERROR__: size problem: %d != %d',nd,nt*nw);
    return
end




for iw=1:nw

   
   
    icaf_init(nt, M( (iw-1)*nt+1:iw*nt ), 1 );
    
    if adj
        out=out+icaf_lop(1,nt,nm, in( (iw-1)*nt+1:iw*nt ) );
       
    else
        out((iw-1)*nt+1:iw*nt ) = icaf_lop(0,nt, nm, in );
    end
    
    
end