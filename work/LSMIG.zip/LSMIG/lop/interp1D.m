function y = interp1D(adj, nm, nd, in)

global coord o1 d1

if adj
y = zeros(nm,1);
else
    y = zeros(nd,1);
end

for id=1:nd
    f = (coord(id)-o1)/d1;
    im=floor(f)+1;
    if (1 <= im && im < nm)
        fx=f+1-im;
        gx=1.-fx;

        if(adj)
            y(im)   =  y(im) + gx * in(id);
            y(im+1) =  y(im+1) + fx * in(id);
        else
            y(id)   = y(id) + gx * in(im)  +  fx * in(im+1);
        end
    end
end
