function [A] = qabs(a1,a2,a3,a4)

% following the rules for quaternion algebra;
A = (a1.^2 + a2.^2 + a3.^2 + a4.^2).^0.5;

return;
