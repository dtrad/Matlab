function [Z1,Z2,Z3,Z4] = quaternion_fftn(X1,X2,X3,X4,LorR)
tic
S = 1;
if LorR == 'R'
    S = -1;  % S used to conj one of the complex components below when the exponential is on the right.
end

% B_fw = [ 5.773502691896258e-01,  5.773502691896258e-01,  5.773502691896258e-01;...
%          0,                      7.071067811865476e-01, -7.071067811865476e-01;...
%          8.164965809277261e-01, -4.082482904638631e-01, -4.082482904638631e-01];

% create an orthonormal basis:
    %  first row: [1/sqrt(3)  1/sqrt(3)   1/sqrt(3)  ]
    % second row: [   0       1/sqrt(2)  -1/sqrt(2)  ] (orthogonal to the first)
    %  third row: [          - row1 X row2           ] (orthogonal to the first two by definition)
    %              = -1*(a2b3 - a3b2) , -1*(a3b1 - a1b3), -1*(a1b2 - a2b1)

B_fw = [ 1/sqrt(3), 1/sqrt(3), 1/sqrt(3);...
         0, 1/sqrt(2), -1/sqrt(2);...
         -1*(  (1/sqrt(3))*(-1/sqrt(2)) - (1/sqrt(3))*(1/sqrt(2)) ) , ...
         -1*( -(1/sqrt(3))*(-1/sqrt(2)) ) , ...
         -1*((1/sqrt(3))*(1/sqrt(2)) )];

S=1;
P1 = complex(X1 , X2.*B_fw(1,1) + X3.*B_fw(1,2) + X4.*B_fw(1,3));
P2 = complex(X2.*B_fw(2,1) + X3.*B_fw(2,2) + X4.*B_fw(2,3) , S.*(X2.*B_fw(3,1) + X3.*B_fw(3,2) + X4.*B_fw(3,3)));

clear X1 X2 X3 X4;

% compute the two complex FFTs:
    	C1 = fftn(P1);
    	C2 = fftn(P2);
clear P1 P2;        

% change back to original basis:
        B_rv = B_fw.';
        % compute the change of basis:
        Z1 = real(C1); % the scalar 
        Z2 = imag(C1).*B_rv(1,1) + real(C2).*B_rv(1,2) + S.*imag(C2).*B_rv(1,3);
        Z3 = imag(C1).*B_rv(2,1) + real(C2).*B_rv(2,2) + S.*imag(C2).*B_rv(2,3);
        Z4 = imag(C1).*B_rv(3,1) + real(C2).*B_rv(3,2) + S.*imag(C2).*B_rv(3,3);
        
return;
