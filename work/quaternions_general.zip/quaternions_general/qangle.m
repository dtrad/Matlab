function [theta,phi1,phi2,phi3] = qangle(a1,a2,a3,a4)

% following the rules for quaternion algebra;
A = (a1.^2 + a2.^2 + a3.^2 + a4.^2).^0.5;

theta = acos(a1./(A));
phi1   = (a2) ./ ((((a2.^2) + (a3.^2) +(a4.^2))).^0.5);
phi2   = (a3) ./ ((((a2.^2) + (a3.^2) +(a4.^2))).^0.5);
phi3   = (a4) ./ ((((a2.^2) + (a3.^2) +(a4.^2))).^0.5);
   
return;
