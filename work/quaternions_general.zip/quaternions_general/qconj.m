function [b1,b2,b3,b4] = qconj(a1,a2,a3,a4)

% following the rules for quaternion conjugation;
b1 = a1;
b2 = -a2;
b3 = -a3;
b4 = -a4;

return;
