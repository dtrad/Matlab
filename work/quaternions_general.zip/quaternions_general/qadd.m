function [c1,c2,c3,c4] = qadd(a1,a2,a3,a4,b1,b2,b3,b4)

% following the rules for quaternion addition;
c1 = a1 + b1;
c2 = a2 + b2;
c3 = a3 + b3;
c4 = a4 + b4;

return;
