function [b1,b2,b3,b4] = qrot(a1,a2,a3,a4,theta,axisx,axisy,axisz)

q1 = cos(theta/2);
q2 = axisx*sin(theta/2); 
q3 = axisy*sin(theta/2); 
q4 = axisz*sin(theta/2); 

% combine the two rotations into one single rotation 
[tmp1,tmp2,tmp3,tmp4] = qmult(q1,q2,q3,q4,a1,a2,a3,a4);
[b1,b2,b3,b4] = qmult(tmp1,tmp2,tmp3,tmp4,q1,-q2,-q3,-q4);

return;
