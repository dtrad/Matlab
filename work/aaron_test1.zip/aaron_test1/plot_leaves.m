clear all; close all; clc;
setpath_Windows;
leaves = imread('leaves.jpg');
[nt,nx]=size(leaves(:,:,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the components individually (R, then G, then B)
% then all together RGB
    red   = gray; red(:,2)   = 0; red(:,3)   = 0;
    green = gray; green(:,1) = 0; green(:,3) = 0;
    blue  = gray; blue(:,1)  = 0; blue(:,2)  = 0;

    figure(01); 
    imagesc(leaves(:,:,1));
    colormap(red);colorbar;
    xlabel('x');ylabel('y');title('red');

    figure(02); 
    imagesc(leaves(:,:,2));
    colormap(green);colorbar;
    xlabel('x');ylabel('y');title('green');

    figure(03); 
    imagesc(leaves(:,:,3));
    colormap(blue);colorbar;
    xlabel('x');ylabel('y');title('blue');
 
    figure(04); %plot all at once as RGB image
    imagesc(leaves);
    colormap('jet');colorbar;
    xlabel('x');ylabel('y');title('full color image');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the fk spectrum of each component
dt = 1;
dx = 1;
L  = 10; % smoothing of spectra

[S_r,k,f] = fk_spectra(double(leaves(:,:,1)),dt,dx,L);
            nk = 2*(2^nextpow2(size(S_r,1)));
            nf = 2*(2^nextpow2(size(S_r,2)));
            P_r = fftshift( angle(fft2(double(leaves(:,:,1)),nf,nk)) );
            P_r = P_r(nf/2:nf,:);

[S_g,k,f] = fk_spectra(double(leaves(:,:,2)),dt,dx,L);
            P_g = fftshift( angle(fft2(double(leaves(:,:,2)),nf,nk)) );
            P_g = P_g(nf/2:nf,:);
[S_b,k,f] = fk_spectra(double(leaves(:,:,3)),dt,dx,L);
            P_b = fftshift( angle(fft2(double(leaves(:,:,3)),nf,nk)) );
            P_b = P_b(nf/2:nf,:);

%%
    figure(11); 
    imagesc(k,f,S_r.^0.1);caxis([0 2*mean(S_r(:).^0.1)]); colorbar; 
    xlabel('kx');ylabel('ky');title('spectrum for red');
    figure(12); 
    imagesc(k,f,S_g.^0.1);caxis([0 2*mean(S_r(:).^0.1)]); colorbar;
    xlabel('kx');ylabel('ky');title('spectrum for blue');
    figure(13); 
    imagesc(k,f,S_b.^0.1);caxis([0 2*mean(S_r(:).^0.1)]); colorbar;
    xlabel('kx');ylabel('ky');title('spectrum for green');
    figure(21); 
    imagesc(k,f,P_r);caxis([-pi pi]); colorbar; 
    xlabel('kx');ylabel('ky');title('phase for red');
    figure(22); 
    imagesc(k,f,P_g);caxis([-pi pi]); colorbar;
    xlabel('kx');ylabel('ky');title('phase for blue');
    figure(23); 
    imagesc(k,f,P_b);caxis([-pi pi]); colorbar;
    xlabel('kx');ylabel('ky');title('phase for green');
%%
[S,k,f] = qfk_spectra(zeros(nt,nx), double(leaves(:,:,1)),double(leaves(:,:,2)),double(leaves(:,:,3)),dt,dx,L);
[D1,D2,D3,D4]= quaternion_fftn(zeros(nt,nx),double(leaves(:,:,1)),double(leaves(:,:,2)),double(leaves(:,:,3)),'L');

[theta,phi1,phi2,phi3] = qangle(D1,D2,D3,D4);

    figure(31); 
    imagesc(k,f,S.^0.1);caxis([0 2*mean(S_r(:).^0.1)]); colorbar;
    xlabel('kx');ylabel('ky');title('quaternion spectrum');
    figure(41); 
    imagesc(k,f,theta.*phi1);caxis([-pi pi]); colorbar;
    xlabel('kx');ylabel('ky');title('quaternion phase 1');
    figure(42); 
    imagesc(k,f,theta.*phi2);caxis([-pi pi]); colorbar;
    xlabel('kx');ylabel('ky');title('quaternion phase 2');
    figure(43); 
    imagesc(k,f,theta.*phi3);caxis([-pi pi]); colorbar;
    xlabel('kx');ylabel('ky');title('quaternion phase 3');



